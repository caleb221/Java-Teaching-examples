package snake_p4;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.Timer;

import java.util.*;

public class Snake implements ActionListener,KeyListener
{
	public static Snake snakeObj; // object for the snake class
	public renderPanel renderpanel;//class we have not written yet
	
	public Timer timer = new Timer(20,this);
	//timers help us keep the game going, we want to repaint and 
	//update as we play, the timer will help us with this!
	
	public ArrayList<Point> snakeParts = new ArrayList<Point>();
	//an array list to keep adding fat (longer snake) to the snake
	//when he eats a piece of food...he is very hungry
	
	public static final int UP=0,DOWN=1,LEFT=2,RIGHT=3,SCALE=10;
	//some game constants
	public int ticks=0,direction=DOWN,score,tailLength=10,time;
	//some changing integers, these can be changed while we play
	public Point head,food;
	//head of the snake, and the piece of food
	public Random random;
	//in the wild, we never know where the next piece of food will come
	//we could  say, its randomly placed 0_0
	
	public boolean over = false, paused;
	
	public JFrame frame;
	//our frame
	
	public Dimension dim;
	//our dimension, to see how big our computer screen is 
	
	//constructor
	public Snake()
	{
		dim = Toolkit.getDefaultToolkit().getScreenSize();
		frame = new JFrame("SNAAAKKKEEEEE ^_^");
		frame.setVisible(true);
		frame.setSize(805, 700);
		frame.setResizable(false);
		frame.setLocation(dim.width/2-frame.getWidth()/2
				, dim.height/2-frame.getHeight()/2);
		frame.add(renderpanel = new renderPanel());
		frame.addKeyListener(this);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		StartGame();
	}//end of constructor
	
	public void StartGame()
	{
		over = false;
		paused = false;
		time=0;
		score =0;
		tailLength = 14;
		ticks =0;
		direction = DOWN;
		head = new Point(0,-1);
		random = new Random();
		snakeParts.clear();
		food = new Point(random.nextInt(79),random.nextInt(66));
		timer.start();
	}
	
	public boolean noTailAt(int x, int y)
	{
		for(Point p : snakeParts)
		{
			if(p.equals(new Point(x,y)))
			{
				return false;
			}
		}
		return true;
	}


	
	
	@Override
	public void keyPressed(KeyEvent e)
	{
		int i = e.getKeyCode();
		
		if((i == KeyEvent.VK_A || i == KeyEvent.VK_LEFT) 
				&& direction != RIGHT)
		{
			direction = LEFT;
		}
		
		if((i == KeyEvent.VK_D || i == KeyEvent.VK_RIGHT)
				&& direction != LEFT)
		{
			direction = RIGHT;
		}
		if((i == KeyEvent.VK_W || i == KeyEvent.VK_UP) 
				&& direction != DOWN)
		{
			direction = UP;
		}
		if((i == KeyEvent.VK_S || i == KeyEvent.VK_DOWN) 
				&& direction != UP)
		{
			direction = DOWN;
		}
		
		if( i == KeyEvent.VK_SPACE)
		{
			if(over == true)
			{
				StartGame();
			}
			else
			{
				paused = !paused;
			}
			
		}
		
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void actionPerformed(ActionEvent e)
	{
		
		renderpanel.repaint();
		ticks++;
		
		if(ticks%2 ==0 && head != null && !over && !paused)
		{
			time++;
			snakeParts.add(new Point(head.x,head.y));
			
			if(direction == UP)
			{
				
				if(head.y-1 >= 0 && noTailAt(head.x,head.y-1))
				{
					head = new Point(head.x,head.y-1);
				}
				else
				{
					over = true;
				}
			}
			
			if(direction == DOWN)
			{
				if(head.y+1 <67 && noTailAt(head.x,head.y-1))
				{
					head = new Point(head.x,head.y-1);
				}
				else
				{
					over = true;
				}
			}
			if(direction == LEFT)
			{
				if(head.x-1>=0 && noTailAt(head.x-1,head.y))
				{
					head = new Point(head.x-1,head.y);
				}
				else
				{
					over = true;
				}
			}
			if(direction == RIGHT)
			{
				if(head.x+1<80 &&noTailAt(head.x+1,head.y))
				{
					head = new Point(head.x+1,head.y);
				}
				else
				{
					over=true;
				}
			}
			
			if(food != null)
			{	
				if(head.equals(food))
				{
					score+=10;
					tailLength+=10;
					food.setLocation(random.nextInt(79),random.nextInt(66));
				}
			}		
		}
	}
		public static void main(String[] args)
		{
			snakeObj = new Snake();
		}
	

}



