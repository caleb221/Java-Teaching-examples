package snake_p4;
/*
 * SNAKE GRAPHICS!
 */
import java.awt.*;
import javax.swing.*;

public class renderPanel extends JPanel
{
	//fields
	public static final Color GREEN = new Color(1666073);
	//dark green color, you are welcome to choose any you would like!

	protected void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		Snake snake1 = Snake.snakeObj;
		g.setColor(GREEN);
		g.fillRect(0, 0, 800, 700);
		
		g.setColor(Color.MAGENTA);//color of the snake
		
		for(Point p : snake1.snakeParts)
		{
			g.fillRect(p.x*snake1.SCALE, p.y*snake1.SCALE,
										snake1.SCALE,snake1.SCALE);
		}
		g.setColor(Color.GREEN);
		g.fillRect(snake1.head.x*snake1.SCALE,snake1.head.y
										,snake1.SCALE,	snake1.SCALE);
		
		g.setColor(Color.green);
		for(Point p : snake1.snakeParts)
		{
			g.drawOval(p.x*snake1.SCALE, p.y*snake1.SCALE,8,8);
		}
		
		g.setColor(Color.blue);
		for(Point p : snake1.snakeParts)
		{
			g.drawOval(p.x*snake1.SCALE, p.y*snake1.SCALE,5,5);
		}
		
		g.setColor(Color.orange);
		g.fillOval(snake1.food.x*snake1.SCALE, snake1.food.y*snake1.SCALE
				, snake1.SCALE, snake1.SCALE);
		String str ="Score: "+snake1.score+"  Length:  "+snake1.tailLength
								+" time: "+snake1.time/20;
		g.setColor(Color.white);//text color
		
		g.drawString(str, (int)(getWidth()/2-str.length()*2.5f), 10);
		
		str ="GAME OVER, YOU KILLED THE SNAKE =,(";
		if(snake1.over)
		{
			g.drawString(str, (int)(getWidth()/2-str.length()*2.5f),
										(int)snake1.dim.getHeight()/4);
		}
		str ="THE GAME IS PAUSED, your snake went to sleep. Press Space"
				+ "to wake him up!";
		if(snake1.paused && !snake1.over)
		{
			g.drawString(str, (int)(getWidth()/2-str.length()*2.5f),
					(int)snake1.dim.getHeight()/4);
		}
	}
	
}


