/*
 * Caleb Seifert
 * 11/21/16
 * pig latin translator!
 */
package piglatin_translator;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class piglatin extends JFrame 
{
	//field!
	// i need a button and two text fields
	JButton btn1 = new JButton("Translate!");
	JTextField txt_in = new JTextField(10);
	JTextField txt_out = new JTextField(10);

	//constructor
	public piglatin()
	{
		btn_method click = new btn_method(); // get the action event into the constructor
		btn1.addActionListener(click);		// connect button and action event
		txt_in.addActionListener(click);	// connect text field and action event
		txt_out.setEditable(false);			// user cannot change the output text field
		btn1.setBackground(Color.pink);
		txt_out.setBackground(Color.yellow);
		
		
		
		JPanel panel = new JPanel();   // create a panel object
		
		panel.setLayout(new FlowLayout());		// set the layout
		
		panel.setBackground(Color.cyan);
		
		panel.add(new JLabel("what word do you want to translate?")); // tell the user what to do
		panel.add(txt_in); // add the text field
		panel.add(btn1); // add the button
		panel.add(new JLabel("translation: ")); // let the user know what is happening
		panel.add(txt_out);	// let the user see the translation
		
		setContentPane(panel);	 // put the panel into the frame
		setTitle("Pig latin translator!"); // set the frame title
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //default close operations for frame
		pack();
	}
	
	public static String translator(String Amessage)
	{
		String word = Amessage; // use the input from the user
		String output = "hello"; // we dont want to return a null so we initialize
		boolean check = false; 
		String[] vowels = {"a","e","i","o","u"}; // a list of all the vowels (array)
		
		String firstletter= word.substring(0, 1); // the first letter of our given word
		
		for(int i=0; i<vowels.length;i++) // check for vowels
		{
			//go through all the boxes of data in the array, and check them against 
			//the first letter of our given word
			check = vowels[i].equalsIgnoreCase(firstletter);
			
			//if a vowel is found, exit the loop and keep check = true
			if(check == true)
			{
				break;
			}
		}
		
		if(check == true)
		{	// we have a vowel because check is true, our rule says that the vowel rule
			//adds way to the end of each word, it is done here
			output = word+"way";
		}
		else
		{
			//for non vowel words, we take the first letter and put it after the
			// last character of the word then add "ay" to it
			output = word.substring(1,word.length())+firstletter+"ay";
		}
		//return the translated word
		return output;
	}
	//action method
	public class btn_method implements ActionListener
	{
		public void actionPerformed(ActionEvent e)
		{	
			
			String input = txt_in.getText();// get the text from the user
			
			String answer = translator(input); // translate the word
			txt_out.setText(answer); // show the user the translation
		}
	}
	//main
	public static void main(String[] args)
	{
		piglatin app = new piglatin();
		app.setVisible(true);
	}
}
