/*
 * Caleb seifert
 * movement
 * 11/23/16
 */
package movement2;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class move extends JPanel
{
	//fields
	int x,y,x2,y2;
	JTextField fld1 = new JTextField(5);
	
	public move()
	{
		fld1.addKeyListener(new keys());
		fld1.setEditable(false);
		setLayout(new FlowLayout());
		setBackground(Color.yellow);
		add(fld1);
	}
	
	public void paint(Graphics g)
	{
		super.paintComponent(g);
		
		x=this.getWidth()/2;
		y=this.getHeight()/2;
		g.setColor(Color.cyan);
		Font f = new Font("MonoSpaced", Font.BOLD,45);
		g.setFont(f);
	//	g.drawString("ţ��", x-x2, y-y2);
		
		g.setColor(Color.yellow);
		g.fillOval(x-x2+30, y-y2+30, 40, 40);
		g.setColor(Color.BLACK);
		g.fillOval(x-x2+35, y-y2+35, 15, 15);
		g.fillOval(x-x2+55, y-y2+35, 15, 15);
		g.drawLine(x-x2+35, y-y2+55, x-x2+50, y-y2+55);
	}
	
	public class keys implements KeyListener
	{
		public void keyPressed(KeyEvent arg0) {
		}
		public void keyReleased(KeyEvent arg0) {
		}
		public void keyTyped(KeyEvent e) 
		{
			char selected = e.getKeyChar();
			fld1.setText(""+selected);
			
			if(selected == 'w')
			{
				y2 +=5;
				repaint();
			}
			if(selected == 's')
			{
				y2-=5;
				repaint();
			}
			if(selected == 'a')
			{
				x2+=5;
				repaint();
			}
			if(selected == 'd')
			{
				x2-=60;
				repaint();
			}
		}
	}
	public static void main(String[] args)
	{
		move app = new move();
		JFrame frame = new JFrame("ITS MOVING 0_0");
		frame.setContentPane(app);
		frame.setSize(250,250);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}

}
