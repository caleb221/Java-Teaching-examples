/*
 * caleb Seifert
 * 10/27/16
 * Integer arrays
 */
package int_arrays;

import java.util.Scanner;

public class int_arrays 
{
	
	public static void main(String[] args)
	{
		Scanner keyboard = new Scanner(System.in);
		int num_array[] = new int[5];
		int numbers[] ={0,0,0,0,0};
		
		numbers[3] = 3;
		for(int i=0; i<numbers.length;i++)
		{
			numbers[i]=i;
			System.out.println(numbers[i]);
		}
		
		System.out.println("Please input a few numbers! \n");
		
		for(int n=0; n<num_array.length;n++)
		{
			num_array[n]=keyboard.nextInt();
			System.out.println("You have entered "+n+" out of 5!");
		}
		
		for(int l=0;l<num_array.length;l++)
		{
			System.out.println("your number is   " + num_array[l]);
			num_array[l] = num_array[l]*5;
			System.out.println(num_array[l]+" is your number * 5!!");
		}	
	}
}
