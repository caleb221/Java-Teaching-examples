/*
 * Caleb Seifert
 * 10/26/16
 * String arrays
 * 
 */

import java.util.*;

public class Strung_out 
{
	public static void main(String[] args)
	{
		Scanner keys = new Scanner(System.in);
		
		String name[] = new String[5]; // create a string array with 5 spaces
		
		String[] greeting = {"Hello ","If if were another person, I would not like to be  ",
				"the coolest person is:  ","the best at basketball  might be ",
				"the person who falls asleep most is "};
		
		Random randomclass = new Random();
		int randomnum=randomclass.nextInt(5);
		
		System.out.println("Hello! who are your 5 best friends? \n");
		for(int i=0; i<name.length;i++)
		{
			name[i]=keys.nextLine();
			System.out.println("Awesome! you have "+(i+1)+" out of 5 choices left");
		}
		
		for(int n=0; n<name.length;n++)
		{
			System.out.println(greeting[randomnum]+" "+name[randomnum]);
			randomnum=randomclass.nextInt(5);
		}
		
	}
	

}
