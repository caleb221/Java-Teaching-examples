package variables;
/*
 * where do variables live?
 * they live in their functions!
 * some of them live only in a loop (they die after the loop is finished) =(
 * some of them live in the whole class we write
 * most of them are contained in their own classes
 * some can be "sent" to other classes
 */
import java.util.*;

public class variable_homes 
{
	static int top_variable=5;
	
	public static void main(String[] args)
	{
		Scanner keyboard = new Scanner(System.in);//keyboard!
		double user_num=0;
		double ans=0;
		System.out.println("hello! please input a number!");
		user_num=keyboard.nextDouble();//get the number from the keyboard
		
		//top_variable lives outside of the 'main' function
		//but can still visit inside for some quick math
		//but in order to let top_variable into main, we need to make sure
		//it will stay the same value, which is why we said 'static'
		ans=top_variable+user_num;//do some math!
		
		System.out.println("your answer is: "+ans);
	}
	
}
