/*
 * 
 */

package movement;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class box_pusher extends JPanel implements ActionListener
// we extend JPanel, so we do not need to create a separate panel object
{
	//fields
	int x,y,x2,y2; // we need an X position and a Y position
				  //similarly, we need an X2 and a Y2 in order to change our position
	JTextField fld1 = new JTextField(5); // text field to show user the key typed
	private int time;
	 Color facecolor;
	//constructor
	public box_pusher()
	{
		keyboard keys = new keyboard();//create the key listener object in constructor
		fld1.addKeyListener(keys);// add the text field to the key listener
		fld1.setEditable(false); // no user input is needed for the text field 
		JLabel lbl1 = new JLabel("move the box!"); // add a label to the panel
		Timer clock = new Timer(30,this);
		clock.start();
		time=0;
		// we do NOT need to create a panel object, because we are extending
		// the JPanel super class
		
		lbl1.setBackground(Color.GREEN);// change the label's color to green
		setLayout(new FlowLayout());  // set the layout, here we use a Flow Layout
		add(lbl1);  				 // add the label to the panel
		add(fld1);					// add the text field to the panel
		setBackground(Color.GRAY); // set the background color
	}
	
	public void actionPerformed(ActionEvent e)
	{
		time++;
		repaint();
	}
	
	public void paint(Graphics g) // Component of JPanel
	{
		super.paintComponent(g); // gets any graphics settings that were assigned
								// and uses them, here it is the background color
								// that we have already set up
		x=this.getWidth()/2; // center of X position on panel (pixels)
		y=this.getHeight()/2;// center of Y position on panel (pixels)
		g.setColor(Color.cyan); //setting the color
		int y3 = (int)(130-(int)75*(Math.sin(0.005*Math.PI*time)));
		Font f = new Font("SansSerif",Font.BOLD,25); //making a nice font
		g.setFont(f); // setting that nice font
		g.drawString("ţ��",x, y-y3);	// draw a string on the panel 
		g.fillRect(x, y+y3,25,25);    // draws a solid rectangle where we specify
		
		int xrange = (x-x2)-x;
		int yrange = (y-y2)-y;
	//	System.out.println(xrange);
		if(xrange > -50)
		{
			facecolor = Color.YELLOW;
		}
		else
		{
			facecolor=Color.red;
		}
		
		
		// happy-ish face equation 
		g.setColor(facecolor); // set the head color
		
		g.fillOval(x-x2+30, y-y2+30, 45, 45); // draw the head
		g.setColor(Color.BLACK);  // set the detail color
		g.fillOval(x-x2+35, y-y2+35, 15, 15); // draw an eye (oval)
		g.fillOval(x-x2+55, y-y2+35, 15, 15); // draw another eye (oval)
		g.drawLine(x-x2+35, y-y2+60, x-x2+50, y-y2+60); // draw the mouth
		
	}
	
	public class keyboard implements KeyListener
	{

		@Override
		public void keyPressed(KeyEvent arg0) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void keyReleased(KeyEvent arg0) {
			// TODO Auto-generated method stub
			
		}

		public void keyTyped(KeyEvent e) 
		{
			char typed = e.getKeyChar();
			
			fld1.setText(""+typed);
			
			if(typed == 'w')
			{
				y2 += 10; // like num++, but instead of adding 1 we add 5
				// these are in pixel units
				repaint();
			}
			if(typed == 's')
			{
				y2-=10; // same as y2=y2-5
				repaint();
			}	
			if(typed == 'a')
			{
				x2+=10; // same as y2=y2-5
				repaint();
			}	
			if(typed == 'd')
			{
				x2-=10; // same as y2=y2-5
				repaint();
			}	
		}	
	}
	
	public static void main(String[] args)
	{
		box_pusher app = new box_pusher();
		JFrame frame = new JFrame("MOVE THE BOX!");
		frame.setContentPane(app);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(250, 250);
		frame.setVisible(true);
	}
}

