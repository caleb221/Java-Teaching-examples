/*
 * caleb seifert
 * 11/22/16
 * gui keys
 */
package keys;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class gui_keys extends JFrame
{
	//fields
	JTextField fld1 = new JTextField(10);
	JTextField fld2 = new JTextField(10);
	JButton btn1 = new JButton("exit");

	int x;
	int y;
	int x2;
	int y2;
	public gui_keys()
	{
		btn1.addActionListener(new buttonmethod());
		fld1.addKeyListener(new keys());
		fld1.setEditable(false);
		btn1.setBackground(Color.cyan);
		btn1.setForeground(Color.red);
		
		fld2.addKeyListener(new keys());
		fld2.setEditable(false);
		
		JPanel panel= new JPanel();
		panel.setLayout(new FlowLayout());
		panel.add(btn1);
		panel.add(fld1);
		panel.add(fld2);
		panel.add(new graphix());
		panel.setBackground(Color.pink);
		panel.setSize(350,120);
		
		setContentPane(panel);
		setSize(350,120);
		setTitle("Keys!");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		pack();
	}
	

	public class buttonmethod implements ActionListener
	{

		@Override
		public void actionPerformed(ActionEvent arg0) 
		{
			System.exit(0);
		}
	}
	
	public class graphix extends JPanel
	{
		
		public void paintComponent(Graphics g)
		{
			super.paintComponents(g);
			g.setColor(Color.blue);
			Font f = new Font("SansSerif",Font.BOLD,22);
			g.setFont(f);
			g.drawString("H", x-x2, y-y2);
		}
	}
	public class keys implements KeyListener
	{

		@Override
		public void keyPressed(KeyEvent e)
		{
			fld2.setText("You pressed  "+e.getKeyChar());
		}

		@Override
		public void keyReleased(KeyEvent e) 
		{
			fld2.setText("you released "+e.getKeyChar());
		}

		@Override
		public void keyTyped(KeyEvent e)
		{
			fld1.setText("you typed: "+e.getKeyChar());
			
		}
	}
	public static void main(String[] args)
	{
		gui_keys app = new gui_keys();
		app.setVisible(true);
	}
	
}
