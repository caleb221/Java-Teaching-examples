/*
 * Caleb Seifert
 * 10/21/16
 * Review of functions, strings, math
 */

package week_inreview;

import java.util.*;

public class irene 
{
	
	public static void log(String Amessage)
	{
		System.out.println(Amessage);
	}
	
	public static double raise_by_a_power(double base, double power)
	{
		double answer = 0;
		answer = Math.pow(base, power);
		return answer;
	}
	
	public static void main(String[] args)
	{
		String username;
		String userpass;
		String name = "caleb";
		String pass = "pass";
		double ans =0;
		double num1=0;
		double num2 =0;
		boolean check = false;
		Scanner keys = new Scanner(System.in);
		Date today = new Date();
		
		log("hello! \n what is your name?");
		
		username=keys.nextLine();
		log("Welcome " +username+"\n What is your password?");
		userpass= keys.nextLine();
		check = name.equalsIgnoreCase(username);
		while ( check == true)
		{
			check = pass.equals(userpass);
			if(check == true)
			{
				log("Welcome back to your computer, how are you on this fine day of "+today);
				log("lets raise a number by a power");
				log("please input the number you want to raise: ");
				num1=keys.nextDouble();
				log("what do you want to raise this number by? ");
				num2=keys.nextDouble();
				
				ans=raise_by_a_power(num1,num2);
				log(num1+" raised to the "+num2+" is "+ans);
			}
			else
			{
				log("THATS NOT THE PASSWORD!!!! >=(\ntry again");
				userpass= keys.nextLine();
		        check = pass.equals(userpass);	
			}
		}
	}
}