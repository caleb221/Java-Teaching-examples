/*
 * Caleb Seifert
 * 10/21/16
 * Week in review (Functions, Strings, boolean, java.Math)
 */

package week_in_review;

import java.util.*;

public class archers_class 
{
	public static boolean userlogin(String name, String password)
	{  boolean check = false;
		  // add the code needed to check the user's name and password
		 //use whatever password you would like
		// remember to return a true if the user name AND password are
	   // correct
		return check;
	}
	
	public static void main(String[] args)
	{
		Scanner keys = new Scanner(System.in);
		boolean logincheck;
		String username;
		String userpass;
		// tell the user hello, and ask for a name and password
		//print out today's date using:
		Date today = new Date();
		logincheck= userlogin(username,userpass);
		// if the user successfully logs in
		// create a calculator option, the user should be able to
		// take the sqaure root (math.sqrt(number)
		// take the absolute value Math.abs(num)
		// raise a number to a specified power Math.pow(basenum,power)
	}
	

}
