package review_of_arrays;

public class arrays_review {

}
