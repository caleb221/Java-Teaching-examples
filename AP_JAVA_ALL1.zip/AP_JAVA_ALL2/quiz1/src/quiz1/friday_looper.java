package quiz1;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class friday_looper
{
	public static void main(String[] args)
	{
		/*
		 * 
		 * Lets re-visit the grand ole calculator!
		 * instead of a console app, lets make it a GUI
		 * for classwork purposes, it only needs to perform
		 * 2 options ( these are up to you, maybe add or subtract )
		 * but it does need to be a GUI
		 * you have until the end of class
		 * make it awesome! 
		 * **remember, you can change the color of all your GUI components
		 * 			just by using setColor() or any similar 
		 * 			color methods available for that component***
		 * 
		 * remember to import the 3 main GUI libraries
		 * the constructor helps you out depending which component you extend
		 * you can take in data from a JTextField OR simply create JButtons for the user
		 * JTextFields are great for showing users answers =)
		 * 
		 * it all happens in the ActionListener and actionPerformed
		 * 
		 *  as usual, if you dont finish this in class please email it to me
		 * 
		 * 
		 */
	}

}
