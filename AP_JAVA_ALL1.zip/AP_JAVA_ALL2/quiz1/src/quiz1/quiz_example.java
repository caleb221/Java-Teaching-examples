package quiz1;

import javax.swing.*;
import java.awt.*;

public class quiz_example 
{
	public static void main(String[] args)
	{
		int question=Integer.parseInt(JOptionPane.showInputDialog(null,"Please pick 1-5"));
		String answer;
		String response;
		char responseChar;
		
		 switch(question)
		 {
		 case 1:
			 response = JOptionPane.showInputDialog(null,
					 "What is the name of this class?"	
							 +"\nA. Computer science"
					 		 +"\nB. This is not class"
					 		 +"\nC. this is your computer testing you"
					 		 +"\nD. I am class");
			 responseChar = response.charAt(0);
			 if(responseChar == 'a' || responseChar == 'A')
			 {
				 JOptionPane.showMessageDialog(null, "WOOO YOU WIN!");
			 }
			 
			 break;
		 case 2:
			 break;
		 case 3:
			 break;
		 case 4:
			 break;
		 case 5:
			 break;
		 }
		
	}

	
}
