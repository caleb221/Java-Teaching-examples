/*
 * caleb seifert
 * 11/1/16
 * switch statements 
 */
package switch11;
import java.util.Scanner;
public class switches_not_stitches 
{
	public static void main(String[] args)
	{
		Scanner keys = new Scanner(System.in);
		int input =0;
		System.out.println("Hello!\n~please pick a number 1-10");
		input = keys.nextInt();
		switch(input)
		{	
		case 1: System.out.println("1 is great!");	
			break;
		case 2: System.out.println("2 is the first number you can half");
			break;
		case 3: System.out.println("3 is a prime number!");
			break;
		case 4: System.out.println("4 is life");
			break;
		case 5: System.out.println("5 is half of 10!");
			break;
		case 6: System.out.println(" 6/2=3 which is a prime number");
			break;
		case 7: System.out.println("7 is lucky? ");
			break;
		case 8: System.out.println(" 8 is crazy!");
			break;
		case 9: System.out.println("9 is 6 upside down");
			break;
		case 10: System.out.println("you have 10 fingers!");
			break;
		default: System.out.println("THAT WAS NOT 1-10! >=( "); 
			break;
		}
		
	}
	
	

}
