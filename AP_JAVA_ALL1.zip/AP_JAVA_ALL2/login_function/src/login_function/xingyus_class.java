/*
 * Caleb Seifert 
 * 10/21/16
 * functional login 
 */

package login_function;

import java.util.*;

public class xingyus_class 
{
	
	public static boolean userlogin(String name, String pswd)
	{
		String username = "caleb";
		String pass = "123";
		boolean check = false;
		
		check = username.equalsIgnoreCase(name);	
		if (check == true)
		{
		  check = pass.equalsIgnoreCase(pswd);
		  	if(check == true)
		  		{
		  			return check;
		  		}
		}
		else
			{
				check = false;
				return check;
			}
		return false;
	}
	
	public static void main(String[] args)
	{
		String myname;
		String mypass;
		boolean login;
		Scanner keys = new Scanner(System.in);
		
		System.out.println("Hello! what is your name?\n");
		myname = keys.nextLine();
		System.out.println("Awesome! welcome" +myname+"\nWhat is your password?");
		mypass=keys.nextLine();
		
		login = userlogin(myname,mypass);
		
		if (login == false)
		{
			
		System.out.println("GO AWAY! THIS IS NOT YOUR COMPUTER >=(");
		}
		else
		{
			System.out.println("Hello! =)\n");
			Date today = new Date();
			System.out.println("How are you on this fine day of \n"+today);
	
		System.out.println("Would you like to do some math? [y/n]");
		String yesno = keys.nextLine();
		
		if(yesno.equals("y") == true)
		{
			System.out.println("Awesome! i love math! press one for square root,"
					+ "press 2 for powers,");
			int in = keys.nextInt();
			
			if(in == 1)
			{
				System.out.println("ok, what number should I square root for you?");
				double sqrnum =0;
				sqrnum = keys.nextDouble();
				sqrnum = Math.sqrt(sqrnum);
				System.out.println("you number is "+sqrnum);
			}
			if ( in == 2)
			{
				System.out.println("Alright, what number are we going to raise today?");
				int base =0;
				int powernum=0;
				base = keys.nextInt();
				System.out.println("Ok, What power are going to raise it too?");
				powernum=keys.nextInt();
				int ans =(int) Math.pow(base, powernum);
				System.out.println(base+" raised to the "+powernum+" is: "+ans);
			}
		}
		else
		{
			System.out.println("okkkaayyyyy, i dont like math either so thats cool");
		}
	}
  }
}
