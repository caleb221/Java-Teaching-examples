/*
 * Caleb Seifert
 * 10/27/16 
 * String arrays
 */
import java.util.Scanner;

public class stringy_boxes
{
	public static void main(String[] args)
	{
		Scanner keys = new Scanner(System.in);
		String[] names = new String[5];
		String[] greeting = {"hello ","ni hao ","bonjour","bienvenidos ","hey "};
		
		System.out.println("Hello! who are 5 cool people you know? \n");
		
		for (int i=0; i<names.length;i++)
		{
			names[i]=keys.nextLine();
			System.out.println("Awesome! you have entered "+i+" out of 4");
		}
		
		for (int n=0; n<names.length;n++)
		{
			System.out.println(greeting[n]+" "+names[n]);
		}
	keys.close();	
	}
}