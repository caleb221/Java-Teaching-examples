
public class cc {
public static void main(String[] args)
{
for (int i=0;i<4;i++)
	{
		for(int n=0;n<4;n++)
		{
			if (i%2 == n%2)
			{
				System.out.println("0");
			}
			else
			{
				System.out.println("1");
			}
		}
	
	}	
}
}
