/*
 * Caleb Seifert
 * 10/21/16
 * Strings, math, and a function
 */

package week_in_review21;
import java.util.*;
public class stringymath 
{
	
	public static void log(String Amessage)
	{
		//function to shorten System.out.println
		System.out.println(Amessage);
	}
	
	public static double powers(double base, double pow1)
	{
		//function to raise a number by a power
		double ans =0;
		ans = Math.pow(base, pow1);
		return ans;
	}
	
	public static void main(String[] args)
	{
		String username;
		String userpass;
		String name ="Caleb";
		String pass = "123456";
		double num1 =0;
		double num2 =0;
		Scanner keys = new Scanner(System.in);
		
		log("Hello! what is your name?");
		username = keys.nextLine();
		log("Nice to see you again, "+username+"\nWhat is the password?");
		userpass = keys.nextLine();
		
		boolean check = false;
		check = name.equalsIgnoreCase(username);
		if (check == true)
		{
			check = pass.equalsIgnoreCase(userpass);
			if (check == true)
			{
				Date today = new Date();
				log("Welcome home!");
				log("how are you on this fine day of?" +today);
				log("\n lets do some math!");
				log("press one to raise any number to a power!");
				int input = keys.nextInt();
				
				if ( input == 1)
				{
					log("Awesome! what number would you like to raise?");
					num1 = keys.nextDouble();
					log("Very cool! what power do you want to raise this number to?");
					num2 = keys.nextDouble();
					double answer = powers(num1,num2);
					log("your answer is "+answer);
				}

			}
			else
			{
				log("WRONG PASSWORD");
			}
		}
		else
			{
				log("GET OFF MY COMPUTER!!");
			}
		
	}

}
