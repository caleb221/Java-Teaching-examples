/*
 * Caleb Seifert
 * 10/20/16
 * Strings and some math
 */

package strings_n_math;
import java.util.Scanner;

public class strings_n_math 
{
	public static void main(String[] args)
	{
		int two =2;
		int three =3;
		String name ="caleb";
		String pswd = "123";
		String input;
		String in;
		
		int ans =0;
		boolean check =false;
		Scanner keys = new Scanner(System.in);
		
		System.out.println("Hello! What is your name? \n: ");
		input = keys.nextLine();
		
		check = name.equalsIgnoreCase(input);
		if (check == true)
		{
			System.out.println("Welcome "+input+"!! what is your password? \n");
			input = keys.nextLine();
			check = pswd.equals(input);
			if(check == true)
				{
					System.out.println("Welcome home! this"
							+ " be your computer\nWould you like to do math? [y/n]");
					in=keys.next();
					check = in.equals("n");
					if (check == true)
					{
						System.out.println("Thats ok, I dont like to do math either...");
					}
					else
						{
							System.out.println("Awesome! I love math! here is the modulus function!");
							
							for(int i=1;i<11;i++)
								{
									ans = two%i;
									System.out.println("2 %"+i +" = "+ans);
									ans = three%i;
									System.out.println("3 % "+i+" = "+ans);
								}
						}
				}
		}
		
		
	}

}
