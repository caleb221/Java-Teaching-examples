/*
 * Caleb seifert
 * 11/15/16
 * review
 */
package reviewp2;

import java.util.*; // this is a library
					// we use them to access many different functions in java
					// they save us a lot of time
public class review_part2 
{
	public static void main(String[] args)
	{
		Scanner keys = new Scanner(System.in);
		int num = 0;
		System.out.println("hello, this is an example of loops\n");
		
		for(int i=0;i<10;i++) // this is a for loop, it will repeat 9 times
		{
			// the code that will be repeated is inside the {Squiggly brackets}
			System.out.println("hello");
		}
		
		while(num < 20) //this is a while loop, it will run until its condition is satisfied
		{ 				// here, the condition is do the loop while num is less than 20
			System.out.println("THIS IS A WHILE LOOP, it has looped "+num+" times");
			 num++;// same as num = num + 1
			 // changes the value of number by adding 1
			 //if we do not change num (or the variable we are using the while loop to check
			 // the loop will never exit and it will become infinite)
		}
		
		//========LOGICAL OPERATORS=============================================
		// ==, !=, <,>,<=,>=
		//these exist in mathematics as well, they have the same meaning
		// we use these operators to check variables and make decisions in code
		// most commonly found in if statements, while loops, and for loops
		// == --> is equal to
		// != --> is not equal to
		// < --> is greater than
		// > --> is less than
		// <= --> is greater than or equal to
		// >= --> is less than or equal to
		//=====================================================================
		
		
	}

}
