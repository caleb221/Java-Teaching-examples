/*
 * lets load an image!
 */
import java.awt.*;
import java.awt.image.*;
import java.io.*;
import java.net.*;
import java.applet.*;
import javax.imageio.*;

package imageloading;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;
import java.awt.image.*;
import javax.imageio.*;


public class loading_images extends Component
{
	//fields
	
	BufferedImage image;
	public void paint(Graphics g)
	{
		g.drawImage(image, 0, 0, null);
		//paint our image onto the panel
		
	}
	public loading_images()
	{

		try{

			image=ImageIO.read(new File("shot.jpg"));
		}
		catch(IOException e)
		{

			System.out.println("this is the error:\n"+e);
		}
	}
	public Dimension getPreferredSize()
	{
		if(image==null)
		{
			return new Dimension(100,100);
		}
		else
		{

			return new Dimension(image.getWidth(null)
					,image.getHeight(null));
		}
	}
	
	public static void main(String[] args)
	{
		JFrame frame = new JFrame("THIS IS MY PICTURE GUYS!! ^_^");

		frame.addWindowListener(new WindowAdapter()
				{
					public void WindowClosing(WindowEvent e)
					{
						System.exit(0);
					}
				});
		frame.add(new loading_images());//our class!
		frame.pack();//make it all fit!
		frame.setVisible(true);//show me my picture!
	}
}






