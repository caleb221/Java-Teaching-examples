package wut;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class uhhwut extends JFrame
{

	JButton btn = new JButton("wht?");
	JTextField txt1 = new JTextField(5);
	
	public uhhwut()
	{
		JPanel panel = new JPanel();
		BorderLayout look = new BorderLayout();
		panel.setLayout(look);
		panel.add(btn,look.BEFORE_FIRST_LINE);
		panel.add(txt1,look.SOUTH);
		panel.addMouseListener(new mouses());
		
		setTitle("hi");
		setContentPane(panel);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		pack();
	}
	
	
	
	public class mouses implements MouseListener
	{

		@Override
		public void mouseClicked(MouseEvent arg0) 
		{
			// TODO Auto-generated method stub
		txt1.setText("X: "+arg0.getX()+" Y:" +arg0.getY());	
		}

		@Override
		public void mouseEntered(MouseEvent arg0) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseExited(MouseEvent arg0) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mousePressed(MouseEvent arg0) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseReleased(MouseEvent arg0) {
			// TODO Auto-generated method stub
			
		}
		
	}
	
	public static void main(String[] args)
	{
		uhhwut app = new uhhwut();
		app.setVisible(true);
	}
	
	
}
