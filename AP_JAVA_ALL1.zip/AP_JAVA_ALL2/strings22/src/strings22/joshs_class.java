/*
 * Caleb Seifert
 * 10/19/16
 * Strings!
 */
package strings22;

import java.util.Scanner;

public class joshs_class 
{	
	public static void main(String[] args)
	{
		Scanner keys = new Scanner(System.in);
		
		String s = "caleb";// Strings are text in computers
		String input; 
		char c = 'c';// characters are single letters in code	
		System.out.println("Hello! What is your name?");
		
		input = keys.nextLine();//get the string
		boolean check = s.equals(input);// booleans are either true or false
									   // if this is your name, it will return a true value
		
		if(check == true)// if the input matches the name, welcome! 
		{
			System.out.println("Welcome to your computer!");
		}
		else //This is not your computer! (the boolean check returned a false value
			{
				System.out.println("this is not your computer, please go away >=(");
			}
		
		
		/*
		 for(int i=0; i<s.length();i++)
		{
			System.out.println(s.charAt(i));
			
		}
		*/
	}

}
