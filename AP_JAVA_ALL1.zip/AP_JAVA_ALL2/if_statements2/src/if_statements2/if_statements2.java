/*
 * Caleb Seifert
 * if statements continued!
 * remember, and if statement is how we make a choice inside our code
 */
package if_statements2;

import java.util.*;

public class if_statements2 
{
	public static void main(String[] args)
	{
		/*
		 *  == --> equal to
		 *  != --> not equal to
		 *  >  --> greater than
		 *  <  --> less than
		 *  >= --> greater than or equal to
		 *  <= --> less than or equal to
		 *  true --> true
		 *  false --> false
		 */
		int user_input=0;
		int number5 = 5;
		int number10=10;
		
		Scanner keyboard = new Scanner(System.in);
		System.out.println("hello! please input any number!");
		user_input = keyboard.nextInt();
		
		if(user_input < 2)//if the number the user has given us is less than 2
		{
			System.out.println("your number was less than 2!");
		}
		if(user_input != 4)//if the user input was not 4
		{
			System.out.println("your input was NOT 4!");
		}
		
		if(user_input > 5)
		{
			System.out.println("your number is greater than 5!");
		}
		else if (user_input > 10) // else if CONNECTS the if statements together
		{
			System.out.println("your number is greater than 10!");
		}
		else //else handles EVERYTHING that is NOT asked by the if statement
		{
			System.out.println("you picked a large number");
		}
		
		System.out.println("Good morning Caleb =) its beautiful out today!");
		System.out.println("Press 1 to add (+) a number!");
		System.out.println("Press 2 to subtract (-) a number");
		user_input = keyboard.nextInt();
		
		if(user_input==1)
		{
			System.out.println("Lets add 2 numbers! what would you like to add?");
			number5=keyboard.nextInt();
			System.out.println("+");
			number10=keyboard.nextInt();
			System.out.println("=");
			int answer = number5+number10;
			System.out.println(answer);
		}
		else if(user_input==2)
		{
			System.out.println("Lets subtract 2 numbers! what would you like to subtract?");
			number5=keyboard.nextInt();
			System.out.println("-");
			number10=keyboard.nextInt();
			System.out.println("=");
			int answer = number5-number10;
			System.out.println(answer);
		}
		
		
		
	}

}
