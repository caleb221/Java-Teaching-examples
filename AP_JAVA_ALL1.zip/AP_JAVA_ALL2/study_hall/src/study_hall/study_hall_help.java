package study_hall;
import java.util.Scanner;
public class study_hall_help 
{
    // while loops
	// for loops 
	// if statements
	// functions 
 
	private static void log(String Amessage)
	{
		System.out.println(Amessage);
	}	
	
public  static void main(String[] args)
 { 
	Scanner keyboard = new Scanner(System.in);
	int num=5;
	double number=5;
	int num2=0;
	
	System.out.println("int is : "+num+" Double is:  "+number);
	log("hello!\n");
	log("Please press 3!");
	num = keyboard.nextInt();

	while (num != 3)
		{
			log("Try again!");
			num = keyboard.nextInt();
		}
	
	for ( int i=0 ;i<=10; i++)
		{// i++ is the same as i = i + 1;
			log("FOR LOOP HAS GONE: "+i+" TIMES");
			if (i < 5 )
				{
					log("I IS LESS THAN 5!!");
				}
			else
			{ 
				log("i must be bigger than 5");
			}
		}
	
 	}
}
