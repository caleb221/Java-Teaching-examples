/*
 * A string is the data type for letters and words!
 * we can do more than just math with a computer
 * lets make a simple login screen!
 */

/*
 * import! lets use some libraries so we can save ourselves some code
 * the libraries we are using here are mainly for GUIs
 * 			(nicer and prettier programs)
 * the main GUI libraries are
 * javax.swing    --> JPanel and related functions
 * java.awt       --> Colors and Panel buttons
 * java.awt.event --> main method for actions in our GUI
 */
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Strings extends JPanel
{
	//fields
	String name; //the piece of data saved in memory for your name
	String password;//variable (data) for your password
	JTextField name_fld = new JTextField(10);// text field (user input area)
	JTextField pass_fld = new JTextField(10);
	JButton btn1 = new JButton("~login~");//button for the user
	//constructor
	public Strings()
	{
		setLayout(new FlowLayout()); //choose a layout for the panel
			add(name_fld);			//add the name text field!
			add(pass_fld);			//add the password text field
			add(btn1);//add the button!
		setBackground(Color.orange);//make the background green (you choose all colors!)
		btn1.addActionListener(new button_presser());
		//connect the button to the actionListener
	}
	
	public class button_presser implements ActionListener
	//what do we want the button to do?
	{
		public void actionPerformed(ActionEvent e) //action for the listener
		{
			String user_password = "MYPASSWORD!";//choose your password
			password = pass_fld.getText();// get the password text from the user!
			name = name_fld.getText();//get the name text from the user 
			
			//if the password and the input are the same, let the user in!
			if(password.equals(user_password))
			{
				JOptionPane.showMessageDialog(null, "WELCOME HOME!"+name);
			}
			else//if the password does not match, dont let the user in
			{
				JOptionPane.showMessageDialog(null, "THIS IS NOT YOUR COMPUTER!"+name);
			}
		}
	}
	
	public static void main(String[] args)
	{
		Strings app = new Strings();// create our class object
		JFrame frame = new JFrame("LOGIN!");//the FRAME! (text in frame at top)
		frame.setContentPane(app);//add the panel object to the frame
		frame.setSize(200,150);//size of frame (and panel)
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//add the exit buttons
		frame.setVisible(true);//lets see the frame!
	}
}
