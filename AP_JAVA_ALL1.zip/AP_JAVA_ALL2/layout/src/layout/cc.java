package layout;

import java.util.ArrayList;

public class cc {

	
	
	
	
	
	
	
	
	//inside the checkersdata class
	}//end makemove 
	checkersmove[] getlegalmove(int player)
	{
		if(player != RED && player != BLACK)
		{
			return null;
		}
		int playerking;
		if(player == RED)
		{
			playerking = RED_KING;
		}
		else
		{
			playerking=BLACK_KING;
		}
		
		ArrayList<checkersmove> moves = new ArrayList<checkersmove>();
		
		for(int row=0;row<8;row++)
		{
			for(int col=0;col<8;col++)
			{
				if(board[row][col] == player || board[row][col] == playerking)
				{
					if(canjump(player,row,col,row+1,col+1,row+2,col+2))
						moves.add(new checkersmoves(row,col,row+2,col+2));
					if(canjump(player,row,col,row-1,col+1,row-2,col+2))
						moves.add(new checkersmoves(row,col,row-2,col+2));
					if(canjump(player,row,col,row+1,col-1,row+2,col-2))
						moves.add(row,col,row+2,col-2);
					if(canjump(player,row,col,row-1,col-1,row-2,col-2))
						moves.add(new checkersmoves(row,col,row-2,col-2));
				}
			}
		}
		
		if(moves.size() == 0)
		{
			for(int row=0;row<8;row++)
			{
				for(int col=0;col<8;col++)
				{
					if(board[row][col] == player || board[row][col] == playerking)
					{
						if(canmove(player,row,col,row+1,col+1,row+1,col+1))
							moves.add(new checkersmoves(row,col,row+1,col+1));
						if(canmove(player,row,col,row-1,col+1,row-1,col+1))
							moves.add(new checkersmoves(row,col,row-1,col+1));
						if(canmove(player,row,col,row+1,col-1,row+1,col-1))
							moves.add(row,col,row+1,col-1);
						if(canmove(player,row,col,row-1,col-1,row-1,col-1))
							moves.add(new checkersmoves(row,col,row-1,col-1));
					}
				}
			}
		}
		
		if(moves.size() ==0)
		{
			return null;
		}
		else
		{
			checkersmove[] movearray = new checkersmove[moves.size()];
			for(int i=0;i<moves.size();i++)
			{
				movearray[i]=moves.get(i);
			}
			return movearray;
		}
	}//end legalmoves
	 
	
	
	
	
	
	
	
	
}
