/*
 * Caleb Seifert
 * 10/28/16
 * layouts and 2nd panels
 */
package layout;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class layouts extends JPanel implements ActionListener
{
	// field
	JButton btn1 = new JButton("change the color!");
	JButton btn2 = new JButton("exit");
	Color bkgrndcolor; // background color that can change
	Font f = new Font("SansSerif",Font.BOLD,14);
	panel2 paneltwo;
	JTextField txtfld = new JTextField(10);
	// second panel object --> we want to connect the two classes
	//(layouts and panel2)
	// and we can do this by calling the desired constructor(panel2) 
	// where we want to put it (layouts)
	int x,y,x2,y2;
	//constructor
	public layouts()
	{
		setLayout(null); // we make our own layout!
		
		// create a dimension of 150X150 pixels
		// we want to define our size, but still enable the user
		// to change it during runtime so we say set preferred size
		setPreferredSize(new Dimension(150,150)); 
		
		setBackground(Color.DARK_GRAY);
		btn1.addActionListener(this);
		btn2.addActionListener(this);
		
		//call the panel2 class constructor here and build the second
		//panel as an object, then add it to the first panel
		paneltwo = new panel2();
		add(paneltwo);
		//set the size and boundaries of the second panel
		paneltwo.setBounds(80,50,164,164);
		
		add(btn1);
		//set the size and boundaries of the first button
		btn1.setBounds(0,20,150,20);
		
		add(btn2);
		//set the size and boundaries of the second button
		btn2.setBounds(0,40,80,20);	
		
		addMouseListener(new mousey());
		//txtfld.addMouseListener(new mousey());
		add(txtfld);
		txtfld.setBounds(150,20,80,20);
	}
	
	public class mousey implements MouseListener
	{

		@Override
		public void mouseClicked(MouseEvent arg0) {
			int mouse_x = arg0.getX();
			int mouse_y = arg0.getY();
			txtfld.setText("X:  "+mouse_x+" Y"+mouse_y);
			float hue = (float)Math.random();
			bkgrndcolor =Color.getHSBColor(hue, 1.0F, 1.0F);
			System.out.println("mouse at:"+mouse_y+"  square at"+(y2-y));
			 int [] xrangeright = new int[30];
			 int [] xrangeleft = new int[30];
			 int [] yrange = new int[30];
			 
			 for (int i=0;i<xrangeright.length;i++)
			 {
				 xrangeright[i] = Math.abs((x-x2+i));
				 xrangeleft[i] = Math.abs((x-x2-40+i));
				
				 yrange[i] = Math.abs((y-y2+i-2));
			 
				/* if (mouse_x == xrangeright[i] && mouse_x !=xrangeleft[i])
				 	{
				 		x+=5;
				 		repaint();
				 	}*/
				 if (mouse_x == xrangeleft[i] && mouse_x != xrangeright[i])
				 	{
				 		x-=5;
				 		repaint();
				 	}
			
				// System.out.println(xrangeleft[i]-xrangeright[i]);
			 }
		
			repaint();
			
		}

		@Override
		public void mouseEntered(MouseEvent arg0) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseExited(MouseEvent arg0) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mousePressed(MouseEvent arg0) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseReleased(MouseEvent arg0) {
			// TODO Auto-generated method stub
			
		}
	}
	
	public class panel2 extends JPanel implements ActionListener
	{
		int time;
		
		panel2()
		{	
		Timer clock = new Timer(20,this);
		time =0;
		clock.start();
		addMouseListener(new mousey());
			setPreferredSize(new Dimension(164,164));
		}
		
		public void actionPerformed(ActionEvent e)
		{
			time+=5;
			repaint();
		}
		
		public void paintComponent(Graphics g)
		{
			g.setColor(Color.ORANGE);
			g.drawRect(0, 0,getSize().width-1, getSize().height-1);
			g.drawRect(1, 1, getSize().width-3, getSize().height-3);
			
			if(bkgrndcolor == null)
			{
				g.setColor(Color.GREEN);
			}
			else
			{
				g.setColor(bkgrndcolor);
			}
			//g.setFont(f);
			
			//g.drawString("Hello! this is another panel :P ", 10,50);
			
			// lets make a checker board!
			for(int row = 0; row<8;row++) // 8 rows tall 
			{
				for(int col =0; col<8; col++) // 8 columns wide
				{
					//main decision maker for the checker board
					if(row %2 == col %2) 
					{
						//if both the row and the column are even numbers
						//(row %2 == col%2) will be false for odd
						//the statement changes the color
						g.setColor(bkgrndcolor);
					}
					else
					{
						//for the odd numbers
						g.setColor(Color.BLACK);
					}
					//make the checker board
				
					g.fillRect(2+col*20,2+row*20, 20, 20);
				}
			}	
			g.setColor(Color.red);
			//int x=0;
			 y=(getSize().width/2);//-(int)(50*Math.cos(0.005*Math.PI*time));
			 x2=(getSize().width/2);//-(int)(50*Math.sin(0.005*Math.PI*time));
			 y2=(getSize().height/2);
			g.fillRect(x2-x,y2-y , 30, 30);
		/*	g.fillRect(x+22,22, 20, 19);
			g.fillRect(x-22,42, 20, 19);
			g.fillRect(x2-40,   62, 20, 19);
			g.fillRect(x+44,   72, 20, 19);
			g.fillRect(x2*2,   82, 20, 19);
		*/
		}
	}
	
	public void actionPerformed(ActionEvent e) 
	{
		if(e.getSource() == btn1)
		{	
			float hue = (float)Math.random();
			bkgrndcolor =Color.getHSBColor(hue, 1.0F, 1.0F);
			repaint();
		}
		if(e.getSource() == btn2)
		{
			System.exit(0);
			//x2=0;
			//repaint();
		}	
	}
	
	public static void main(String[] args)
	{
		layouts app = new layouts();
		JFrame frame = new JFrame("Hello, there are 2 panels here");
		frame.setContentPane(app);
		frame.setSize(400,200);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
}