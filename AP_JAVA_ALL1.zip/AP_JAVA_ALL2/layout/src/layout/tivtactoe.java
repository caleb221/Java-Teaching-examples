package layout;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;



public class tivtactoe extends JFrame
{
	public static final int ROW=3;
	public static final int COL=3;
	public static final int CELL_SIZE = 100;
	public static final int CANVAS_WIDTH = CELL_SIZE*COL;
	public static final int CANVAS_HEIGHT=CELL_SIZE * ROW;
	public static final int GRID_WIDTH = 8;
	public static final int GRID_HALF = GRID_WIDTH/2;
	public static final int CELL_PADDING = CELL_SIZE/6;
	public static final int SYMBOL_SIZE = CELL_SIZE -CELL_PADDING*2;
	public static final int SYMBOL_STROKE = 8;
	
	
	public enum GameState {PLAYING,DRAW, O_WIN,X_WIN}
	private GameState currentState;
	
	public enum seed {EMPTY, X,O}
	private seed currentPlayer;
	
	private seed[][] board;
	private DrawCanvas canvas;
	private JLabel statusbar;
	
	//constructor
	public tivtactoe()
	{
		canvas = new DrawCanvas();
		canvas.setPreferredSize(new Dimension(CANVAS_WIDTH,CANVAS_HEIGHT));
		
		canvas.addMouseListener(new MouseAdapter() {
			
			public void mouseClicked(MouseEvent e)
			{
				int mouseX = e.getX();
				int mouseY = e.getY();
				
				int rowselected = mouseY/CELL_SIZE;
				int colselected = mouseX/CELL_SIZE;
				
				if(currentState == GameState.PLAYING)
				{
					if(rowselected >=0 && rowselected < ROW && 
						colselected >=0 && colselected < COL
						&& board[rowselected][colselected]==seed.EMPTY)
					{
						board[rowselected][colselected]= currentPlayer;
						updateGame(currentPlayer,rowselected,colselected);
						currentPlayer= (currentPlayer == seed.X) ? seed.O : seed.X;
					}
				}
				else
					{
						initGame();
					}
					repaint();
				}
			}		
				);
		statusbar = new JLabel(" ");
		statusbar.setFont(new Font(Font.DIALOG_INPUT,Font.BOLD,15));
		statusbar.setBorder(BorderFactory.createEmptyBorder(2,5,4,5));
		
		Container cp = getContentPane();
		cp.setLayout(new BorderLayout());
		cp.add(canvas, BorderLayout.CENTER);
		cp.add(statusbar, BorderLayout.PAGE_END);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		pack();
		setTitle("tic tac toe =D ");
		setVisible(true);
		board = new seed[ROW][COL];
		initGame();		
	}//end constructor
	
	
	public void initGame()
	{
		for(int row =0;row< ROW;row++)
		{
			for(int col=0; col<COL;col++)
			{
				board[row][col]=seed.EMPTY;
			}
		}
		currentState = GameState.PLAYING;
		currentPlayer=seed.X;
	}
	
	public void updateGame(seed theSeed,int rowselected,int colselected)
	{
		if(hasWon(theSeed,rowselected,colselected))
		{
	    currentState=(theSeed==seed.X) ? GameState.X_WIN : GameState.O_WIN;
		}
		else if (isDraw())
		{
			currentState=GameState.DRAW;
		}
	}
	public boolean isDraw()
	{
		for(int row =0; row < ROW; row++)
		{
			for(int col =0; col<COL;col++)
			{
				if(board[row][col]== seed.EMPTY)
					return false;
			}
		}
		return true;
	}
	
	public boolean hasWon(seed theseed,int rowselected,int colselected)
	{
		return( 
				board[rowselected][0] == theseed // 3 in a row
			&&  board[rowselected][1] == theseed
			&&  board[rowselected][2] == theseed
			
 			||	
				board[0][colselected] == theseed // 3 in a column
			&&  board[1][colselected] == theseed
			&&  board[2][colselected] == theseed
			
			||
				rowselected == colselected // 3 in the diagonal
			&& board[0][0] == theseed
			&& board[1][1] == theseed
			&& board[2][2] == theseed
			
			||
				rowselected + colselected == 2 // 3 in the opposite 
			&& board[0][2] == theseed		  // diagonal
			&& board[1][1] == theseed
			&& board[2][0] == theseed
			
				);
	}
	
	class DrawCanvas extends JPanel
	{
		public void paintComponent(Graphics g)
		{
			super.paintComponent(g);
			setBackground(Color.GREEN);
			 
			//gird colors
			g.setColor(Color.DARK_GRAY);
			
			for(int row =1;row<ROW;row++)
			{
				g.fillRoundRect(0, CELL_SIZE*row-GRID_HALF,
						CANVAS_WIDTH-1, GRID_WIDTH, 
						   GRID_WIDTH, GRID_WIDTH);
			}
			for (int col=1;col<COL;col++)
			{
				g.fillRoundRect(CELL_SIZE*col-GRID_HALF,
								0,GRID_WIDTH, CANVAS_HEIGHT-1,
								GRID_WIDTH,GRID_WIDTH);
			}
			
			Graphics2D g2 = (Graphics2D)g;
			g2.setStroke(new BasicStroke(SYMBOL_STROKE,BasicStroke.CAP_ROUND,
					BasicStroke.JOIN_ROUND));
			for(int row=0;row<ROW;row++)
			{
				for(int col=0;col<COL;col++)
				{
					int x1 = col*CELL_SIZE+CELL_PADDING;
					int y1 = row*CELL_SIZE+CELL_PADDING;
					if(board[row][col] == seed.X)
					{
						g2.setColor(Color.BLACK);
						int x2 =(col+1) *CELL_SIZE-CELL_PADDING;
						int y2 =(row+1) *CELL_SIZE-CELL_PADDING;
						g2.drawLine(x1, y1, x2, y2);
						g2.drawLine(x2, y1, x1, y2);
					}
					else if(board[row][col]== seed.O)
					{
						g2.setColor(Color.RED);
						g2.drawOval(x1, y1, SYMBOL_SIZE, SYMBOL_SIZE);
					}
					
				}
			}
			if(currentState == GameState.PLAYING)
			{
				statusbar.setForeground(Color.BLUE);
				if(currentPlayer == seed.X)
				{
					statusbar.setText("IT IS X'S TURN =D");
				}
				else
				{
					statusbar.setText("O! IT IS YOUR TURN ^_^");
				}
			}
			else if(currentState == GameState.DRAW)
			{
				statusbar.setForeground(Color.red);
				statusbar.setText("IT IS A TIE! NO ONE WINS OR LOSES, play again??");
			}
			else if(currentState == GameState.X_WIN)
			{
				statusbar.setText("X WINS! YOU ARE THE BEST EVER");
			}
			else if(currentState == GameState.O_WIN)
			{
				statusbar.setText("O WINS! YOU GET 500000 DOLLARS! WOOO");
			}
		}
	}
	public static void main(String[] args)
	{
		SwingUtilities.invokeLater(new Runnable() 
		{
			public void run()
			{
				new tivtactoe();
			}
		});
	}
	
	

}
	