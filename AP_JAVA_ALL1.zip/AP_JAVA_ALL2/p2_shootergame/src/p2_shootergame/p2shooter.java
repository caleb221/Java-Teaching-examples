/*
 * Caleb Seifert
 * 12/20/16
 * Shooter game 
 */
package p2_shootergame;

import java.awt.event.*;
import java.awt.*;
import javax.swing.*;

public class p2shooter extends JPanel
{
	//fields 
	private Timer timer; // give us a timer!
	
	private int height,width;// how long/tall is our frame?
	
	private Player player;//object for the player
	private Enemy enemy;
	private Bomb bomb;

	
	//constructor
	public p2shooter()
	{
		setBackground(Color.BLUE);
	    ActionListener action = new ActionListener()
	    		{
	    			public void actionPerformed(ActionEvent e)
	    			{
	    				if(player != null)
	    				{
	    					player.updateFornewFrame();
	    					bomb.updateFornewFrame();
	    					enemy.updateFornewFrame();
	    				
	    				}
	    				repaint();
	    			}
	    		};
		timer = new Timer(30,action);
		
		addMouseListener(new MouseAdapter() 
			{	
				public void mousePressed(MouseEvent e)
				{
					requestFocus();
				}
			});
		
		addFocusListener(new FocusListener()
							{
								public void focusGained(FocusEvent e)
								{
									timer.start();//start the time when user gains focus
									repaint();//repaint the panel
								}
								public void focusLost(FocusEvent e)
								{
									timer.stop();//when user loses focus, stop the game
									repaint();
								}
							}
						);
		addKeyListener(new KeyAdapter()
			{
				public void keyPressed(KeyEvent e)
				{
					int pressedkey = e.getKeyCode();//key that has been pressed
					
					if(pressedkey == KeyEvent.VK_LEFT)
					{
						player.centerX -= 15;//move the player 15 pixels left
					}
					else if(pressedkey == KeyEvent.VK_RIGHT)
					{
						player.centerX += 15;//move player 15 pixels right
					}
					else if(pressedkey == KeyEvent.VK_DOWN)
					{
						

						player.centerY+=15;
					}
					else if(pressedkey == KeyEvent.VK_UP)
					{
						player.centerY-=15;
					}
					else if(pressedkey == KeyEvent.VK_SPACE)
					{
						//if the bomb is not already falling
						  if(bomb.isFalling == false)
							//make the bomb fall (shoot)
							bomb.isFalling = true;
					}
					
				}
			});
		
	}//end of main constructor
	
	private class Player 
	{
		//fields
		int centerX,centerY;
		//constructor
		Player()
		{	
			centerX=width/2;
			centerY=80;
		}
		void updateFornewFrame()
		{
			if(centerX<0 || centerY <0) //make sure we are still in the panel
			{
				centerX = 0;
				centerY=0;
			}
			else if(centerX > width || centerY >height) // other side of panel
			{
				centerY=height/2;
				centerX=width;
			}
		}
		void draw(Graphics g)//draw our player, hes just a round ball right now =\
		{
			g.setColor(Color.ORANGE);
			g.fillRoundRect(centerX-40, centerY-20, 80, 40, 20, 20);
			g.setColor(Color.black);
			g.setFont(new Font("Helvetica",Font.BOLD,25));
			g.drawString("��", centerX-15, centerY+5);
			
		}
	}//end player class
	
	private class Bomb
	{
		//fields
		int centerX,centerY;
		boolean isFalling;
		
		//constructor
		Bomb()
		{
			isFalling = false;
		}
		void updateFornewFrame()
		{
			if(isFalling == true)
			{
				if(centerY > height)
				{
					isFalling = false;
				}
				else if(Math.abs(centerX-enemy.centerX) <= 36 
						&& Math.abs(centerY-enemy.centerY) <= 21)
				{
					enemy.isExploding = true;
					enemy.explosionFrameNumber =1;
					isFalling = false;
				}
				else
				{
					centerY += 10;
				}
			}
		}
		void draw(Graphics g)
		{
			if(isFalling == false)
			{
				centerX=player.centerX;
				centerY=player.centerY+21;
			}
			g.setColor(Color.white);
			g.fillOval(centerX-8, centerY-8, 16, 16);
			g.setColor(Color.red);
			g.fillOval(centerX-4, centerY-4, 8, 8);
		}
	}//end of bomb class
	
	private class Enemy
	{
		//fields
		int centerX,centerY;
		boolean isMovingLeft,isMovingup;
		boolean isExploding;
		int explosionFrameNumber;
		
		//constructor
		Enemy()
		{
			centerX=(int)(width*Math.random());
			centerY=height-40;
			isExploding = false;
			isMovingLeft = (Math.random() < 0.5);
			isMovingup = (Math.random() < 0.2);
		}//end of enemy constructor
		
		void updateFornewFrame()
		{
			if(isExploding == true)
			{
				explosionFrameNumber++;
				if(explosionFrameNumber == 15)
				{
					centerX=(int)(Math.random()*width);
					centerY=height-40;
					isExploding = false;
					isMovingLeft= (Math.random() < 0.4);
					isMovingup = (Math.random() < 0.4);
				}
			}
			else
			{
				if(Math.random() < 0.04)//25% chance of happening
				{
					isMovingLeft = !isMovingLeft;
				}
				if(Math.random() < 0.04)//25% chance of happening
				{
					isMovingup = !isMovingup;
				}
				if(isMovingLeft || isMovingup)
				{
					centerX -= 5;
					centerY -=5;
					if(centerX<=0)
					{
						centerX=0;
						isMovingLeft = false;	
					}
					else if(centerY <=0)
					{
						centerY=width;
						isMovingup = true;
					}
				}
				else
				{
					centerX +=5;
					centerY +=5;
					if(centerX > width)
					{
						centerX=width;
						isMovingLeft = true;
					}
					else if(centerY > height)
					{
						isMovingup=false;
						centerY=height;
					}
				}
				
			}
		}//end updateFornewFrame
		void draw(Graphics g)
		{
			//g.setColor(Color.green);
			//g.fillOval(centerX-30, centerY-15, 60, 30);
			g.setColor(Color.green);
			g.fillOval(centerX-20, centerY-20, 40, 40);
			g.setColor(Color.red);
			g.fillOval(centerX-12, centerY-13, 15, 15);
			g.fillOval(centerX+5, centerY-13, 15, 15);
			g.drawLine(centerX-12, centerY-20, centerX+15, centerY+20);
			
			if(isExploding == true)
			{
				g.setColor(Color.YELLOW);
				g.fillOval(centerX-4*explosionFrameNumber
							,centerY-2*explosionFrameNumber
							,8*explosionFrameNumber
							,4*explosionFrameNumber);
				
				g.setColor(Color.red);
				g.fillOval(centerX-2*explosionFrameNumber
							, centerY-explosionFrameNumber/2
							, 4*explosionFrameNumber
							, explosionFrameNumber);
			}
		}//end of draw
		
	}//end of enemy class
	
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		
		Graphics2D g2 = (Graphics2D)g;
		g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, 
								RenderingHints.VALUE_ANTIALIAS_ON);
		if(player == null)
		{
			width=getWidth();
			height=getHeight();
			player = new Player();
			bomb = new Bomb();
			enemy = new Enemy();
		}
		if(hasFocus())
		{
			g.setColor(Color.red);
		}
		else
		{
			g.setColor(Color.magenta);
			g.drawString("CLICK ON ME TO PLAY A GAME!", 20, 30);
			g.setColor(Color.DARK_GRAY);
		}
		g.drawRect(0,0,width-1,height-1);
		g.drawRect(1,1,width-3,height-3);
		g.drawRect(2, 2, width-5, height-5);
		
		player.draw(g);
		enemy.draw(g);
		bomb.draw(g);
		
		Font f = new Font("Helvetica",Font.BOLD,20);
		g.setFont(f);
		g.setColor(Color.CYAN);
		g.drawString("Arrow Keys for movement, Spacebar to shoot", 20, 30);	
	}
	public static void main(String[] args)
	{
		JFrame frame = new JFrame("THE COOLEST GAME EVAARR!!");
		p2shooter app = new p2shooter();
		
		frame.setContentPane(app);
		frame.setSize(600,480);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocation(100, 100);
		frame.setResizable(false);
		frame.setVisible(true);
	}
	
}// end of main class







