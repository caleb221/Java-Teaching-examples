/*
 * Caleb Seifert
 * 1/1/16
 * Switch Statements
 */

package switch_statement;
import java.util.Scanner;

public class switches_not_stiches
{
	public static void main(String[] args)
	{
		Scanner keys = new Scanner(System.in);
		int input =0;
		System.out.println("Hello! please pick a number 1-10");
		input=keys.nextInt();
		
		switch(input)
		{
			case 1: System.out.println("Hello, 1 is an alright number"); 
				break;
			case 2: System.out.println("2 is cool");
				break;
			case 3: System.out.println("3 is a prime number");
				break;
			case 4: System.out.println("4 is almost 5");
				break;
			case 5: System.out.println("5! its half of 10 =) ");
				break;
			case 6: System.out.println("did you know 3 + 3 is 6? ");
				break;
			case 7: System.out.println("7 is an odd number");
				break;
			case 8: System.out.println("crazy 8s ");
				break;
			case 9: System.out.println(" 9 is 10-1");
				break;
			case 10: System.out.println("10 is the highest number you could have chosen!");
				break;
			default: System.out.println("THAT WAS NOT 1-10 >=( ");
				break;
		}
	}
}
