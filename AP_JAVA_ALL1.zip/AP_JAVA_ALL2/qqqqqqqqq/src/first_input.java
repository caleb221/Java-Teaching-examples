/*
 * INPUT!!
 * lets take in a number from the keyboard
 */
import java.util.*;

public class first_input 
{
	public static void main(String[] args)
	{
		//this is the keyboard variable! it lets us use the keyboard
		Scanner keyboard = new Scanner(System.in);
		
		//our number we will take from the user
		int number_input =0;
		
		System.out.println("hello! please input a number:");
		//set our number_input equal to the keyboards next input
		
		number_input = keyboard.nextInt();
		//number_input is now the number we typed in
		//Note: we MUST input an int (whole number) type
		//because that is what our computer expects (needs)
		System.out.println("your number is: "+number_input+" =)");
	}

}
