/*
 * Caleb Seifert
 * 10/19/16
 * Strings
 */
public class string_ex 
{	
	public static void main(String[] args)
	{
		String name = "Hello";
		String input;
		char c = 'c';
		System.out.println(c);
		System.out.println(name+"\n");

		for(int i =0; i<name.length();i++)
			{
				System.out.println(name.charAt(i));
			}
	}
}