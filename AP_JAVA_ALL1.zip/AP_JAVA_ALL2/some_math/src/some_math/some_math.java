/*
 * Caleb Seifert
 * 10/20/16
 * Math and modulus
 */
package some_math;
import java.util.Scanner;
public class some_math 
{
	public static void main(String[] args)
	{
		Scanner keys = new Scanner(System.in);
		int two =2;
		int three = 3;
		int input =0;
		int ans =0;
		
		for (int i=1;i<11;i++)
			{
				ans = two %i; // modulus returns the remainder of division
				System.out.println("2 % "+i+" = "+ans);
				ans = three % i; 
				System.out.println("3 % "+i+" = "+ans);
			}
		System.out.println("Awesome! Lets take a square root, pick a number\n:");
		input = keys.nextInt();
		ans =(int) Math.sqrt(input);
		System.out.println("Your square root is:  "+ans);
	}

}
