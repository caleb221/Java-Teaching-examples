/*
 * Caleb Seifert
 * THE SUNRISE (a bit more on graphics)
 * 11/10/16
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class THESUN extends JPanel implements ActionListener
{
	//here we can put the field (variables that can be used in all classes)
	private int time;
	
	public THESUN() // constructor
	{
		time=0;
		Timer clock = new Timer(30,this); // gives us a timer in java
		clock.start();
	}
	public void paintComponent(Graphics g)
	{
		int x = 350 - (int)(50*Math.cos(0.005*Math.PI*time));
		int y = (int) (330-(int) 502*Math.sin(0.005*Math.PI*time));
		int r =30;
		
		Color sky;
		if(y>getSize().height/2)
		{
			sky= Color.orange;
		}
		else
		{
			sky = Color.getHSBColor(1.2F, 1.0F, .755F);
		}
		setBackground(sky);
		super.paintComponent(g);
		g.setColor(Color.red);
		g.fillRect(x-r, y-r, r*2, r*2);
		g.setColor(Color.orange);
		int r2= r-10;
		Font f = new Font("SansSerif",Font.BOLD,35);
		Graphics2D g2 = (Graphics2D)g;
		g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, 
				RenderingHints.VALUE_ANTIALIAS_ON);
		g.fillRect(x-r2, y-r2, r2*2, r2*2);
		g.setFont(f);
		g.setColor(Color.cyan);
		g.drawString("ţ��", x-r2*5,y-r2/4);
	}
	public void actionPerformed(ActionEvent e)
	{
		time++;
		repaint();
	}
	public static void main(String[] args)
	{
		JFrame frame = new JFrame("LOOK AT THIS SUN!");
		frame.setSize(700, 450);
		
		Container c = frame.getContentPane();
		c.add(new THESUN());
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setResizable(false);
		frame.setVisible(true);
	}
}






//System.out.println("I love John very much and also Freddy and MR Seifer love you too ")
//I love John very much and also Freddy and MR Seifer Iove you too Jay sencerely Jay