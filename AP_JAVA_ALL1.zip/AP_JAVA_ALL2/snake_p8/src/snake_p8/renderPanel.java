package snake_p8;
/*
 * SNAKE GRAPHICS!!!!
 */

import java.awt.*;
import java.awt.image.*;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.*;

public class renderPanel extends JPanel
{
	//fields
	public BufferedImage image;
	public static final Color DARKGREEN = new Color(166073);
	
	
	public renderPanel()
	{

		try{
				image=ImageIO.read(new File("rainbowbunchie.jpg"));
			}
		catch(IOException e)
		{
			System.out.println("this is the error:\n"+e);
		}
	}
	public Dimension getPreferredSize()
	{
		if(image==null)
		{
			return new Dimension(100,100);
		}
		else
		{
			return new Dimension(image.getWidth(null)
					,image.getHeight(null));
		}
	}
	
	
	
	
	
	protected void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		
		Snake snake1 = Snake.snakeObj;
		g.drawImage(image, 0, 0, null);
		g.setColor(DARKGREEN);
	//	g.fillRect(0, image.getHeight(), 800, 700);
	//	g.fillRect(image.getWidth(), 1, image.getWidth(),image.getHeight() );
		g.setColor(Color.PINK);
		for(Point p : snake1.snakeParts)
		{
			g.fillRect(p.x*snake1.SCALE, p.y*snake1.SCALE,
					snake1.SCALE,snake1.SCALE);
		}
		
		//to change the snake head color, just set a new color 
		
		g.fillRect(snake1.head.x*snake1.SCALE,snake1.head.y*snake1.SCALE
						,snake1.SCALE, snake1.SCALE);
		g.setFont(new Font("SansSerif",Font.BOLD,14));
		g.setColor(Color.red);
		
		
		g.setColor(Color.BLACK);//snake food color
		
		g.fillOval(snake1.food.x*snake1.SCALE, snake1.food.y*snake1.SCALE, 
								snake1.SCALE, snake1.SCALE);
		String str = "Score: "+snake1.score+" Length: "+snake1.tailLength
									+" Time: "+snake1.time/20;
		g.setColor(Color.white);//text color
		
		g.drawString(str, (int)(getWidth()/2-str.length()*2.5f), 10);
		
		str = "Game over! you killed the snake ='(";
		if(snake1.over)
		{
			g.drawString(str, (int)(getWidth()/2-str.length()*2.5f),
						(int)snake1.dim.getHeight()/4);
		}
		str = "you have paused the game, the snake is sleeping...press"
				+"the space bar to wake him up and keep eating!";
		
		if(snake1.paused && !snake1.over)
		{
			g.drawString(str, (int)(getWidth()/2-str.length()*2.5f),
					(int)snake1.dim.getHeight()/4);
		}
	}
}





