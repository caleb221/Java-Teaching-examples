/*
 * lets try and load an image!
 */

package snake_p8;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;
import java.awt.image.*;
import javax.imageio.*;


public class loadmyimage extends Component
{
	//fields
	
	BufferedImage image;
	/*
	 * buffered image is a special data type from java.awt.image
	 * it will buffer (load) an image from the project file
	 * and we will be able to use it as an object
	 */

	public void paint(Graphics g)
	{
		g.drawImage(image, 0, 0, null);
		//paint our image onto the panel
		
	}
	public loadmyimage()
	{
		/*
		 * in order to obtain the image, we need to load it into memory
		 * from the project file, to do this we need to use the 
		 * try{}
		 * and catch(){}
		 * methods, they first try the code inside '{}' and if it does
		 * not execute correctly, there will be an exception error (e)
		 * this helps us to avoid exception errors while we run our code
		 * without the try and catch we run a risk of running into
		 * an error and the program failing during runtime
		 */
		try{
			/*
			 * we need to be EXACTLY CLEAR when we write filepaths
			 * the computer does not have any thoughts, so it does not
			 * go looking for the file it thinks you want...
			 * this is why we have catch(){}
			 * 
			 */
			image=ImageIO.read(new File("rainbowbunchie.jpg"));
		}
		catch(IOException e)
		{
		/*
		 * if the above code in try fails and gives an error, we catch it
		 * here..
		 * note the System.out.println(e); is not necessary, but without it
		 * we would not know what error occured  
		 */
			System.out.println("this is the error:\n"+e);
		}
	}
	public Dimension getPreferredSize()
	{
		if(image==null)
		{
			// just incase java doesnt find our image
			return new Dimension(100,100);
		}
		else
		{
			//get the size of our picture!
			return new Dimension(image.getWidth(null)
					,image.getHeight(null));
		}
	}
	
	public static void main(String[] args)
	{
		JFrame frame = new JFrame("THIS IS MY PICTURE GUYS!! ^_^");

		frame.addWindowListener(new WindowAdapter()
				{
					public void WindowClosing(WindowEvent e)
					{
						System.exit(0);
					}
				});
		frame.add(new loadmyimage());//our class!
		frame.pack();//make it all fit!
		frame.setVisible(true);//show me my picture!
	}
}





