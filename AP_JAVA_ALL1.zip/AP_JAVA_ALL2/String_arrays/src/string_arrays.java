/* 
 * Caleb Seifert
 * 10/26/16
 * String arrays
 * 
 */

import java.util.*;

public class string_arrays 
{
	public static void main(String[] args)
	{
		Scanner keys = new Scanner(System.in);
		
		 Random randomclass = new Random();
		 int randomnum=randomclass.nextInt(2);
		 
		String[] greetings = {"hello ","if i was another person i would not "
				+ "want to be ", "the coolest person is "};
		String[] people= new String[3];
		System.out.println("Hello!\n who are three of your good friends? ");
		
		for (int i=0; i<people.length;i++)
		{
			people[i] = keys.nextLine();
			System.out.println("Cool! \n you have entered "+i+1+" out of 3 friends");
		}
		
		for(int n=0; n<people.length;n++)
		{
			System.out.println(greetings[randomnum]+" "+people[randomnum]);
			randomnum=randomclass.nextInt(2)+1;
		}
		
	}

}
