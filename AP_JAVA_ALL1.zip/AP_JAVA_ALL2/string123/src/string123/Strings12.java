package string123;
import java.util.Scanner;
public class Strings12 
{
	public static void main(String[] args)
	{
		Scanner keys= new Scanner(System.in);
		
		String s = "Hello!";//declare a string
		String name= "caleb";
		String input;//also declare a string
		
		char c = 'c';// single letters are characters
		
		System.out.println("Hello!, what is your name?");
		
		input = keys.nextLine();// get the string from the keyboard
		
		// boolean means it can be true or false, nothing else
		boolean check = name.equalsIgnoreCase(name);
		
		if(check == true)// true is a reserved word
		{
			System.out.println("Hello! welcome home!");
		}
		else// if the check is false (not true)
		{
			System.out.println("This is not your computer! leave, or it will blow up");
		}
	/*	
		for(int i=0; i<name.length();i++)
		{
			System.out.println(name.charAt(i));
			
		}
	*/
		
		
	}
}
