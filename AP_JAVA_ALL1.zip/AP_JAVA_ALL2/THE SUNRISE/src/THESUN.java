/*
 * Caleb seifert
 * 11/10/16
 * a bit more graphics, THE SUNRISE/sunset
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class THESUN extends JPanel implements ActionListener
{
	private int time;
	JButton btn = new JButton("wut");
	
	
	public THESUN()
	{
		btn.addActionListener(this);
		add(btn);
		
		Timer clock = new Timer(30,this);
		clock.start();
		time=5;
	}
	
	public void paintComponent(Graphics g)
	{
		int x =150-(int)(100*Math.cos(0.005*Math.PI*time));
		int y = (int)(130-(int)75*(Math.sin(0.005*Math.PI*time)));
		int r = 30;
		Color sky;
		
		if(y>130)
		{
			sky= Color.black;
		}
		else
		{
			sky=Color.blue;
		}
		setBackground(sky);
		
		super.paintComponent(g);
	
		g.setColor(Color.red);
		g.fillOval(x-r,	 y-r, r*2, r*2);
		
		int r2 = r-10;
		Font f = new Font("SansSerif",Font.BOLD,55);
		Graphics2D g2 = (Graphics2D)g;
		g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_ON);
		g.setFont(f);
		g.setColor(Color.ORANGE);
		g.fillOval(x/2-r2, y-r2,r2*2,r2*2);
		g.setColor(Color.white);
		g.drawString("ţ��", x-r2, (y-r2)+x/2);

	}
	
	public void actionPerformed(ActionEvent e)
	{
		time++;
		repaint();
		if(e.getSource() == btn)
		{ 
			JOptionPane.showMessageDialog(this,"what up");
			JFrame frame = new JFrame("LOOK AT THIS SUNRISE!");
			frame.setSize(300, 150);
			
			Container c = frame.getContentPane();
			c.add(new THESUN());
			frame.setLocationRelativeTo(getParent());
			frame.setResizable(true);
			frame.setVisible(true);
		}
	}
	
	
	public static void main(String[] args)
	{
		JFrame frame = new JFrame("LOOK AT THIS SUNRISE!");
		frame.setSize(300, 150);
		
		Container c = frame.getContentPane();
		c.add(new THESUN());
		frame.setResizable(true);
		frame.setVisible(true);
	}
}
