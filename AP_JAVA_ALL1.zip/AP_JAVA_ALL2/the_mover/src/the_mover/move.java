/*
 * Caleb Seifert
 * 11/23/16
 * moving stuffs
 */
package the_mover;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class move extends JPanel // we create a panel object without the
								// need to reference it
{
	// fields
	int x; // X position (pixels) 
	int y; // Y Position (pixels)
	int x2;// X2 for change in X (pixels)
	int y2;// Y2 for change in Y (pixels)
	
	JTextField fld1 = new JTextField(5); // text field to show the 
										// key that is being typed
	
	//JButton btn = new JButton("CLICK ME!");
	
	//constructor
	public move()
	{
		keys keypress = new keys();  // create the key listener object
									//  in the constructor
		fld1.addKeyListener(keypress); // connecting the key listener
									  //  to the text field
		fld1.setEditable(false);// no user input is needed
		
		setLayout(new FlowLayout()); // make the panel
		add(fld1);
		setBackground(Color.gray);
	}
	
	public void paint(Graphics g) // paint is a component in JPanel
	{
		super.paintComponent(g); // gets any graphics that were set before
								// the paint component and uses them
							   //  here, we have set the background, so it keeps that value
		Font f = new Font("SansSerif",Font.BOLD,40);
		g.setFont(f);
		g.setColor(Color.CYAN);
		x = this.getWidth()/2; // X center of panel (pixels)
		y=this.getHeight()/2; //  Y center of panel (pixels)
		g.setColor(Color.yellow); // draw the happy-ish face
		g.fillOval(x+30-x2, y+30-y2, 40, 40); 
		g.setColor(Color.BLACK);
		g.fillOval(x-x2+35, y-y2+35, 15, 15);
		g.fillOval(x-x2+55, y-y2+35, 15, 15);
		g.drawLine(x-x2+35, y-y2+55, x-x2+50, y-y2+55);
	}


	public class keys implements KeyListener // key listener is like action listener
											// but for the keyboard
	{

		@Override
		public void keyPressed(KeyEvent arg0) {
			// needed for the key listener class
			// when the user presses a key, the actions in this method take place
			//example:
			//in a racing game, when we press the gas button, the vehicle should 
			// go faster or move in a direction
		}

		@Override
		public void keyReleased(KeyEvent arg0) {
			// needed for the key listener class
			// when the user releases a key this method takes place
			// example:
			// in that same racing game, when the user stops pressing the gas
			// the vehicle should slow down or something
			//that action would take place here
			
		}

		@Override
		public void keyTyped(KeyEvent e) 
		{
			// needed for the key listener class  
			char pressed = e.getKeyChar(); // get the character the user typed
			fld1.setText(""+pressed); // shows the user the typed key
			if(pressed == 'w') // if the user presses 'w' (different than 'W') do:
			{
				y2 +=5; // same as y2=y2+5
				repaint();// repaints the whole panel every time the user presses
						 // the key 
			}
			if(pressed == 's')
			{
				y2 -=5;
				repaint();
			}			
			if(pressed == 'a')
			{
				x2 +=5;
				repaint();
			}
			if(pressed == 'd')
			{
				x2 -=5;
				repaint();
			}
		}
	}

	public static void main(String[] args)
	{
		move app = new move();
		JFrame frame = new JFrame("MOVE!");
		frame.setContentPane(app);
		frame.setSize(250,250);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
}






