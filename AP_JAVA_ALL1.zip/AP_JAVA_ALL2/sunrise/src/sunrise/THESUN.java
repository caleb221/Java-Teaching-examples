/*
 * Caleb Seifert
 * 11/10/16
 * a bit more on graphics, motion!
 */
package sunrise;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

// extends --> we are now using a subclass
//implements --> means we are going to use a piece of a super class
public class THESUN extends JPanel implements ActionListener
{
	private int time; // time keeps moving on
	
	public THESUN()
	{
		time =0; //time starts at 0
		Timer clock = new Timer(30,this); // set up a timer, name it clock
		clock.start(); // start the timer
	}
	
	public void paintComponent(Graphics g) // part of JPanel, paintComponent helps us
										  // use graphics
	{
		int x = 150 -(int)(100*Math.cos(0.005*Math.PI*time)); // draw an arc on X
		int y = (int)(130-(int) 75*Math.sin(0.005*Math.PI*time));// draw an arc on Y
		int radius = 40; // the size of the sun 0_0
		Color sky; // color the sky!
		
		if(y > 130) // at the end of the program, change the background to black
		{
			sky = Color.BLACK;
		}
		else
		{
			sky = Color.BLUE; // make the sky blue!
		}
		setBackground(sky);// add the color to the panel
		super.paintComponent(g); //grab paintComponent from JPanel (the superclass)
		
		g.setColor(Color.red); // color the sun
		// we want the sun to move based on X and Y, so we move it (mathematically)
		// by using the (x,y) coordinates and tracing the sun onto it as follows
		g.fillOval(x-radius, y-radius, 2*radius, 2*radius);
		g.setColor(Color.ORANGE);
		int radius2=radius-10;
		g.fillOval(x-radius2, y-radius2, 2*radius2, 2*radius2);
		Font newfont = new Font("SansSerif",Font.BOLD,15);
		g.setFont(newfont);
		g.setColor(Color.red);
		g.drawString("���!!", x-radius/3, y-radius/50);
		// remember, x changes with time, so does y, but radius doesnt, so the size
		//will be the same, but the position will not
	}
	
	public void actionPerformed(ActionEvent e)
	{
		time++; // add some time
		repaint(); // paint the sun over and over again 0_0
	}
	
	public static void main(String[] args)
	{
		JFrame frame = new JFrame("THE SUN!"); // create a frame
		frame.setSize(300, 150); // set the size (size matters on this program because
								// of the X and Y)
		Container contained = frame.getContentPane(); // set up a container so that 
													 // we can refresh the painted panel
													// that we have made
		contained.add(new THESUN()); // add the panel to the frame
	
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setResizable(false); // the user is no longer able to change the window size
		frame.setVisible(true);// SHOW ME THE PROGRAM!
	}
}
