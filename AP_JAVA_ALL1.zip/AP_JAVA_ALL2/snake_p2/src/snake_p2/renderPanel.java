/*
 * Caleb Seifert
 * Snake Graphics
 */
package snake_p2;

import javax.swing.JPanel;
import java.awt.*;

//the snake graphics class

public class renderPanel extends JPanel 
{
	//fields
	public static final Color GREEN = new Color(1666073);
	//background color (dark green) you can change it if you want!
	protected void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		
		g.setColor(GREEN);//background color, change if you want
		g.fillRect(0, 0, 800, 700);
		
		g.setColor(Color.orange);//snake color
		
		snake snake1 = snake.snakeObj;
		
		for(Point p : snake1.snakeParts)
		{
			g.fillRect(p.x*snake1.SCALE, p.y*snake1.SCALE, 
									snake1.SCALE, snake1.SCALE);
		}
		g.setColor(Color.GREEN);
		g.fillRect(snake1.head.x*snake1.SCALE,snake1.head.y*snake1.SCALE
							, snake1.SCALE, snake1.SCALE);
		
		g.setColor(Color.BLACK);//snake food color
		g.fillRect(snake1.mouse.x*snake1.SCALE, snake1.mouse.y*snake1.SCALE,
								snake1.SCALE,snake1.SCALE);
		
		//lets let the user know their score and stuff!
		String str = "Score:  "+snake1.score+" length: "
							+snake1.tailLength+"  Time:"+snake1.time/20;
		g.setColor(Color.lightGray);//text color
		
		g.drawString(str, (int)(getWidth()/2-str.length()*2.5F), 10);
	
		str = "Game Over, you killed the snake =,(";
		if(snake1.over)
		{
			g.drawString(str, (int)(getWidth()/2-str.length()*2.5F),
					(int)snake1.dim.getHeight()/4);
		}
		str="Game Paused, press the spacebar to resume";
		if(snake1.paused && !snake1.over)
		{	
			g.drawString(str, (int)(getWidth()/2-str.length()*2.5F),
				(int)snake1.dim.getHeight()/4);
		}	
	}
}
