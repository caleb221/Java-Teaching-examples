/*
 * Caleb seifert
 * 10/19/16
 * Strings
 * 
 */
import java.util.Scanner;

public class string_1 
{
	public static void main(String[] args)
	{
		Scanner keys = new Scanner(System.in);
			char c = 'h';//single piece of text
		String name ="caleb"; // text held in an array (boxes inside the computer)
		String input;
		
		System.out.println("Hello! What is your name?");
		input=keys.nextLine();
		int check = name.compareTo(input);
	
		if(check == 0)
			{
				System.out.println("Welcome " +name+"!!! this is your computer");
			}
		else
			{
				System.out.println("This is not your computer, please go away");
			}		
	}
}
