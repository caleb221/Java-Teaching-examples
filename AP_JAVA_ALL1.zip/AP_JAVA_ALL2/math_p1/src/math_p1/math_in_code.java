/*
 * Caleb Seifert
 * Math in code!
 */
package math_p1;

/*
 * variables are pieces of data that we can change in our code
 */

public class math_in_code 
{
	public static void main(String[] args)
	{
		/*
		 * computers are great with math! lets have a look
		 */
		int mynumber =0;//create an int variable named mynumber
		int answer =0; // create an int variable for the answer
		
		mynumber =5; //set the variable equal to 5 (it has now been changed)
		answer = mynumber +5;//add 5 to mynumber
		//we want to tell the user that something is happening in our code
		System.out.println("hello! your addition (+) is :"+answer); 
		
		answer = mynumber - 4;//change the answer variable
		System.out.println("Your subtraction (-) is: "+answer);
		
		answer = mynumber * 54655;//multiply mynumber by a large number
		System.out.println("your multiplication (*) is: "+answer);
		
		answer = mynumber/2; // this answer is wrong =( it shows up as 2
							 // and not 2.5
		System.out.println("your division (/) is: "+answer);
		
		double num_accurate=0;
		double answer_acc=0;
		/*
		 * a double is a number with a decimal point
		 * it is more accurate than an int
		 * the difference between 1 and 1.0
		 * lets see how to use it!
		 */
		num_accurate =5;
		
		answer_acc = num_accurate/2;// we use them the same way as ints
									// but they are processed different
		System.out.println("your DOUBLE divided (/) is: "+answer_acc);
		
		answer_acc =num_accurate *10.1;//lets multiply by a double!
		System.out.println("your DOUBLE multiplied (*) is:"+answer_acc);
		
		answer_acc = num_accurate % 4;//modulus! this is a math formula
									 // that Divides (/) 2 numbers
									// AND gives back ONLY the remainder
		
		System.out.println("your DOUBLE Modulus (%) is: "+answer_acc);
		
		
		
	}

}
