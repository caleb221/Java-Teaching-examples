/*
 * Caleb Seifert
 * 10/27/16
 * number arrays!
 * 
 */
package num_arrays;

import java.util.Scanner;

public class number_boxes 
{
	public static void main(String[] args)
	{
		Scanner keys = new Scanner(System.in);
		int num[]=new int[55];// create an empty array of unknown size
		
		int number_box[] = {0,0,0,0,0}; // create an array with 5 spaces all = 0
		
		System.out.println(number_box[2]);
		
		number_box[2]=2; // set the 2nd space = 2
		
		System.out.println(number_box[2]+"\n\n");
		
		for(int i=0;i<number_box.length;i++)
		{    
			int n=i;
			number_box[i]=n;
			System.out.println(number_box[i]);
		}
		
		System.out.println("Please pick a number: \n");
		for(int n=0; n<number_box.length;n++)
		{
			number_box[n]=keys.nextInt();
			System.out.println("Please pick another number, you have "+n+"out of 5 left");
		}
		
		for(int i=0;i<number_box.length;i++)
		{    
			number_box[i]=number_box[i]+2;
			System.out.println(number_box[i]);
		}
		
	}
}
