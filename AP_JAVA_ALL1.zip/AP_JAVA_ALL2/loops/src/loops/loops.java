/*
 *Caleb seifert
 *  Loops!
 */
package loops;

import java.util.*;
/*
 * A loop is a circle, when we want the SAME piece of code to be repeated
 * we throw it in a loop ( circle) 
 */

public class loops 
{
	public static void main(String[] args)
	{
		int count =0; 
		int usernum =0;
		Scanner keyboard = new Scanner(System.in);		
		System.out.println("Hello! what number would you like to count up to?");
		usernum = keyboard.nextInt();
		
/*
 * a for loop is a loop that is defined FOR a specific number of repetitions
 * 
 * HOW WE DEFINE A FOR LOOP:
 * for (int i=0; i<number;     i++)   { }
 * ^         ^         ^         ^     ^
 * |         |         |          \    |
 * tell java | we want | a loop   |    |
 *           |create a | variable |that| will count the loops
 *                     |tell the  |loop| how many times to repeat
 * 								  |add | one to the variable after each repetition
 *									   | the code in the loop
 */ 
		for(int i=0;i<10;i++)
		{
			System.out.println("i is: "+i);
		}
		
		for(int i=0;i<usernum;i++)
		{
			System.out.println("user's i is at: "+i);
		}
	}
}
