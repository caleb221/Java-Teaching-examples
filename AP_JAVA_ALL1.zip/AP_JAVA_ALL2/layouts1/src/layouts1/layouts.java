/*
 * caleb seifert
 * 11/28/16
 * layout example
 */
package layouts1;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class layouts extends JPanel implements ActionListener
{
	JButton btn1 = new JButton("change the color!");
	panel2 paneltwo;
	Color bkgcolor;
	
	//main constructor
	public layouts()
	{
		setLayout(null); // we will make the layout by ourselves
		setBackground(Color.DARK_GRAY); // setting the background color
		paneltwo = new panel2();// create the panel 2 object
		add(paneltwo); // add the 2nd panel to the first panel
		btn1.addActionListener(this); // connect the button and action listener
		add(btn1);//add the first button
		
		paneltwo.setBounds(10,10,200,80);
		// set the size and location of the 2nd panel, and button
		//x,y,width,height (pixels)
		btn1.setBounds(25,100,180,30);
	}
	
	public void actionPerformed(ActionEvent e) 
	{
		float hue = (float)Math.random();
		bkgcolor =Color.getHSBColor(hue, 1.0F, 1.0F);
		repaint();
	}
	public class panel2 extends JPanel
	{
		//constructor for 2nd panel
		public panel2()
		{
			setPreferredSize(new Dimension(20,20));
		}
		
		public void paintComponent(Graphics g)
		{
			if(bkgcolor == null)
			{
				g.setColor(Color.ORANGE);
			}
			else
			{
				g.setColor(bkgcolor);
			}
			g.drawRect(0, 0, getSize().width, getSize().height);
			g.drawRect(1, 1, getSize().width-3, getSize().height-3);
			//Font f = new Font("SansSerif",Font.BOLD,15);
		//	g.setFont(f);
			//g.drawString("This is the second panel", 10, 15);
			for (int row =0; row<8;row++)
			{
				for(int column =0; column<8;column++)
				{
					if(row%2 == column%2)
					{
						g.setColor(bkgcolor);
					}
					else
					{
						g.setColor(Color.black);
					}
					g.fillRect(2+column*20, 2+row*20, 20, 20);
				}
			}
			
		}
	}
	
	public static void main(String[] args)
	{
		layouts app = new layouts();
		JFrame frame = new JFrame("hello!");
		frame.setContentPane(app);
		frame.setSize(350,200);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
}
