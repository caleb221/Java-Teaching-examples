package ttttt;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;



public class tivtactoe extends JFrame
{
	public static final int ROW=20; //number of rows we want
	public static final int COL=20;//number of columns we want
	public static final int CELL_SIZE = 100;//how big we want our spaces
	public static final int CANVAS_WIDTH = CELL_SIZE*COL;//how wide we our frame
	public static final int CANVAS_HEIGHT=CELL_SIZE * ROW;//how tall we want our frame
	public static final int GRID_WIDTH = 8;// how many pixels we want the grid to be
	public static final int GRID_HALF = GRID_WIDTH/2;// measurement help
	public static final int CELL_PADDING = CELL_SIZE/6;//how many pixels between (X or O) and the grid
	public static final int SYMBOL_SIZE = CELL_SIZE -CELL_PADDING*2;// how big we want the symbol
	public static final int SYMBOL_STROKE = 15;//how fat we want our pen
	
	
	//enum data types are a nice halfway point between classes
	//and arrays, they store data like an array, but are called/changed
	//during the runtime of the program, we assign 
	//the variable currentState to "see" what the current value of
	//GameState is
	public enum GameState {PLAYING,DRAW, O_WIN,X_WIN}
	
	private GameState currentState;
	// same enum idea here, but instead GameStates we are checking 
	//who the player is
	public enum seed {EMPTY, X,O}
	private seed currentPlayer;
	
	private seed[][] board;
	//2D array that can have 3 values(defined by seed {EMPTY,X,O})
	
	private DrawCanvas canvas;
	private JLabel statusbar;
	
	//constructor
	public tivtactoe()
	{
		canvas = new DrawCanvas();
		canvas.setPreferredSize(new Dimension(CANVAS_WIDTH,CANVAS_HEIGHT));
		
		canvas.addMouseListener(new MouseAdapter() {
			//add the mouse listener right into the constructor
			//normal mouse listener method
			public void mouseClicked(MouseEvent e)
			{
				int mouseX = e.getX();//x position that has been clicked
				int mouseY = e.getY();//y position that has been clicked
				
				int rowselected = mouseY/CELL_SIZE;//blow up the pixel size
				int colselected = mouseX/CELL_SIZE;
				
				if(currentState == GameState.PLAYING)//if a game is going on
				{
					if(rowselected >=0 && rowselected < ROW && 
						colselected >=0 && colselected < COL
						&& board[rowselected][colselected]==seed.EMPTY)
						//make sure the click was on the board, 
						//and the space is empty	
					{
						//give the clicked space to the currentplayer 
						//(remember it was already empty)
						board[rowselected][colselected]= currentPlayer;
						//switch the current player (this is an if-else statement)
						updateGame(currentPlayer,rowselected,colselected);
						currentPlayer= (currentPlayer == seed.X) ? seed.O : seed.X;
					}
				}
				else
					{
						initGame();//restart the game
					}
					repaint();//repaint the panel
				}
			}		
				);
		
		statusbar = new JLabel("hi ");
		statusbar.setFont(new Font(Font.DIALOG_INPUT,Font.BOLD,15));
		statusbar.setBorder(BorderFactory.createEmptyBorder(2,5,4,5));
		
		Container cp = getContentPane();
		cp.setLayout(new BorderLayout());
		cp.add(canvas, BorderLayout.CENTER);
		cp.add(statusbar, BorderLayout.PAGE_END);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		pack();
		setTitle("tic tac toe =D ");
		setVisible(true);
		
		board = new seed[ROW][COL];
		initGame();
	}//end constructor
	
	
	public void initGame()
	{
		//2D arrays are usually filled with data in this 
		//nested for loop algorithm,
		//we use them quite often especially for board games and
		//other data that uses a table format
		for(int row =0;row< ROW;row++)//all the rows
		{
			for(int col=0; col<COL;col++)//all the columns
			{
				board[row][col]=seed.EMPTY;//make all the data empty
			}
		}
		currentState = GameState.PLAYING;//start the game, let java know
		currentPlayer=seed.X;//first player is X
	}
	
	public void updateGame(seed theSeed,int rowselected,int colselected)
	{
		if(hasWon(theSeed,rowselected,colselected)==true)//if someone won
		{//let the user know who won
	    currentState=(theSeed==seed.X) ? GameState.X_WIN : GameState.O_WIN;
		}
		else if (isDraw())//if there is a draw
		{
			//let the user/java know there is a draw
			currentState=GameState.DRAW;
		}
	}
	
	public boolean isDraw()
	{
		for(int row =0; row < ROW; row++)//for all rows
		{
			for(int col =0; col<COL;col++)//for all columns
			{
				if(board[row][col]== seed.EMPTY)//check if the board is empty
					return false;//if it is empty, there is not a draw (yet)
			}
		}
		return true;//no empty spaces means there is a draw
	}
	
	public boolean hasWon(seed theseed,int rowselected,int colselected)
	{
		return( 
				board[rowselected][0] == theseed // 3 in a row
			&&  board[rowselected][1] == theseed
			&&  board[rowselected][2] == theseed
			
 			||	
				board[0][colselected] == theseed // 3 in a column
			&&  board[1][colselected] == theseed
			&&  board[2][colselected] == theseed
			
			||
				rowselected == colselected // 3 in the diagonal
			&& board[0][0] == theseed
			&& board[1][1] == theseed
			&& board[2][2] == theseed
			
			||
				rowselected + colselected == 2 // 3 in the opposite 
			&& board[0][2] == theseed		  // diagonal
			&& board[1][1] == theseed
			&& board[2][0] == theseed
			
				);
	}
	public class DrawCanvas extends JPanel
	{
		public void paintComponent(Graphics g)
		{
			super.paintComponent(g);
			setBackground(Color.BLACK);
			
			g.setColor(Color.MAGENTA);
			for(int row =1;row<ROW;row++)
			{
				g.fillRoundRect(0,
						CELL_SIZE*row-GRID_HALF,
						CANVAS_WIDTH-1,
						GRID_WIDTH,
						GRID_WIDTH,
						GRID_WIDTH);
			}
			for(int col =1;col<COL;col++)
			{
				g.fillRoundRect(CELL_SIZE*col-GRID_HALF,
								0,
								GRID_WIDTH, 
								CANVAS_HEIGHT-1,
								GRID_WIDTH, 
								GRID_WIDTH);
			}
			
			Graphics2D g2 = (Graphics2D)g;
			g2.setStroke(new BasicStroke(SYMBOL_STROKE,
					BasicStroke.CAP_ROUND,BasicStroke.JOIN_ROUND));
			
			for(int row =0; row<ROW;row++)
			{
				for(int col=0;col<COL;col++)
				{
					//we need to know where we are
					int x1 = col * CELL_SIZE + CELL_PADDING;
					int y1 = row * CELL_SIZE + CELL_PADDING;
					//who is playing?
					if(board[row][col] == seed.O)
					{
						g2.setColor(Color.green);
						g2.drawOval(x1, y1, SYMBOL_SIZE, SYMBOL_SIZE);
					}
					else if( board[row][col] == seed.X)
					{
						g2.setColor(Color.orange);
						int x2 = (col+1)*CELL_SIZE - CELL_PADDING;
						int y2 = (row+1)*CELL_SIZE - CELL_PADDING;
						g2.drawLine(x1, y1, x2, y2);
						g2.drawLine(x2, y1, x1, y2);
					}
				}
			}
			
			if(currentState == GameState.PLAYING)
			{
				statusbar.setForeground(Color.red);
				if(currentPlayer==seed.X)
				{
					statusbar.setText("X's Turn!");
				}
				else
				{
					statusbar.setText("O's Turn!");
				}
			}
			else if(currentState == GameState.DRAW)
			{
				statusbar.setForeground(Color.RED);
				statusbar.setText("ITS A TIE! click to play again");
			}
			else if (currentState == GameState.X_WIN)
			{
				statusbar.setForeground(Color.black);
				statusbar.setText("X WON!!! XD");
			}
			else if(currentState == GameState.O_WIN)
			{
				statusbar.setForeground(Color.blue);
				statusbar.setText("O WON!! =D");
			}
		}
	}
		
		public static void main(String[] args)
		{
			SwingUtilities.invokeLater(new Runnable()
					{
					//@Override
						public void run()
						{
							new tivtactoe();
						}
					});
		}
	}
	 
