/*
 * Caleb Seifert
 * intro to numbers
 */

package numbers;

public class intro_to_numbers 
{
	public static void main(String[] args)
	{
		/*
		 * "int" stands for "integer...it means we are using a 
		 *  WHOLE (no decimal point or fraction) counting number
		 */
		int number =10;
		//number is a variable of "int" type
		// we can rename "number" to whatever we want, as long as
		// we keep the spelling the same
		System.out.println("your number is:"+number);
		//print out the number, let the user know what it is! 
	}
}
