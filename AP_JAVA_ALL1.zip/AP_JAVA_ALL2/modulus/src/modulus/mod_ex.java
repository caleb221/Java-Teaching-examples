/*
 * Caleb Seifert
 * 10/20/16
 * Modulus
 * 
 */

package modulus;
import java.util.Scanner;
public class mod_ex 
{
	public static void main(String[] args)
	{
		
		Scanner keys = new Scanner(System.in);
		int num =0;
		int two = 2;
		int three = 3;
		
		System.out.println("Hello, this is a modulus example ~!");
		
		for (int i=1; i<10;i++)
			{
				num = two % i; // modulus (remainder function)
				System.out.println("2 % "+ i+" = "+num);
				num = three % i;
				System.out.println("3 % "+i+" = "+ num);
			}
		System.out.println("take the square root of a number \n:" );
		
		num = keys.nextInt();
		int ans = (int) Math.sqrt(num);
		
		System.out.println("The square root of your number is: "+ans);
	}
}
