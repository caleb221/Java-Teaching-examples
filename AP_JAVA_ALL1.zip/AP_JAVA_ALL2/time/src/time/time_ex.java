/*
 * Caleb Seifert
 * 10/17/16
 * Time
 */
package time;
import java.util.*;

public class time_ex 
{
	
	
	public static void main(String[] args)
	{
		
		Date today = new Date();// get today's date from the computer
		Scanner keys = new Scanner(System.in);// lets us use the keyboard
		System.out.println("Today is:  "+ today);
		int countdown = 5;
		int input = 0;
		
		System.out.println("\nPlease input 5: ");
		input=keys.nextInt();
		
		while(countdown < 0 || input !=5 )
		{
			System.out.println("CHOOSE BETTER! maybe 5?\n");
			input =keys.nextInt();
			countdown--;
			System.out.println("YOU HAVE "+countdown+" Chances left");
			
			if(countdown == 0)
			{
				System.out.println("YOU RAN OUT OF CHANCES!!\n");
				System.out.println(today);
				
				try {
					   Thread.sleep(20*10*60);
					}
				catch(Exception e)
					{
						System.out.println("EXCEPTION ENCOUNTERED! "+e);
					}
				System.out.println(today);
			}
			
		}
		
	}

}
