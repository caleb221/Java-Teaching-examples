/*
 * Caleb Seifert
 * 10/20/16
 * the math class
 */
package some_math2;
import java.util.Scanner;
public class some_math_ex
{
	public static void main(String[] args)
	{
		int two =2;
		int three =3;
		int ans =0;
		int input =0;
		
		Scanner keys = new Scanner(System.in);
		
		System.out.println("Hello! here is some math!");
		for (int i=1;i<11;i++)
		{
			ans = two % i;// % divides both numbers and gives back remainder
			System.out.println("2 % "+i+" = "+ans);
			ans = three % i;
			System.out.println("2 % "+i+" = "+ans);
		}
		System.out.println("Please put in a number to see its square root");
		input = keys.nextInt();
		ans =(int) Math.sqrt(input);
		System.out.println("The square root is: "+ans);
		
		
	}

}
