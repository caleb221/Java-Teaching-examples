/*
 * Caleb Seifert
 * 11/21/16
 * pig latin translator
 */
package piglatin;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class piglatin_translator extends JFrame
{
	//fields
	JButton btn1 = new JButton("Translate!");
	JTextField txt_in = new JTextField(10);
	JTextField txt_out = new JTextField(10);
	
	//constructor
	public piglatin_translator()
	{
		btnclick click = new btnclick(); // action method
		btn1.addActionListener(click);
		txt_in.addActionListener(click);
		txt_out.setEditable(false);
		
		JPanel panel = new JPanel();
		panel.setLayout(new FlowLayout());
		
		panel.setBackground(Color.green);
		btn1.setBackground(Color.yellow);
		
		panel.add(new JLabel("input your word: "));
		panel.add(txt_in);
		panel.add(btn1);
		panel.add(new JLabel("your translation is: "));
		panel.add(txt_out);
		
		setTitle("Pig latin translator =) ");
		setContentPane(panel);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		pack();
	}
	
	public static String translator(String Amessage)
	{
		String word = Amessage;
		String output="hello";
		boolean check = false;
		String[] vowels = {"a","e","i","o","u"};
		
		String firstletter = word.substring(0, 1);
		
		for(int i =0; i<vowels.length;i++)
		{
			check = vowels[i].equalsIgnoreCase(firstletter);
			if(check == true)
			{
				break;
			}	
		}
		
		if (check == true)
		{
			output = word+"way";
		}
		else
		{
			output = word.substring(1,word.length())+firstletter+"ay";
		}
		return output;
	}
	
	//action method
	public class btnclick implements ActionListener
	{
		public void actionPerformed(ActionEvent e)
		{
			String input = txt_in.getText();
			String answer = translator(input);
			txt_out.setText(answer);
		}
	}
	
	public static void main(String[] args)
	{
		piglatin_translator app = new piglatin_translator();
		app.setVisible(true);
	}
}



