/*
 * Caleb Seifert
 * 11/23/16
 * movement!
 */

package themover;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class themover extends JPanel
{
	//field
	int x,y,x2,y2;// X and Y position on the panel, in pixels  
				 // X2 and Y2 are the changing parameters used 
				// to move around the graphics 
	
	JTextField fld1 = new JTextField(5); // new text field to show us
										// what key we are pressing
	//constructor
	public themover()
	{
		fld1.addKeyListener(new keys()); // add the key listener, so that when we
										// press a key, the program will hear it
		fld1.setEditable(false); // no user input is needed
		
		setLayout(new FlowLayout());//set the layout, we are using a Flow Layout here
		add(fld1); 					// add the text field to the panel
		setBackground(Color.GRAY);	//make the background dark grey
	}
	
	//painter
	public void paint(Graphics g) // JPanel method, this can be called again over
	{							 // the life of the program
		
		super.paintComponent(g); // gets any graphics that were set earlier 
								// in this case, our background color
		x=this.getWidth()/2; // center X position (pixels) 
		y=this.getHeight()/2;// center Y position (pixels)
		Font f = new Font("MonoSpaced",Font.PLAIN,45); // a nice font 
		g.setFont(f); // set the font on the panel
		g.setColor(Color.cyan); //set the color for the graphics on the panel
		//g.fillRect(x-x2,y-y2,40,40);
		//g.drawString("��", x-x2, y-y2);
		
		g.setColor(Color.yellow);
		g.fillOval(x-x2+30, y-y2+30, 40, 40);
		g.setColor(Color.BLACK);
		g.fillOval(x-x2+35, y-y2+35, 15, 15);
		g.fillOval(x-x2+55, y-y2+35, 15, 15);
		g.drawLine(x-x2+35, y-y2+55, x-x2+50, y-y2+55);
	}
	//key board action listener
	public class keys implements KeyListener
	{

		@Override
		public void keyPressed(KeyEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void keyReleased(KeyEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void keyTyped(KeyEvent e) {
			char selected = e.getKeyChar();
			fld1.setText(""+selected);
			
			if(selected == 'w')
			{
				y2+=5;
				repaint();
			}
			if(selected == 's')
			{
				y2-=5;
				repaint();
			}
			if(selected == 'a')
			{
				x2+=5;
				repaint();
			}
			if(selected == 'd')
			{
				x2-=5;
				repaint();
			}
		}
	}
	public static void main(String[] args)
	{
		themover app = new themover();
		JFrame frame = new JFrame("THINGS�����ңš�MOVING����_��");
		frame.setContentPane(app);
		frame.setSize(250, 250);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}

}
