package layoutss;

/*
 * Caleb seifert
 * 11/28/16
 * panels inside panels
 * 
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


public class layouts extends JPanel implements ActionListener
{
	//fields
	JButton btn1 = new JButton("change the color!");
	Color bkgcol;
	panel2 paneltwo;
	
	//constructor
	public layouts()
	{
		setLayout(null);
		setBackground(Color.DARK_GRAY);
		paneltwo= new panel2();
		btn1.addActionListener(this);
		add(paneltwo);
		add(btn1);
	
		paneltwo.setBounds(0, 10, 180, 200);
		btn1.setBounds(190,210,80,40);
	}
	
	public class panel2 extends JPanel
	{
		//constructor for panel 2
		public panel2()
		{
			setPreferredSize(new Dimension(20,20));
		}
		public void paintComponent(Graphics g)
		{
			if(bkgcol == null)
			{
				g.setColor(Color.GREEN);
			}
			else
			{
				g.setColor(bkgcol);
			}
			g.drawRect(0, 0, getSize().width-1, getSize().height-1);
			g.drawRect(1, 1,getSize().width-3,getSize().height-3);
			Font f = new Font("SansSerif",Font.BOLD,15);
			g.setFont(f);
			g.drawString("hello! this is panel 2!", 10, 50);
		}
	}
	public void actionPerformed(ActionEvent e)
	{
		float hue = (float)Math.random();
		bkgcol =Color.getHSBColor(hue, 1.0F, 1.0F);
		repaint();
	}
	
	public static void main(String[] args)
	{
		layouts app = new layouts();
		JFrame frame = new JFrame("2 panels 0_0");
		frame.setContentPane(app);
		frame.setSize(400,400);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
}
