/*
 * lets try and load an image!
 */

package imageloading;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;
import java.awt.image.*;
import javax.imageio.*;
import java.io.File;
import java.io.IOException;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.SourceDataLine;

public class loadmyimage extends Component
{
	//fields
	BufferedImage image;
	private SourceDataLine line = null;
	private byte[] audioBytes;
	private int numBytes;
	/*
	 * buffered image is a special data type from java.awt.image
	 * it will buffer (load) an image from the project file
	 * and we will be able to use it as an object
	 */
	public void paint(Graphics g)
	{
		g.drawImage(image, 0, 0, null);
		//paint our image onto the panel
		sounds nys = sounds("bells.wav");
		
	}
	public loadmyimage()
	{
		/*
		 * in order to obtain the image, we need to load it into memory
		 * from the project file, to do this we need to use the 
		 * try{}
		 * and catch(){}
		 * methods, they first try the code inside '{}' and if it does
		 * not execute correctly, there will be an exception error (e)
		 * this helps us to avoid exception errors while we run our code
		 * without the try and catch we run a risk of running into
		 * an error and the program failing during runtime
		 */
		try{
			/*
			 * we need to be EXACTLY CLEAR when we write filepaths
			 * the computer does not have any thoughts, so it does not
			 * go looking for the file it thinks you want...
			 * this is why we have catch(){}
			 * 
			 */
			image=ImageIO.read(new File("rainbowbunchie.jpg"));
		}
		catch(IOException e)
		{
		/*
		 * if the above code in try fails and gives an error, we catch it
		 * here..
		 * note the System.out.println(e); is not necessary, but without it
		 * we would not know what error occured  
		 */
			System.out.println("this is the error:\n"+e);
		}
		
		
	}
	public Dimension getPreferredSize()
	{
		if(image==null)
		{
			// just incase java doesnt find our image
			return new Dimension(100,100);
		}
		else
		{
			//get the size of our picture!
			return new Dimension(image.getWidth(null)
					,image.getHeight(null));
		}
	}
	
	 public void sounds(String fileName)
	  {
	    File  soundFile = new File(fileName);
	    AudioInputStream audioInputStream = null;
	    try
	    {
	      audioInputStream = AudioSystem.getAudioInputStream(soundFile);
	    }
	    catch (Exception ex)
	    {
	      System.out.println("*** Cannot find " + fileName + " ***");
	      System.exit(1);
	    }

	    AudioFormat audioFormat = audioInputStream.getFormat();
	    DataLine.Info info = new DataLine.Info(SourceDataLine.class,
	                         audioFormat);
	    try
	    {
	      line = (SourceDataLine)AudioSystem.getLine(info);
	      line.open(audioFormat);
	    }
	    catch (Exception ex)
	    {
	      System.out.println("*** Audio line unavailable ***");
	      return;
	    }

	    line.start();

	    audioBytes = new byte[(int)soundFile.length()];

	    try
	    {
	      numBytes = audioInputStream.read(audioBytes, 0, audioBytes.length);
	    }
	    catch (IOException ex)
	    {
	      System.out.println("*** Cannot read " + fileName + " ***");
	      System.exit(1);
	    }
	  }

	  /**
	   * Plays this <code>EasySound</code>.
	   */
	  public void play()
	  {
	    // Our thanks to JP Fasano for helping debug audio line exceptions. 
	    if (line != null)
	      line.write(audioBytes, 0, numBytes);
	    else
	      System.out.println("La-la-la (the audio line is unavailable on this computer)");
	  }
	  
	
	
	
	
	public static void main(String[] args)
	{
		JFrame frame = new JFrame("THIS IS MY PICTURE GUYS!! ^_^");
		sound app = new sounds("C:\\Users\\yiwut\\Documents\\StudentFiles\\EasyClasses\\bells.wav");
		frame.addWindowListener(new WindowAdapter()
				{
					public void WindowClosing(WindowEvent e)
					{
						System.exit(0);
					}
				});
		frame.add(new loadmyimage());//our class!
		frame.pack();//make it all fit!
		frame.setVisible(true);//show me my picture!
	}
}





