/*
 * getting system time!
 * this passes the barrier between our real computers and the fake eclipse computer
 */

import java.util.*;//import the java.util library!

public class System__time 
{
	public static void main(String[] args)
	{
		Date today = new Date();//what is today?
	
		System.out.println("��� annie! how are you on this fine day of:  "+today);
		System.out.println("Jun, you look beautiful on "+today.getDay()+
				"th day of the week");	
	System.out.println( "but you had food on your shirt at "+today.getHours());
		
	}

}
