/*
 * Caleb Seifert
 * 11/8/16
 * GUI integer input
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class GUIinput extends JFrame
{
	public static final double constant_minus = 32;
	// ԰ fields!! these are the variables that ALL classes
	// have access to
	
	JTextField input_textf = new JTextField(3);
	JTextField output_textf = new JTextField(3);
	
	public GUIinput()
	{
		JButton convertbtn = new JButton("convert");
		
		convertbtn.addActionListener(new method_button());
		
		input_textf.addActionListener(new method_button());
		
		output_textf.setEditable(false);
		
		JPanel panel = new JPanel();
		
		panel.setLayout(new FlowLayout());
		
		panel.add(new JLabel("convert celcius to farenheight!!"));
		panel.add(input_textf);
		panel.add(convertbtn);
		panel.add(new JLabel("your temprature is: "));
		
		panel.add(output_textf);
		setContentPane(panel);
		pack();
		setTitle("this be the FRAME, lets convert some stuff");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
	}
	
	 class method_button implements ActionListener
		{
		public void actionPerformed(ActionEvent e)
		{ 
			String input = input_textf.getText();
			int actual_input = Integer.parseInt(input);
		
		double celcius_temp= (double) (1.8)*(actual_input -constant_minus);
		
			output_textf.setText(""+celcius_temp);
		}
	}
	public static void main(String[] args)
	{
		GUIinput app = new GUIinput();
		app.setVisible(true);
	}

}










