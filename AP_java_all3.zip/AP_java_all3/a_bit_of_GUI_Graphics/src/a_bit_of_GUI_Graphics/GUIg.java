/*
 * Caleb seifert
 * Gui 2D 
 * 11/8/16
 */
package a_bit_of_GUI_Graphics;

import java.awt.*;
import javax.swing.*;

public class GUIg extends JPanel
{
	//create a field ( THE PLACE WHERE WE DEFINE 
	//       variables that can be passed to other classes)

	private String Amessage;
	private Font font1,font2,font3,font4;
	
	//default constructor --> sends the GUI a null string
	public GUIg()
	{
	 this(null);	
	}
	
	public GUIg(String Amessage) // take in a string
	{
		//make some nice fonts
		font1 = new Font("Serif",Font.BOLD,20); 
		font2= new Font("SansSerif",Font.ITALIC,25);
		font3= new Font("MonoSpaced",Font.PLAIN,55);
		font4 = new Font("Dialog",Font.ITALIC,45);
	}
	public void paintComponent(Graphics g)
	{
		String message= Amessage;
		if(message == null) // this will always be true because we send in a null value
		{
			Amessage= "��ϲ������ �����!";
		}
		super.paintComponent(g);//override the superclass, 
						//take paintComponent from JPanel so we can now use it in our
						// class however we would like
		Graphics2D g2 = (Graphics2D)g;
		g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, 
				RenderingHints.VALUE_ANTIALIAS_ON);
		
		int height = getHeight();
		int width = getWidth();
		
		for (int i=0; i<25;i++)
		{
			int fontnum = (int)(Math.random()*5)+1;
			
			switch(fontnum)
			{
			case 1: 
				g.setFont(font1);
				break;
			case 2:
				g.setFont(font2);
				break;
			case 3: g.setFont(font3);
				break;
			default: 
				g.setFont(font4);
				break;
			}
			// set the color ~!
			float hue = (float)(Math.random());
			g.setColor(Color.getHSBColor(hue, 1.0F, 1.0F));
			
			int x,y;
			x=-50 + (int)(Math.random()*width+40);
			y=(int)(Math.random()*(height+20));
			
			g.drawString(Amessage, x, y);
		}
	}
		public static void main(String[] args)
		{
			JFrame window = new JFrame("WHAT WHAT");
			GUIg app = new GUIg();
			
			window.setContentPane(app);
			window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			window.setSize(250, 100);
			window.setVisible(true);
			
		}
		
	}

