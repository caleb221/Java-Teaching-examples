package first_code_sem2;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class sem2_day1 extends JPanel
{
	//fields
	JButton btn1 = new JButton("press me =)");
	JTextField txt1 = new JTextField(10);
	
	//constructor!
	public sem2_day1()
	{
		//connect the button with the listener!
		btn1.addActionListener(new user_click());
		
		//create a nice GUI =)
		setLayout(new FlowLayout());
		setBackground(Color.GREEN);
		add(btn1);
		add(txt1);
	}
	//set up the listener
	public class user_click implements ActionListener
	{
		public void actionPerformed(ActionEvent e)
		{
			String new_output = null;
			if(e.getSource() == btn1)
			{
				new_output = message();
				txt1.setText(new_output);
			}
		}
		
		public String message()
		{
			String[] out = {"hello!","who are you?","GIVE ME FOOD!"};
			
			int random = (int)(Math.random()*10);
			
			if(random<=0 && random >=2)
			{
				return out[random];
			}
			else
			{
			return out[2];
			}
		}
	}// end of user_click class
	
	public static void main(String[] args)
	{
		JFrame frame = new JFrame("THIS IS THE FRAME =)");
		sem2_day1 app = new sem2_day1();
		frame.setContentPane(app);
		frame.setSize(200,100);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
	

}
