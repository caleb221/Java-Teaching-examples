/*
 * Caleb Seifert
 * 11/7/16
 * counting with GUIs
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class GUIclicker extends Frame implements ActionListener  
{
	//declare a few fields 
	// these are the variables we use in the GUI
	private Label lbl;
	private TextField txtfld;
	private Button btn;
	private int count=0; // counts upwards after a click
	
	//make a big constructor
	public GUIclicker()
	{
		setLayout(new FlowLayout());// sets the layout
		
		lbl= new Label("How many times can you click?"); 
		//labels are like the System.out.println(""); for GUIs
		add(lbl);
		//text fields can change value, see the counter in the code
		txtfld = new TextField("",10);
		txtfld.setEditable(false);
		add(txtfld);
		
		btn = new Button("CLICK ME");
		add(btn);
		
		btn.addActionListener(this);// this --> THIS CLASS
		
		setTitle("I HAVE NO IDEA!");
		setSize(250,100);
		setVisible(true);// dont forget, no one
						//see your work unless you tell the computer to show it!
	}
	public static void main(String[] args)
	{
		GUIclicker app = new GUIclicker(); // all we need to do is call the 
										  // single object GUIclicker in main
	}
	
	@Override // tells java something in the panel is going to change
	public void actionPerformed(ActionEvent e)
	{
		count++; // count plus 1
		txtfld.setText(""+count);//reset the text field with the new count value 
								// after every click
	}

}














