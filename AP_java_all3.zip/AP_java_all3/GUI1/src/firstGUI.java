/*
 * Caleb Seifert
 * 8/31/16
 * First GUI
 */
import javax.swing.JOptionPane;

public class firstGUI 
{
	public static void main(String[] args)
	{
		JOptionPane.showMessageDialog(null, "Happy Halloween!!");	
	}
}
