/*
 * review code for the first test
 */

import java.util.*;//what does this do? and what is it?

public class review1 
{
	

	 public static void message(String text)//what is this called? how do we use it?
	{
		System.out.println(text);
	}
	 
	 public static void main(String[] args)
	 {
		 Scanner keyboard = new Scanner(System.in);
		 int user_input1=0;//what is an int?
		 
		 //why does this work?
		 message("hello! please pick a number! any one will do fine");
		 user_input1=keyboard.nextInt();

		 for(int i=0;i<user_input1;i++)//what is going on here? what kind of loop is this
		 {							//how long will the loop go on?
			message("we are at: "+i);
			if(i == 5)//what does == mean?
			{
				/*
				 * == -> equal to
				 * != -> not equal
				 * >  -> greater than
				 * < -> less than
				 * <= -> less than or equal to
				 * >= -> greater than or equal to
				 * && -> AND
				 * || -> OR
				 */
				message("5!!!! WOOOOOOO!!!");
			}
			else//when does this else happen?
			{
				message("not 5");
			}
		 }//end of for loop
		 /*
		  * be sure to study all classwork!
		  */
		 dog puppy = new subdog();
		 puppy.act();
	 }//end of main
	 
	 
	 
	 
	 
	 
public class dog 
{
	public void act()
	{
		message("act (dog class)");
		eat();
	}
	public void eat()
	{
		message("eat: dog class");
	}
} 

public class subdog extends dog
{
	public void act()
	{
		super.act();
		message("sleep");
	}
	public void eat()
	{
		super.eat();
		message("bark");
	}

}




}//end of class review













/**
 * FINISH OUT THE AP MULTIPLE CHOICE WORKSHEET
 * (you should already have 1-10 done)
 * We will work on the free response codes later tomorrow
 *	I am here to help if you need  
 */






