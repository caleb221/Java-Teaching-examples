/*
 * Caleb Seifert
 * 11/14/16
 * review of console applications part 1
 */
import java.util.*;

public class review_p1
{
	public static void log(String Amessage)
	{
		System.out.println(Amessage);
	}
	
	public static void main(String[] args)
	{
		Scanner keys = new Scanner(System.in);
		Date today = new Date();
		int input1 = 0;
		int input2=0;
		String mood;
		boolean check;
		
		log("Hello! how are you?\n");
		mood = keys.nextLine();
		check = mood.equals("good");
		// if statements help us make decisions in code
		// they take in 2 parameters and check them against each other
		// if the condition is true or correct, the code in the  {squiggly brackets}
		// is executed
		// otherwise the code moves on
		if(check == true )
		{
			log("Awesome! im so happy you are feeling great today! =)");
		}
		check = mood.equals("bad");
		if(check == true)
		{
			log("sorry man =\\ cheer up! it will be alright!");
		}
		check = mood.equals("meh");
		if(check == true)
		{
			log("why though? ");
		}
		log("anyways, pick a number");
		input1 = keys.nextInt();
		log("cool, pick another one");
		input2=keys.nextInt();
		int answer = (int) Math.pow(input1, input2);
		log(input1+"^"+input2+" = "+answer);
	}
}
