

/*
 * Caleb Seifert
 * 11/10/16
 * A sunrise (a bit of graphics)
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class SUNRISE_sobright extends JPanel implements ActionListener
{
	private int time;
	
	public SUNRISE_sobright()
	{
		time=0;
		Timer clock = new Timer(30,this);
		clock.start();
	}
	
	public void paintComponent(Graphics g)
	{
		int x = 150-(int)(100*Math.cos(0.005*Math.PI*time));
		int y =(int)(130-(int)75*Math.sin(0.005*Math.PI*time));
		int r =30;
		Color sky;
		
		if(y>130)
		{
			sky=Color.BLACK;
		}
		else
		{
			sky = Color.blue;
		}
		
		setBackground(sky);
		
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D)g;
		g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
		g.setColor(Color.red);
		g.fillOval(x-r, y-r, r*2, r*2);
		int r2 = r-10;
		Font f = new Font("MonoSpaced",Font.BOLD,25);
		g.setFont(f);
		g.setColor(Color.orange);
		g.fillOval(x-r2,y-r2, r2*2, r2*2);
		g.setColor(Color.WHITE);
		g.drawString("����", (x-r2), (y-r2/20));
	}
	
	public void actionPerformed(ActionEvent e)
	{
		time++;
		repaint();
	}
	
	public static void main(String[] args)
	{
		JFrame frame = new JFrame("LOOK AT THIS SUNRISE!");
		frame.setSize(300, 150);
		
		Container c = frame.getContentPane();
		c.add(new SUNRISE_sobright());
		frame.setResizable(false);
		frame.setVisible(true);
	}
}










