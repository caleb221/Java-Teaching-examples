/*
 * Caleb seifert
 * 11/16/16
 * GUI review
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class GUI_review extends JFrame // extends is the keyword that lets us know
{									  // that we are now using a subclass of JFrame or 
									 // whichever super class we choose to use
	//Fields
	// this is where the fields are located, it is the spot where
	// we define all the variables that we will be using in more than one class
	JButton btn = new JButton("this is the button");
	JLabel lbl1 = new JLabel("this is a label");
	
	//constructor!
	//this is where we build our GUI object, it is the blue print for our GUI
	public GUI_review()
	{
		btn.addActionListener(new button_method()); // connect the button to the action listener
		JPanel panel = new JPanel(); // create a panel object
		panel.setLayout(new FlowLayout()); // set the layout 
		panel.add(btn);   				  // add the button
		panel.add(lbl1);				 // add the label
		panel.setBackground(Color.GREEN);// make the background green ( or whatever color)
		
		setContentPane(panel); // put the panel onto the frame
		setTitle("this is the FRAME Title"); // set the frame title
		pack();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // set the close operations (FRAME)
	}
	
	public class button_method implements ActionListener // this class uses the action listener
	{
		public void actionPerformed(ActionEvent e) // on an action, do something
		{
			if(e.getSource() == btn) // if the source of the action is btn, do the the code
			{
				System.exit(0); // exit the program
			}
		}
	}
	
	public static void main(String[] args)
	{
		GUI_review app = new GUI_review();
		app.setVisible(true);
	}

}









