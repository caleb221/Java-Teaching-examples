/*
 * Caleb seifert
 * 11/17/16
 * GUI Graphics review (intro to graphics only)
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class GUI_graphics extends JPanel
{
	//field
	Font font1 = new Font("MonoSpaced",Font.BOLD,25);
	//constructor
	public GUI_graphics()
	{
		setBackground(Color.black);
		JFrame frame = new JFrame();
		// build the frame, the panel is made already by extending JPanel
		frame.setContentPane(this);
		frame.setTitle("Hello!");
		frame.setSize(350, 200);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
	
	public void paintComponent(Graphics g) // JPanel graphics painter
	{
		super.paintComponents(g); // get the paint components from the super class (this)
		g.setColor(Color.red);	// set the color to red
		int x = 100;  			// x-dimension in pixels
		int y =50;				// y-dimension in pixels
		
		g.setFont(font1); 		// set the font for the string
		g.drawString("�й� ���Ǻó�", x, y); // draw a string (it will be red)
		g.drawRect(x, y+50, 20, 20);		  // draw a rectangle (it will be red)
		g.fillRect(x+60, y+50, 20, 30);		 // draw a solid rectangle (red)
		g.setColor(Color.orange);			// set the color to green
		g.fillOval(x+30, y+25, 20, 20);		// draw an oval (circle) it will be green	
	}
	
	public static void main(String[] args)
	{
		GUI_graphics app = new GUI_graphics();
	}
}








