/*
 * Caleb Seifert
 * 10/26/16
 * Arrays
 */

package array_of_arrays;
import java.util.Scanner;
public class arrays_on_arrays 
{
	public static void main(String[] args)
	{
		int num_array[] = null;// {0,0,0,0,0};// create an array
		
		Scanner keys = new Scanner(System.in);
		num_array[3] = 3; // set the 4th space of num_array equal to 3
		
		for(int i=0;i<num_array.length;i++)
		{
		   System.out.println(num_array[i]); // print out each space 1 by 1
		}
		
		System.out.println("What a nice array you made, now lets put some "
												+ "numbers in it!");
		for(int n =0;n<num_array.length;n++)
		{
			System.out.println("Please enter the number your want! ");
			num_array[n]=keys.nextInt(); // get a new number 1 by 1
		}
		
		for(int i=0;i<num_array.length;i++)
		{
		   System.out.println(num_array[i]); // print out each space 1 by 1
		}
		
			
	}

}
