package AP_snake;
/*
 * Snake graphics panel!
 */
import javax.swing.*;
import java.awt.*;

public class Renderpanel extends JPanel 
{
	//field
	//public loadmyimage bunchie;
	public static final Color GREEN = new Color(1666073);
	//dark green, you can choose any color you would like

	protected void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		Snake snake1 = Snake.snakeObj;
		
		g.setColor(GREEN);
		g.fillRect(0, 0, 800, 700);
		
		g.setColor(Color.magenta);
		for(Point p : snake1.snakeParts)
		{
			g.fillRect(p.x*snake1.SCALE, p.y*snake1.SCALE
					, snake1.SCALE, snake1.SCALE);
		}
		
		g.setColor(Color.green);
		for(Point p : snake1.snakeParts)
		{
			g.drawOval(p.x*snake1.SCALE, p.y*snake1.SCALE,8,8);
		}
		
		g.setColor(Color.blue);
		for(Point p : snake1.snakeParts)
		{
			g.drawOval(p.x*snake1.SCALE, p.y*snake1.SCALE,5,5);
		}
		
		
		
		g.fillRect(snake1.head.x*snake1.SCALE, snake1.head.y*snake1.SCALE,
				snake1.SCALE, snake1.SCALE);
		g.setColor(Color.PINK);
		
		g.fillRect(snake1.food.x*snake1.SCALE, snake1.food.y*snake1.SCALE,
				snake1.SCALE, snake1.SCALE);
		
	String str = "Score: "+snake1.score+" Length: "
					+snake1.tailLength+" Time: "+snake1.time/20;
	
	g.setColor(Color.GRAY);
	g.drawString(str, (int)(getWidth()/2-str.length()*2.5f), 10);
	
	str ="GAME OVER! THE SNAKE DIED =(";
	if(snake1.over)
	{
		g.drawString(str, (int)(getWidth()/2-str.length()*2.5f), 
										(int)snake1.dim.getHeight()/4);
	}
	
	str = "PAUSED! PRESS SPACE TO RESUME THE GAME!";
	if(snake1.paused && !snake1.over)
	{
		g.drawString(str, (int)(getWidth()/2-str.length()*2.5f), 
				(int)snake1.dim.getHeight()/4);
	}
	
	}
}




