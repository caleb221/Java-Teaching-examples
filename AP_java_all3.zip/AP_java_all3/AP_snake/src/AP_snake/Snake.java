package AP_snake;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.Timer;

import java.util.*;

public class Snake implements ActionListener,KeyListener
{
	public static Snake snakeObj; // object for the snake class
	public Renderpanel renderpanel;//our graphics for snake

	
	public Timer timer = new Timer(20,this);
	//timers help us keep the game going, we want to repaint and 
	//update as we play, the timer will help us with this!
	
	public ArrayList<Point> snakeParts = new ArrayList<Point>();
	//an array list to keep adding fat (longer snake) to the snake
	//when he eats a piece of food...he is very hungry
	
	public static final int UP=0,DOWN=1,LEFT=2,RIGHT=3,SCALE=10;
	//some game constants, these will never change
	
	public int ticks=0,direction=DOWN,score,tailLength=10,time;
	//some changing integers, these can be changed while we play
	
	public Point head,food;
	//head of the snake, and the piece of food
	
	public Random random;
	//in the wild, we never know where the next piece of food will be
	//we could  say, its randomly placed 0_0
	
	public boolean over = false, paused;
	public JFrame frame;
	//our frame
	
	public Dimension dim;
	//our dimension, to see how big our computer screen is 
	
	//constructor
	public Snake()
	{
		dim = Toolkit.getDefaultToolkit().getScreenSize();
		frame = new JFrame("SNAAAKKKEEEEE ^_^");
		frame.setVisible(true);
		frame.setSize(805, 700);
		frame.setResizable(false);
		frame.setLocation(dim.width/2-frame.getWidth()/2
				, dim.height/2-frame.getHeight()/2);
		frame.add(renderpanel = new Renderpanel());
		frame.addKeyListener(this);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		StartGame();
	}
	public void StartGame()//lets start a new game!
	{
		over = false; // the game is not over
		paused=false; // we are not paused
		time =0;
		score =0;
		tailLength=14;
		ticks=0;
		direction = DOWN;
		head = new Point(0,-1);
		random = new Random();
		snakeParts.clear(); // clear the snake
		food = new Point(random.nextInt(79),random.nextInt(66));
		//put the food somewhere on the board
		timer.start();
	}
	
	public boolean noTailAt(int x,int y)
	{// has the snake hit itself?
		for(Point p : snakeParts)
		{// p is a new Point type variable, much like an int i=0;
		// it goes through the length of snakeParts, and actually 
		// assumes the value of snakeParts[i]
		//so, the ":" does the following code for us
		//for(int i=0;i<snakeParts.lenght();i++)
		//{
		//  p[i] = snakeParts[i];
		// --> continue code
		//}
			if(p.equals(new Point(x,y)))
			{//if the point (now in snake parts) is equal to the
			// given x,y then the snake has hit itself
				return false;
			}
		}
		return true;//the snake has not hit itself
	}
	
	@Override
	public void keyPressed(KeyEvent e) 
	{
		int i = e.getKeyCode(); // user input, this updates every time 
								// a new key is pressed, it is the
								// instance variable for the event
		
		if((i== KeyEvent.VK_A || i == KeyEvent.VK_LEFT)// allow the user 
			&& direction != RIGHT)					  //to use either
		{											 // 'W,A,S,D' or
			direction = LEFT;						// the arrow keys
		}											//and make sure the 
		if((i == KeyEvent.VK_D || i==KeyEvent.VK_RIGHT)//snake will 
				&& direction != LEFT)				  // not run into 
		{											 // itself during
			direction = RIGHT;						// gameplay
		}
		if((i== KeyEvent.VK_W || i == KeyEvent.VK_UP)
					&& direction != DOWN)
		{
			direction = UP;
		}
		if((i == KeyEvent.VK_S || i==KeyEvent.VK_DOWN)
				&& direction != UP)
		{
			direction=DOWN;
		}
		if(i==KeyEvent.VK_SPACE)
		{
			if(over)
			{
				StartGame();
			}
			else
			{
				paused = !paused;
				//paused is a boolean (true or false)
				//we switch it here by setting paused equal to not paused
				// !true = false
				// !false = true
				//so if paused is currently true,
				//after this line it will become !true, or false
			}
		}
		
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void actionPerformed(ActionEvent e)
	{
		renderpanel.repaint(); // repaint the panel
		ticks++;				// ticks on a clock
		
		if(ticks%2 ==0 && head != null && !over && !paused)
		{				
			time++;	//add the time
			
			snakeParts.add(new Point(head.x,head.y));
			// this is how we use the ArrayList to add a new space 
			//of memory into our list. Using the built in method "add"
			//we can add any number of data values into our list
			//this is the biggest difference between an ArrayList and an array
			//much like a how a "String" is different from a 'c'har
			if(direction == UP)
			{
				if(head.y-1 >=0 && noTailAt(head.x,head.y-1))
				{//if our head is in the boundaries (panel) and
				// we are not going to run into ourselves (snake)
					head = new Point(head.x,head.y-1);// move the head up 
				}
				else
				{
					over = true;//end the game
				}
			}
			
			if(direction == DOWN)
			{
				if(head.y+1 < 67 && noTailAt(head.x,head.y+1))
				{
					head = new Point(head.x,head.y+1);
				}
				else
				{
					over = true;
				}
			}
			if(direction == LEFT)
			{
				if(head.x-1>= 0 && noTailAt(head.x-1,head.y))
				{
					head=new Point(head.x-1,head.y);
				}
				else
				{
					over = true;
				}
			}
			if(direction == RIGHT)
			{
				if(head.x+1 < 80 && noTailAt(head.x+1,head.y))
				{
					head = new Point(head.x+1,head.y);
				}
				else
				{
					over= true;
				}
			}
			if(snakeParts.size()>tailLength)
			{
				//snakeParts.remove(0);
				//remove the previous head points
			}
			if(food !=null)
			{
				if(head.equals(food))
				{
					score +=10;
					tailLength +=10;
					food.setLocation(random.nextInt(79),
												random.nextInt(66));
				}
			}
		}
	}
	public static void main(String[] args)
	{
		snakeObj = new Snake();
	}
}







