/*
 * Caleb Seifert
 * 11/2/16
 * GUI 2
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class myGUI 
{
	private static class helloString extends JPanel // subclass of JPanel
	{
		public void paintComponent(Graphics g)
		{
			super.paintComponent(g);
			Font font1 = new Font("SansSerif",Font.BOLD,20);
			g.setColor(Color.RED);
			g.setFont(font1);
			
			g.drawString("��� ��֪���������ѧ", 20, 30);
		}
	}
	private static class Buttonclick implements ActionListener
	{
		public void actionPerformed(ActionEvent e)
		{
			System.out.println("WHY YOU CLICK THE BUTTON????");
			//System.exit(0);
		}
	}
	
	public static void main(String[] args)
	{
		//constructors
		helloString box = new helloString();
		JButton button1 = new JButton("DO NOT CLICK ME");
		Buttonclick clicked = new Buttonclick();
		
		button1.addActionListener(clicked);
		
		JPanel content = new JPanel();
		content.setLayout(new BorderLayout());
		content.add(box, BorderLayout.CENTER);
		content.add(button1,BorderLayout.SOUTH);
		
		JFrame window = new JFrame("THIS IS THE FRAME!!!");
		window.setContentPane(content);
		window.setSize(250,100);
		window.setLocation(100, 100);
		window.setVisible(true);
	}
}