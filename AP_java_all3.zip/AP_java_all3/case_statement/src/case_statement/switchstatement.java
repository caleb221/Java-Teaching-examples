/*
 * Caleb Seifert
 * 11/1/16
 * switch statement
 */
package case_statement;

import java.util.Scanner;

public class switchstatement 
{
	public static void main(String[] args)
	{
		Scanner keys = new Scanner(System.in);
		int input = 0;
		int switched=0;
		System.out.println("Hello! please pick a number 1-10!");
		
		input = keys.nextInt();
		switch (input)
		{
		case 1: System.out.println("Hello Xingyu!");
			break;
		case 2: System.out.println("Hello Kunhee!");
			break;
		case 3: System.out.println("Hello Carol!");
			break;
		case 4: System.out.println("Hello Todd!");
			break;
		case 5: System.out.println("Hello Julia!");
			break;
		case 6: System.out.println("Hello Hanuel!");
			break;
		case 7: System.out.println("Hello Jun!");
			break;
		case 8: System.out.println("Hello victoria!");
			break;
		case 9: System.out.println("Hello Hesna!");
			break;
		case 10: System.out.println("Hello Cem!");
			break;
		default: System.out.println("That was not 1-10 =(");
			break;
		}
		
		
	}

}








