/*
 * Caleb Seifert
 * 11/22/16
 * keys in GUI
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class guikey extends JFrame
{
	//fields
	JTextField  fld1 = new JTextField(10);
	JTextField fld2 = new JTextField(5);
	JTextField fld3 = new JTextField(5);
	
	JButton btn = new JButton("exit!");
	/*
	public static void main(String[] args)
	{
		guikey app = new guikey();
		app.setVisible(true);
	}
	*/
	public guikey()
	{
		keyclass keys = new keyclass();
		buttonmethod buttonclick = new buttonmethod();
		
		fld1.addKeyListener(keys);
		fld1.setEditable(false);
		
		fld2.addKeyListener(keys);
		fld2.setEditable(false);
		
		fld3.addKeyListener(keys);
		fld3.setEditable(false);
		
		btn.addActionListener(buttonclick);
		btn.setBackground(Color.CYAN);
		btn.setForeground(Color.red);
		
		JPanel panel = new JPanel();
		panel.setLayout(new BorderLayout());
		panel.setSize(250,250);
		panel.setBackground(Color.pink);
		panel.add(btn,BorderLayout.LINE_START);
		panel.add(fld1,BorderLayout.SOUTH);
		
		panel .add(fld2,BorderLayout.EAST);
		
		panel.add(fld3,BorderLayout.CENTER);
		
		setContentPane(panel);
		setTitle("keyboard listener example!");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(250,250);
		
		
	}
	
	
	
	public class buttonmethod implements ActionListener
	{
		public void actionPerformed(ActionEvent e)
		{
			System.exit(0);
		}
	}
	
	public class keyclass implements KeyListener
	{
		public void keyPressed(KeyEvent e) 
		{
			fld2.setText("pressing: "+e.getKeyChar());
		}

		public void keyReleased(KeyEvent e)
		{
			fld3.setText("you have released: "+e.getKeyCode());
		}

		public void keyTyped(KeyEvent e)
		{
			fld1.setText("you have typed: "+e.getKeyChar());
		}
		
	}
	
	public static void main(String[] args)
	{
		guikey app = new guikey();
		app.setVisible(true);
	}

}

