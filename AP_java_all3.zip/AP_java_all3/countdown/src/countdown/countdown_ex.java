/*
 * Caleb Seifert
 * 10/17/16
 * counting downwards
 * 
 */
package countdown;
import java.util.Scanner;
public class countdown_ex
{
	public static void main(String[] args)
	{
		int input =0;
		int count=0;
		int down=5;
		Scanner keys = new Scanner(System.in);
		System.out.println("Hello! please pick a number, 5 would be cool! ");
		
		input = keys.nextInt();
		
		while(down < 0 || input != 5 )
		{
			System.out.println("Choose a better number, 5 maybe?\n DO IT FOR HARAMBE");
			System.out.println("\nYou have "+ down +" chances left");
			input = keys.nextInt();
			down--;
			
			if(down == 0)
			{
				System.out.println("WHY CANT YOU JUST PICK 5??\n"
								+ " YOU RAN OUT OF CHANCES");
			}
		}
		
		System.out.println("WOOHOO!");
		
		
	}
}
