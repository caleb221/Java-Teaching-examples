package functions_revistited;

public class another_function {

}
