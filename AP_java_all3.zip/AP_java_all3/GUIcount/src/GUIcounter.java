/*
 * Caleb Seifert
 * 11/7/16
 * GUI counter
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class GUIcounter extends Frame implements ActionListener
{
	//fields! the setup for variables in our code
	private Label lblcount;
	private TextField txtfld;
	private Button btncount;
	private int count =0;
	
	public GUIcounter() // big constructor
	{
		setLayout(new FlowLayout()); // Flow layout for the GUI
		
		//labels are like the System.out.println(""); of GUIs
		lblcount = new Label("How many times can you click?"); 
		add(lblcount);
		
		//text fields can change in GUIs
		txtfld = new TextField("0",40);
		txtfld.setEditable(false);
		add(txtfld);
		
		//buttons are cool! They also do stuff for us
		btncount = new Button("click me!");
		add(btncount);
		//make sure to add an action to the button, or else it will do nothing =(
		btncount.addActionListener(this);
		
		//what do you want to call your GUI?
		setTitle("THIS BE A GUI!");
		JFrame.setDefaultLookAndFeelDecorated(true);
		
		setSize(250,100);
		setVisible(true);	
	}
	


	public static void main(String[] args)
	{
		//call the constructor, make the GUI
		GUIcounter app = new GUIcounter();
	}
	
	@Override
	public void actionPerformed(ActionEvent arg0)
	{
		//every time the button is clicked, add 1 to count and display it
		count++;
		//reset the text in the text field every time count changes
		txtfld.setText("you have clicked " +count+" times");
	}
}

