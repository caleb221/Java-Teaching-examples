/*
 * Caleb Seifert
 * Keyboard in GUI
 * 11/22/16
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Guikey extends JFrame
{
	//field
	JTextField txt1 = new JTextField(10);
	JButton exit = new JButton("exit =\\");
	
	//constructor
	public Guikey()
	{
		exit.addActionListener(new btnmethod());
		txt1.addKeyListener(new keyclass()); // listen for key inputs
		txt1.setEditable(false);
		
		
		JPanel panel = new JPanel();
		panel.setLayout(new FlowLayout());
		panel.add(exit);
		panel.add(txt1);
		
		
		setContentPane(panel);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		pack();
	}
	
	
	public class btnmethod implements ActionListener
	{
		public void actionPerformed(ActionEvent e)
		{
			System.exit(0);
		}
	}
	
	public class keyclass implements KeyListener
	{
		@Override
		public void keyPressed(KeyEvent e) {
			// TODO Auto-generated method stub
		}

		@Override
		public void keyReleased(KeyEvent e) {
			// TODO Auto-generated method stub
		}
		@Override
		public void keyTyped(KeyEvent e) {
			// TODO Auto-generated method stub
			txt1.setText(""+e.getKeyChar());
		}
		
   }
	
	public static void main(String[] args)
	{
		Guikey app = new Guikey();
		app.setVisible(true);
	}
	


}
