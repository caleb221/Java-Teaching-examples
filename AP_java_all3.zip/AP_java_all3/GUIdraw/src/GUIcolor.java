/*
 * Caleb Seifert
 * 11/8/16
 * GUIs with a little more color
 */
import java.awt.*;
import javax.swing.*;

public class GUIcolor extends JPanel
{
	
	private Font font1,font2,font3,font4;
	private String Amessage = "��֪�����Կ�ѧ";;
	
	//constructor
	public GUIcolor()
	{
		this(null);
	}
	
	public GUIcolor(String Amessage)
	{
		font1 =new Font("SansSerif",Font.BOLD,14);
		font2 =new Font("Serif",Font.ITALIC,44);
		font3=new Font("Dialog",Font.BOLD,40);
		font4 = new Font("MonoSpaced",Font.PLAIN,50);
		
		setBackground(Color.BLACK);
	}
	
	public void paintComponent(Graphics g)
	{
		super.paintComponents(g);
		
		Graphics2D g2 = (Graphics2D)g;
		g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, 
								RenderingHints.VALUE_ANTIALIAS_ON);
		
		int height= getHeight();
		int width = getWidth();
		setBackground(Color.BLACK);
		for(int i =0;i<5;i++)
		{
			int fontnum = (int)(Math.random()*5)+1;
			
			switch(fontnum)
			{
			case 1:
				g.setFont(font1);
				break;
			case 2:
				g.setFont(font2);
				break;
			case 3:
				g.setFont(font3);
			default:
				g.setFont(font4);
				break;
			}
			
			float hue = (float)Math.random();
			g.setColor(Color.getHSBColor(hue, 1.0F, 1.0F));
			int x,y;
			x=-50 +(int)(Math.random()*(width+40));
			y = (int)(Math.random()*(height+20));
			
			g.drawString(Amessage, x, y);
		}
	}
		public static void main(String[] args)
		{
			JFrame window = new JFrame("woo!!");
			GUIcolor content = new GUIcolor();
			
			window.setContentPane(content);
			
			window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			
			window.setSize(420, 250);
			window.setVisible(true);
		}	
	}