/*
 * caleb seifert
 * 11/14/16
 * consoles part 1
 */
import java.util.*;

public class consolespart1 
{
	public static void log(String Amessage)
	{
		System.out.println(Amessage);
	}
	public static void main(String[] arg)
	{
		Scanner keys = new Scanner(System.in);
		String mood;
		int num;
		boolean check = false;
		log("hello!\nHow are you feeling today?");
		mood =keys.nextLine();
		check = mood.equalsIgnoreCase("good");
		// if statements help us make decisions in code
		//we take in 2 conditions (parameters) and  
		//check them against each other
		//if the condition is true, then the code in the {squiggly brackets} 
		// is performed, if not then the check is skipped 
		if(check == true)
		{
			Date today = new Date();
			log("Awesome! im glad youre doing well on this fine day of "+today);
		}
		check=mood.equalsIgnoreCase("bad");
		if(check == true)
		{
			log("oh, im sorry dude..dont worry it will get better! =)");
		}
		check = mood.equalsIgnoreCase("meh");
		if(check == true)
		{
			log("i dont know either dude, im a computer");
		}
		log("\nanyway, lets do something else now....choose a number :P ");
		num = keys.nextInt();
		log("your number times 333333 is: "+(num*333333));
	}
}