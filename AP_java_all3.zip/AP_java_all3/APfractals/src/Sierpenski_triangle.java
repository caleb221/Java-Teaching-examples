
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Sierpenski_triangle extends JApplet
{
	private JTextField jtfOrder = new JTextField("0",5);//order
	private Sierpenski_panel tri_panel = new Sierpenski_panel();
	//panel object to update our screen
	
	//constructor
	public Sierpenski_triangle()
	{
		JPanel panel = new JPanel();
		
		panel.add(new JLabel("Enter an Order (try under 10)"));
		panel.add(jtfOrder);
		jtfOrder.setHorizontalAlignment(SwingConstants.RIGHT);
		
		add(tri_panel);
		add(panel,BorderLayout.SOUTH);
		
		jtfOrder.addActionListener(new ActionListener() 
			{
			   	public void actionPerformed(ActionEvent e)
			   	{
			   		tri_panel.setOrder
			   		(Integer.parseInt(jtfOrder.getText()));
			   	}
					
			}
		);
	}//end of constructor
	
	static class Sierpenski_panel extends JPanel
	{
		//fields!
		private int order= 0;
		
		public void setOrder(int outside_order)
		{
			this.order=outside_order;
			repaint();
		}
		
		protected void paintComponent(Graphics g)
		{
			super.paintComponent(g);
			
			Point p1 = new Point(getWidth()/2,10);
			Point p2 = new Point(10,getHeight()-10);
			Point p3 = new Point(getWidth() - 10, getHeight() - 10 );
			
			displayTriangles(g,order,p1,p2,p3);
		}
		
		private static void displayTriangles(Graphics g, int order,
				Point p1,Point p2,Point p3)
		{
			if(order ==0)//BASE CASE!
			{
				g.drawLine(p1.x, p1.y, p2.x, p2.y);
				g.drawLine(p1.x, p1.y, p3.x, p3.y);
				g.drawLine(p2.x, p2.y, p3.x, p3.y);
			}
			else
			{
				//get the midpoint of each triangle
				Point p12 = midpoint(p1,p2);
				Point p23 = midpoint(p2,p3);
				Point p31 = midpoint(p3,p1);
				
				//HERE IS THE RECURSION!
				displayTriangles(g,order-1,p1,p12,p31);
				displayTriangles(g,order-1,p12,p2,p23);
				displayTriangles(g,order-1,p31,p23,p3);
			}
		}//outside display triangles
		private static Point midpoint(Point p1,Point p2)
		{
			return new Point( (p1.x+p2.x)/2, (p1.y+p2.y)/2 );
		}
	}//outside of sierpenski_panel class
	
	public static void main(String[] args)
	{
		JFrame frame = new JFrame("TRIANGLE FRACTAL (Sierpenski)");
		Sierpenski_triangle app = new Sierpenski_triangle();
		frame.add(app);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(400, 400);
		frame.setVisible(true);
	}
}
