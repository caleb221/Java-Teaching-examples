/*
 * 4th period review for the final
 */

import java.util.*;

public class day2 
{
	/*
	 * a function is a small operation that can be called (used)
	 * many times over and over again, we use them a lot in code
	 * lets write a small example
	 */
	public static int add_the_number(int num)
	{
		int ans = 0;
		ans = num + 100;
		return ans;
	}
	
	public static void main(String[] args)
	{
		//keyboard set up
		Scanner keys = new Scanner(System.in);
		
		int users_num=0;// integer (counting) number
		int counter;	// another integer	
		
		String name;//Strings are for text in computers
		
		System.out.println("Hello! what is your name? ");
		name = keys.nextLine();
		System.out.println("Hello "+name);
		System.out.println("lets add a number +100, which number do you"
								+ " want to add?");
		
		users_num=keys.nextInt();
		counter = add_the_number(users_num);
		System.out.println("your new number is: "+counter);
		
		
		/*
		 * the while loop!
		 * while loops differ from for loops in that a for loop repeats a
		 * set number of times, and the while loop can repeat for 
		 * a conditioned set of times 
		 * (may be different each time the code runs)
		 */
		boolean loop_exit=false;
		// we want to make sure our loop will not be infinite
		
		int j=0;
		
		while(loop_exit != true)
		{
			j++;
			if(j == name.length())
			{
				loop_exit = true;
			}
		}
	System.out.println("your name " +name+" has "+j+" letters");	
		/*
		 * algorithms!
		 * algorithms are equations that can do more than just math
		 * they are a set of rules that a computer can follow in a code
		 * and perform a highly desired function
		 * there are mathematical algorithms, graphical algorithms,
		 * 	and data analysis algorithms
		 * they require repetition (repeated events)
		 */
	for(int i=0;i<2;i++)
	{
		for(int j1=0;j1<name.length();j1++)
		{
			if(i%2 == j1%2)
			{
				System.out.println(name.charAt(j1));
			}
		}
		System.out.println("_");
	}
		
	}
}
