

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import javax.swing.Timer;
import java.awt.geom.*;


public class pong extends JPanel implements KeyListener,ActionListener
{
	//our class is now a subclass (lower extension) of JPanel
	//it also uses the key listener and action listener, which give us 
	//the methods to enable keyboard and other such actions in the panel
	
	/*
	 * 				fields!
	 * this is the place we define all our variables that can
	 * be changed and have some type of interaction between methods and
	 * classes
	 */
	private int height,width;
	private Timer t = new Timer(5,this);
	private boolean first;
	
	private HashSet<String> keys = new HashSet<String>();
	
	private final int SPEED=1;
	private int padH=10,padW=40;
	private int bottompadX,topPadX;
	private int inset =10;
	
	private double ballX,ballY,velX=1,velY=1,ballSize=20;
	
	private int scoreTop,scoreBottom;
	/*
	 * 				Constructor!
	 * constructors BUILD the GUI
	 * they set up the first (1st) state of the GUI, giving it life
	 * it is where the class and the data meet, we construct our panel,
	 * our frame (both optional) and connect our Listener(s) to 
	 * the components they need
	 * it is the bone structure of our class
	 * if you want to find a constructor, just look for the
	 * public method that has the SAME name as the class
	 * constructors ALWAYS have the SAME name as the class they are in
	 */
	public pong()
	{
		addKeyListener(this);
		setFocusable(true);
		setFocusTraversalKeysEnabled(true);
		first = true;
		t.setInitialDelay(1000);
		t.start();
	}
	
	protected void paintComponent(Graphics g)
	{
		/*
		 * Graphics are almost as important as data analysis
		 * who would want to use an ugly app? (if its not useful)
		 * the graphics make the interactions between user (you)
		 * and computer more enjoyable and easier to understand
		 */
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D)g;
		height = getHeight();
		width = getWidth();
		
		if(first == true)
		{
			bottompadX= width/2-padW/2;
			topPadX=bottompadX;
			ballX= width/2-ballSize/2;
			ballY= height/2-ballSize/2;
			first = false;
		}
		//bottom pad
		Rectangle bottomPad = new Rectangle(bottompadX,
							height-padH-inset,padW,padH);
		g2.fill(bottomPad);
		
		//top pad
		Rectangle topPad = new Rectangle(topPadX,inset,padW,padH);
		g2.fill(topPad);
		
		//ball
		Ellipse2D ball = new 
				Ellipse2D.Double(ballX,ballY,ballSize,ballSize);
		
		g2.fill(ball);
		
		//scores
		String tscore= "Top Score: "+scoreTop;
		String bscore= "Bottom Score: "+scoreBottom;
		
		g2.drawString(tscore, width-50, height/2);
		g2.drawString(bscore, 10, height/2);
	}
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		/*
		 * the actionPerformed is the method that updates the panel!
		 * it also handles buttons.
		 * if we need a panel to be constantly updated we can 
		 * use this method to do it, the actionPerformed is also
		 * closely tied to the timer! 
		 */
		
		/*
		 * GAME LOGIC!
		 * pong is a game where we pass a ball between two paddles 
		 * (like a flat ping pong)... the walls are hard which means
		 * the ball bounces off of them if a player hits the opponents
		 * wall that is protected by their paddle, the player scores!
		 */
		
		//side walls
		if(ballX <0 || ballX > width-ballSize)
		{
			velX=-velX;
		}
		//top wall
		if(ballY <0)
		{
			velY=-velY;
			scoreBottom +=1;
		}
		//bottom wall
		if(ballY +ballSize > height)
		{
			velY=-velY;
			scoreTop+=1;
		}
		
		//bottom paddle (pad)
		if(ballY +ballSize >= height - padH - inset && velY >0)
		{
			if(ballX +ballSize >= bottompadX && ballX <=bottompadX +padW)
			{
				velY=-velY;
			}
		}
		
		//top paddle (pad)
		if(ballY <= padH + inset && velY <0)
		{
			if(ballX +ballSize >= topPadX && ballX <= topPadX +padW)
			{
				velY=-velY;
			}
		}
		
		ballX += velX;
		ballY += velY;
		
		if(keys.size() ==1)
		{
			if(keys.contains("LEFT"))
			{
				bottompadX -=(bottompadX>0) ? SPEED : 0 ; 
			}
			else if(keys.contains("RIGHT"))
			{
				bottompadX += (bottompadX < width - padW) ? SPEED :0;
			}
		}
		
		//AI! 0_0
		double delta = ballX - topPadX;
		if(delta > 0)
		{
			topPadX += (topPadX < width - padW) ? SPEED : 0;
		}
		else if(delta <0)
		{
			topPadX -= (topPadX > 0) ? SPEED : 0;
		}
		repaint();
	}
	public static void main(String[] args)
	{
		JFrame frame = new JFrame("PONG!! ^_^");
		pong PONG = new pong();
		frame.setContentPane(PONG);
		frame.setSize(300,700);
		frame.setResizable(false);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}

	@Override
	public void keyPressed(KeyEvent e) {
		/*
		 * the KeyEvent e variable is the User's (you) Variable
		 * e is the action (in KeyEvent it is the key pressed by user)
		 * of the user, every time you press a key or push a button
		 * or take any other type of action, the value of e changes!
		 * you change e with  your actions! =)
		 */
		int keypressed = e.getKeyCode();
		/*
		 * the switch statement is similar to an if-else statement
		 * the main difference is that we switch on ONE (1) variable
		 * and each case is given a different operation
		 */
		switch(keypressed)
		{
		case KeyEvent.VK_LEFT:
			keys.add("LEFT");
			break;
		case KeyEvent.VK_RIGHT:
			keys.add("RIGHT");
			break;
		}
		
		
	}

	@Override
	public void keyReleased(KeyEvent arg0) {
		
		int keypressed = arg0.getKeyCode();
		
		switch(keypressed)
		{
		case KeyEvent.VK_LEFT:
			keys.remove("LEFT");
			break;
		case KeyEvent.VK_RIGHT:
			keys.remove("RIGHT");
			break;
		}
		
	}

	@Override
	public void keyTyped(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}

}
