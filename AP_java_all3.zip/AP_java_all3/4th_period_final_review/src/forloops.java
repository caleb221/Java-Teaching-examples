/*
 * Caleb Seifert
 * for loops
 */
//a for loop is used when we want to repeat an operation and
//we know how many times we want that operation repeated
public class forloops 
{
	public static void main(String[] args)
	{
		for(int i=0;i<15;i++)
		{//we want the loop to repeat 14 (i-1) times
		// i adds one to itself after every loop
		// the loop operations are contained in the { } squiggly brackets
		 System.out.println("the loop has repeated: "+i+" times");
		}
	}
}