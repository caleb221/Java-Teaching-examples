package first_calculator;

/*
 * the first calculator!
 */
import java.util.*;

public class calc1 
{
	public static void main(String[] args)
	{
		Scanner keys = new Scanner(System.in);//keyboard
		int base =0;
		int height =0;
		int area =0;
		
		System.out.println("hello! please input the base of your triangle:");
		base = keys.nextInt();//take in the int for base
		System.out.println("what about your height?");
		height = keys.nextInt();//take in the int for height
		
		area = (base*height)/2;//calculate the area of a triangle
		System.out.println("your area is: "+area);//tell the user!
		
		/********************************
		 * THIS IS A TRIANGLE, YOU NEED TO DO A CIRCLE
		 * AREA FORMULA IS ON THE BOARD
		 * DUE BY THE END OF CLASS (this is a classwork grade)
		 ********************************/
	}
}
