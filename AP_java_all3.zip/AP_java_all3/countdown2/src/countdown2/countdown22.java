/*
 * Caleb Seifert
 * 10/17/16
 * Counting downwards and time
 * 
 */

package countdown2;

import java.util.*;

public class countdown22 
{
	
	public static void main(String[] args)
	{
		
		Date today = new Date();// get the date 
		System.out.println(today);
				
		int countdown = 5;
		int input = 0;
		Scanner keys = new Scanner(System.in);
		System.out.println("\nHello! please pick a number, maybe 213?");
		input = keys.nextInt();
		
		while( countdown < 0 || input != 213)// while countdown is bigger than 0 or input is not 213
		{
			System.out.println("WHY YOU NO CHOOSE 213????\nTRY AGAIN\n");
			input=keys.nextInt();
			countdown--;// same as countdown=countdown -1;
			System.out.println("YOU HAVE "+countdown+" Chances left");
			
			if (countdown ==0)
			{				//when the user has used all chances 
				System.out.println("YOU CANT LISTEN!\n NO MORE PROGRAM FOR YOU!");
			}
		}
		
		System.out.println("WOOHOO!!! 213 is a great number");
		keys.close();
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
