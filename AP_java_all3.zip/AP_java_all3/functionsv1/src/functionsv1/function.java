package functionsv1;

import java.util.*;
/*
 * Functions! 
 * A function is a small process that we can have OUTSIDE of main
 * this idea will become useful when we start to program more
 * complex codes, and especially when making games!
 * 
 * the idea is this:
 * i have one process that needs to be done in many places, instead of re-writing 
 * the process over and over, i can write a function and simply "call" or access 
 * the function wherever I need in my code
 */

public class function 
{
	/*
	 * Lets make a simple function that will shorten System.out.println(""); for us
	 */
	public static void message(String words)//F(x) is now named message(String)
	{
		System.out.println(words);//f(X) = System.out.println();
	}
	
	public static int add2(int num1,int num2)//name G(x) to add 2 and take in 2 numbers
	{
		int ans=0;//we need to "return" or give back the correct answer
		ans = num1+num2;//do the operation
		return ans;//give our answer back
	}
	
	public static void main(String[] args)
	{
		message("hello!");//call the function by name! remember it needs a String
						 // here, the string is "hello!"
		int added=0;
		added = add2(3,5);//call the add2 function, it asks for 2 numbers so we
						 // need to make sure we give it those 2 numbers
						// the return statement makes the added variable equal to
					   // the  "ans" variable in the add2 function!
		message(""+added);
	}
}
