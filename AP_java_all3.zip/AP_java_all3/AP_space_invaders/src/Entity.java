import java.awt.Graphics;
import java.awt.Rectangle;

/*
 * this class handles the position and 
 * collisions between the sprites 
 */

public abstract class Entity 
{
	//fields!
	
	//current location of X
	protected double x;
	//current location of Y
	protected double y;
	//current sprite
	protected Sprites sprite;
	//horizontal speed
	protected double dx;
	//vertical speed (aliens and bullets)
	protected double dy;
	
	//rectangle to draw our collision space (bullet hits alien)
	private Rectangle me = new Rectangle(); 
	
	//the other objects in the game
	private Rectangle him = new Rectangle();
	
	//constructor
	public Entity(String ref, int x, int y)
	{
		this.sprite = SpriteStore.get().getSprite(ref);
		this.x = x;
		this.y = y;
	}
	
	public void move(long delta)
	// long is a longer form of double (more memory)
	{
		//updates the game movements
		x += (delta *dx)/1000;
		y += (delta *dy)/1000;
	}
	
	public void setHorizontalSpeed(double dx)
	{
		this.dx = dx;// set our X speed!
	}
	
	public void setVerticalSpeed(double dy)
	{
		this.dy=dy;//set our Y speed!
	}
	
	public double getHorizontalMovement()
	{
		return dx;//get the data to pass for another class
	}
	
	public double getVerticalMovement()
	{
		return dy;
	}
	
	public void draw(Graphics g)
	{
		sprite.draw(g, (int) x,(int) y);
	}
	public void doLogic()
	{
		//this is just a passing method, we will call it from the 
		//main game class and have it access the individual entity classes
		//through this method
	}
	
	public int getX()
	{
		return (int) x;
	}
	public int getY()
	{
		return (int) y;
	}
	
	public boolean collidesWith(Entity other)
	{
		//set the boundaries for our entity (make a box around it)
		me.setBounds((int) x,(int) y,sprite.getWidth(),sprite.getHeight());
		
		him.setBounds((int) other.x,(int) other.y,
					other.sprite.getWidth(), other.sprite.getHeight());
		return me.intersects(him);
	}
	
	//notification method, lets us know when 2 entities have collided
	public abstract void collidedWith(Entity other);
	
	
}
