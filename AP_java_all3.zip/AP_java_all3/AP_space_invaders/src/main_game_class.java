/*
 * Space Invaders!
 * main game class
 * 
 */
//Canvas.getBufferStrategy;
import java.awt.*;
import java.awt.event.*;

import java.awt.image.BufferStrategy;

import javax.swing.*;
import java.util.ArrayList;

public class main_game_class extends Canvas
{
	//fields!
	
	private BufferStrategy strategy;//different class, the strategy
	public boolean gameRunning;
	private ArrayList entities = new ArrayList(); 
	//game entities (objects, pictures, data)

	private ArrayList removeList = new ArrayList();
	//when we kill an alien or something, we need to remove it
	
	private Entity ship;//ship entity (different class)
	
	private double moveSpeed = 200;//how fast are we going to go?
	
	private long lastFire = 0;//time from last fire (from user)
	
	private long FiringInterval = 500;//time between firing
	
	private int alienCount;//how many aliens are there?
	
	private String message = "";//tell the user something
	
	private boolean waitingForKeyPress = true;//is there a key pressed?
	
	private boolean leftPressed = false;
	private boolean rightPressed = false;
	private boolean firePressed = false; // user control checks
	
	private boolean logicRegquiredThisLoop=false;
	//is there something special happening in this loop?
	
	//constructor!
	public main_game_class()
	{
		JFrame frame = new JFrame("SPAACCEEE IINNNVVAAADDDEERRSSS 0_0");
				
		//create the panel object, and put it into the frame 
		//all in one line of code!
		JPanel panel = (JPanel) frame.getContentPane();
		
		panel.setPreferredSize(new Dimension(800,600));
		panel.setLayout(null);
		
		panel.add(this);//put the game into the panel
		
		setIgnoreRepaint(true);//canvas method that will be overridden later
		
		frame.pack();
		frame.setResizable(false);
		frame.setVisible(true);
		
		frame.addWindowListener(new WindowAdapter() 
						{
							public void windowClosing(WindowEvent e)
							{
								System.exit(0);
							}
						}
					);
		addKeyListener(new keyInputHandler() );//we will create this class
	
		requestFocus();
		
		createBufferStrategy(2);
		strategy =  getBufferStrategy();
		
		initEntites();
		
	}//end of constructor
	
	public void startGame()
	{
		//clear the screen
		entities.clear();
		//create new sprites
		initEntites();
		
		//reset the keyboard
		leftPressed = false;
		rightPressed = false;
		firePressed = false;
	}
	
	private void initEntites() 
	{
		ship = new shipEntity(this,
			"rainbowbunchie.jpg",370,550);
		
	}
	
	/*
	 * now we write the main game loop
	 * the BRAIN of space invaders
	 * what we need to do in this loop:
	 * -move the game entities
	 * -draw the screen graphics
	 * -update our game events
	 * -check input
	 */
	public void gameLoop()
	{
		long lastLoopTime=System.currentTimeMillis();
		//how long our game has been running
		
		while(gameRunning)//keep the loop going until
		{				 // the game is over
			long delta = System.currentTimeMillis() - lastLoopTime;
			lastLoopTime = System.currentTimeMillis();
			//keep track of time in our game!
			
		}
	}
	
	
	private class keyInputHandler extends KeyAdapter
	{
		private int pressCount =1;
		//store the number of times the user has pressed a key
	
	public void keyPressed(KeyEvent e)
	{
		if(waitingForKeyPress)
		{
			return;
		}
		
		if(e.getKeyCode() == KeyEvent.VK_LEFT)
		{
			leftPressed = true;
		}
		if(e.getKeyCode()==KeyEvent.VK_RIGHT)
		{
			rightPressed = true;
		}
		if(e.getKeyCode()==KeyEvent.VK_SPACE)
		{
			firePressed = true;
		}
	}	
	public void keyReleased(KeyEvent e)
	{
		if(waitingForKeyPress)
			return;
		
		if(e.getKeyCode()==KeyEvent.VK_LEFT)
			leftPressed = false;
		
		if(e.getKeyCode()== KeyEvent.VK_RIGHT)
			rightPressed=false;
		
		if(e.getKeyCode()==KeyEvent.VK_SPACE)
			firePressed = false;
	}
	
	public void keyTyped(KeyEvent e)
	{
		if(waitingForKeyPress)
		{
			if(pressCount == 1)
			{
				waitingForKeyPress =false;
				startGame();
				pressCount = 0;
			}
			else
			{
				pressCount++;
			}
		}
		//ESCAPE KEY!
	if(e.getKeyChar() == 27)
	{
		System.exit(0);
	 }	
	
	}
	
	}//end key handler class
	
	public static void main(String[] args)
	{
		main_game_class gg = new main_game_class();
		
		gg.gameLoop();
	}
	
	
	
	
	
}






