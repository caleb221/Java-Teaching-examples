


import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.HashMap;
import javax.imageio.ImageIO;


//this class will load our images from the background files
public class SpriteStore 
{
	//fields
	
	//single image instance of this class
	private static SpriteStore single = new SpriteStore();
	
	public static SpriteStore get()
	{
		return single;
	}
	
	private HashMap sprites = new HashMap();
	
	public Sprites getSprite(String ref)
	{
		//if there is already an image, then go ahead and return
		// that image
		if(sprites.get(ref) != null)
			return (Sprites) sprites.get(ref);
		
		//otherwise, lets load our image
		BufferedImage sourceImage = null;
		
		try 	
		{
			/* Try is a piece of code that we write when we need to
			 * execute a piece of code that we are "unsure" about
			 * we use it when loading images to avoid runtime error,
			 * and for similar type operations (audio, other resources)
			 */
			File url = new File(ref);
			if(url == null)
			{
				fail("Can't find your file: "+ref);
			}
			sourceImage = ImageIO.read(url);			
		}
		catch(IOException e)
		{
			fail("Failed to load: "+ref);
		}
		//now we want to draw the image
		// here we are using Java's accelerated 2D engine
		
		//set up our environment
		GraphicsConfiguration gc = 
						GraphicsEnvironment.getLocalGraphicsEnvironment()
									.getDefaultScreenDevice()
									.getDefaultConfiguration();
		//load the image into the 2d accelerated Engine
		Image image = gc.createCompatibleImage(sourceImage.getWidth()
						, sourceImage.getHeight(),Transparency.BITMASK);
		//draw the image into the 2d accelerated engine
		image.getGraphics().drawImage(sourceImage, 0, 0, null);
		
		Sprites sprite = new Sprites(image);
		sprites.put(ref, sprite);
		return sprite;
	}
	
	private void fail(String message)
	{
		/*
		 * when an image load fails we have to make sure we exit the game
		 */
		System.err.println(message); 
		System.exit(0); 
	}
}
