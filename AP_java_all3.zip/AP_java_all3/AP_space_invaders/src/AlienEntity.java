/*
 * 
 */

public class AlienEntity extends Entity
{
	main_game_class game;
	private double moveSpeed = 75;
	/*
	 * lets make an alien 0_0
	 */
	public AlienEntity(String ref,int x,int y)
	{
		super(ref,x,y);
		this.game=game;
		dx = -moveSpeed;
	}
	
	public void move(long delta)
	{
		//set boundaries for these aliens...make sure they dont
		//fall off the screen
		if((dx<0) && (x<10))//left side walls
		{
			game.updateLogic();
		}
		if((dx<0)&& (x>750))//right side walls
		{
			game.updateLogic();
		}
		super.move(delta);
	}
	/*
	 * ALIEN LOGIC X_X 
	 */
	public void doLogic()
	{
		dx=-dx;// move us down the screen
		y+=10;
		if(y>570)//if the aliens touch the ground, they take over the planet
		{		// and we die X( (570 is the "ground" in pixels)
			game.notifyDeath();
		}
	}
	public void collidedWtih(Entity other)
	{
		//the alien collisions are handled elsewhere
	}
	
	

}
