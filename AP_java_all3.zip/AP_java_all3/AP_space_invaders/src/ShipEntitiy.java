/*
 * The class that will handle the ship and its data
 */
public class ShipEntitiy extends Entity
{
	private main_game_class game;
	
	public ShipEntitiy(main_game_class game, String ref, int x, int y)
	{
		super(ref,x,y);// send the reference file (picture) to the 
					  // super class! remember ch12
		
		this.game=game;// use the current game 
	}
	
	public void move(long delta)
	{
		if(dx< 0 && x > 10) // check the left boundaries
			return;
		if(dx>0 && x >750)//check the right boundaries
			return;
		//if we can move (inside boundaries) then call super and 
		//move our game piece 
		super.move(delta);
	}

	public void collidedWith(Entity other)
	{
		//if the alien touches our ship, we die =(...they like to eat us
		if(other instanceof AlienEntity)
		{
			game.notifyDeath();
		}
	}
}
