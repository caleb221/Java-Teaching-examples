/*
 * lets make a class for our shots!
 */

public class ShotEntity extends Entity
{
	private double moveSpeed = -300;//how fast?
	private main_game_class game;
	private boolean used = false;//is our shot used?
	
	public ShotEntity(main_game_class Game,String sprite
			,int x,int y)
	{
		super(sprite, x, y);
		this.game = game;
		dy = moveSpeed;
	}
	public void move(long delta)
	{
		//lets move!
		super.move(delta);
		if(y < -100)
		{
			game.removeEntity(this);
			//remove a bullet if it goes off screen
		}
	}
	public void collidedWith(Entity other)
	{
		if(used == true)
		{
			return;
		}
		if(other instanceof AlienEntity)
		{
			game.removeEntity(this);
			game.removeEntity(other);
			game.notifyAlienKilled();
			used=true;
		}
	}
}
