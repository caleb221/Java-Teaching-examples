/*
 * This class displays the sprites (graphics in pictures)
 * onto our screen!
 * 
 */

import java.awt.Graphics;
import java.awt.Image;

public class Sprites 
{
	private Image image;//our picture
	
	//lets make a new sprite
	public Sprites(Image image)
	{
		this.image = image;
	}
	
	public int getWidth()
	{
		return image.getWidth(null);
	}
	
	public int getHeight()
	{
		return image.getHeight(null);
	}
	
	public void draw(Graphics g, int x, int y)
	{
		g.drawImage(image, x, y, null);
	}
}
