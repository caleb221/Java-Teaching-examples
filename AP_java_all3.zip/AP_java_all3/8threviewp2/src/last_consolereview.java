/*
 * Caleb Seifert
 * 11/15/16
 * Console review part 2
 */

import java.util.*; // this is a library!
					// we use them to import many different functions
					// they give us access to the function so that we do not have to write 
					// all of the code, we can simply use the functions..like Scanner!

public class last_consolereview 
{
	public static void main(String[] args)
	{
		int num =0;
		int num_array[]=new int[5]; // declare an array, this is not a primitive data type
								// arrays hold many values in one variable (remember the window?)
		System.out.println("Hello! this code will show you a for loop and a while loop");
		for(int i=0;i<10;i++) // this is a for loop, it repeats whatever code is in
							 // the {Squiggly brackets} however many times you would like
							//here, we have it set to loop 9 times!
		{
			System.out.println("���� ��  �� ��!");
		}
		
		while ( num <20) // this is a while loop, it is different from 
		{				// a for loop because it checks the condition (num<20)
					   // after each time it loops, this can be useful for checking input,
					  // but is also dangerous because we can have infinite loops happen
			System.out.println("THIS IS A WHILE LOOP 0_0 it has repeated "+num+" times");
			num++;
		}
		
		/* ========================================================================
		 * 				LOGICAL OPERATORS
		 *  logical operators help us to make comparisons in our code
		 *  they are:
		 *  	== --> equals
		 *      != --> not equal
		 *      <  --> less than
		 *      >  --> greater than
		 *      >= --> greater than or equal too
		 *      <= --> less than or equal too
		 *      || --> or
		 *      && --> and
		 *  these operators work the same way they would in math
		 * they are most commonly found in for loops, while loops, and if statements
		 * =========================================================================
		 */
		// algorithms are equations in computer science that do more than just math
	}

}









