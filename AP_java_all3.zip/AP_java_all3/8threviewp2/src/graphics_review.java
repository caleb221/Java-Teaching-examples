/*
 * Caleb Seifert
 * 11/17/16
 * Graphics review
 */
import java.awt.*;
import javax.swing.*;

public class graphics_review  extends JPanel
{
	//here is our field
	Font f1 = new Font("SansSerif", Font.BOLD,70);
	Font f2 = new Font("MonoSpaced", Font.BOLD,20);
	
	//constructor
	public graphics_review()
	{
		this.setBackground(Color.BLACK);//sets the background color 
		
		JFrame frame = new JFrame("FRAME!");
		frame.setContentPane(this);
		frame.setSize(250, 200);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
	
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g); // enables the use of any previous graphics (in this case, 
								// the background color) 
		g.setFont(f1); // set the font
		int x = 50;		// x-Dimensions in pixels
		int y=90;	   // y-dimensions in pixels
		g.setColor(Color.red); // set the text color to red
		g.drawString("�й� �� �Ǻó�", x, y); // draw a string or message on the panel
		g.setColor(Color.ORANGE);
		g.setFont(f2);
		g.drawString("hello! ", x+25, y+50);
		g.setColor(Color.cyan);
		g.drawRect(x+100, y+30, 20, 20);
		g.fillRect(x+125, y+30,	20, 20);
		g.drawOval(x+150, y+30,	20,	20);
		g.setColor(Color.green);
		g.fillOval(x+175, y+30, 22, 22);
		g.setColor(Color.yellow);
		g.fillOval(x+200, y+50,	 75, 75);
		g.setColor(Color.black);
		g.fillOval(x+210, y+70, 20,20);
		g.fillOval(x+235, y+70, 20,20);
		g.drawLine(x+210, y+100, x+2450, y+100);
	}
	

	public static void main(String[] args)
	{
		graphics_review app = new graphics_review(); // create the object
		
	}
}







