
public class firstGUIevar {

}
