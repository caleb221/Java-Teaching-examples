/*
 * Caleb Seifert
 * 11/17/16
 * graphics review
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class graphics_review extends JPanel
{
	// fields
	Font f1 = new Font("SansSerif" ,Font.BOLD,80);
	Font f2 = new Font("MonoSpaced", Font.BOLD,25);
	JButton btn1 = new JButton("click for more!");
	
	public graphics_review()
	{
		this.setLayout(new FlowLayout());
		this.setBackground(Color.black);
		btn1.addActionListener(new method());
		//this.add(btn1);
		
		JFrame frame = new JFrame("W0o0o0o0o!");
		frame.setContentPane(this);
		frame.setSize(300, 250);
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g); // use the super class with graphics variable g
								// this enables the use of any graphics/ colors used in the	
								// the constructor
		
		g.setColor(Color.green); // set the text color to green
		g.setFont(f1);			//set the font
		int x =50;				// x-dimension in pixels
		int y =90;				// y-dimension in pixels
		g.drawString("���", x, y); // draw a string that says hello
		g.setFont(f2);				//set a different font
		g.drawString("Hello", x+30, y+45);	// say hello again (draw a string)
		g.setColor(Color.cyan);				// set the color to cyan
		g.drawRect(x+50, y+50,20, 20);	//draw a rectangle (square)
		g.fillRect(x+75, y+75, 30, 30);	// draw a filled rectangle (square)
	}
	public class method implements ActionListener 
	{
		public void actionPerformed(ActionEvent e)
		{
		graphics_review newapp = new graphics_review();//create a new object
			
		}
	}
	
	public static void main(String[] args)
	{
		graphics_review app = new graphics_review();
	}
}
