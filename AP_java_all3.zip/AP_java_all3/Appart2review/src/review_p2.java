/*
 * Caleb Seifert
 * 11/15/16
 * Review
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*; // GUI libraries

public class review_p2 extends JFrame //"extends" tells us we are now creating a subclass of JFrame
{
	// here are the FIELDs, this is where we define  variables that are used in the GUI and
	// may need to be used in more than one class/constructor
	
	JButton btn = new JButton("Translate"); // calls the JButton constructor
	static JTextField input_txt = new JTextField(10); // creates a JTextfield named input_txt
	static JTextField output_txt = new JTextField(10); // calls JTextField Constructor
	String output; // lets us print the output
	
	public review_p2() // this is our constructor, it builds the GUI
	{
		translate_method action = new translate_method();// construct our method so we 
														// can use it inside the GUI panel
		
		input_txt.addActionListener(action); // connect action listener to input textfield
		btn.addActionListener(action); // connect action listener to the button
		output_txt.setEditable(false);
		JPanel panel = new JPanel(); // call the JPanel constructor so we do not have to 
									// construct a panel from scratch (saves a lot of time)
		panel.setLayout(new FlowLayout()); // set the layout for the panel
		panel.setBackground(Color.GREEN);
		
		JLabel lbl1 = new JLabel("what word would you like translated? ");
		panel.add(lbl1);
		panel.add(input_txt); // put the input text field right after the label
		JLabel lbl2 = new JLabel("your translation is:");
		panel.add(btn); // put the button after the input text field
		panel.add(lbl2);
		panel.add(output_txt); // the last thing we show the user is the output text field
		
		setContentPane(panel); // put all of out panel onto the frame (part of JFRAME) 
		pack();               // JFrame method 
		setTitle("Pig Latin!"); //  set the title of the frame
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // make the exit buttons work
		setLocationRelativeTo(null);		//let the starting position be chosen by computer
	}
	
	public static String translator(String message)
	{
		String word = message; //
		String output="hello!"; // we never want to return a null string, initialize it!
		boolean check = false; // set the boolean to false, just to make sure 
		String[] vowels = {"a","e","i","o","u"}; // an array that contains all the vowels
		
		String firstletter = word.substring(0, 1);// the first letter in a string
		
		for (int i=0; i<vowels.length;i++)// repeat for the whole list of vowels (4)
		{
			check=vowels[i].equalsIgnoreCase(firstletter);
			//here we are checking each vowel (array[i]) to see if it matches
			//the first letter in our given word
			if(check == true)
			{
				// if a vowel is found exit the loop
				break;
			}
		}
		if(check == true)
		{
			//vowel words
			output = word+"way";
		}
		else
		{
			//non-vowel words
			output = word.substring(1,word.length())+firstletter+"ay";
		}
		return output;// gives us the translation back
	}
	
	public class translate_method implements ActionListener
	{
		public void actionPerformed(ActionEvent e)
		{
			String input = input_txt.getText();
			String ans = translator(input);
			
			output_txt.setText(""+ans);
		}
	}
	
	public static void main(String[] args)
	{
		review_p2 piglatin = new review_p2(); //create the object for our class
		
	// we want to see our object (and all the hard work we put into it!) so we say...
		piglatin.setVisible(true);
	}
}

