/*
 * Caleb Seifert
 * 10/27/16
 * Array searching
 * 
 */


package array_search;
import java.util.Scanner;

public class looking_for_a_letter
{
	public static void main(String[] args)
	{
		String[] name = new String[5];
		String look;
		boolean check = false;
		String first_letter;
		Scanner keys = new Scanner(System.in);
		
		System.out.println("Hello! please input 5 different names");
		for(int i=0; i<name.length;i++)
		{
			name[i]=keys.nextLine();
			System.out.println("cool! you have "+(i+1)+" out of 5 left to go!");
		}
		
		System.out.println("what is the letter you would like to find? ");
		
		look = keys.nextLine();
		
		for(int n=0; n<name.length;n++)
		{
			first_letter = name[n].substring(0, 1);// takes the first letter of each entered name
			check = look.equalsIgnoreCase(first_letter); // check each name by the first letter
			
			if(check == true)
			{
				System.out.println("\n "+name[n]+" is the "+(n+1)+" name you entered"); // print the name that matches
			}
			
			check = false;//reset for more letters 
		}
	}
}
