/*
 * Object review
 */

import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class objects extends JPanel // class "objects" is now extended by JPanel
{	
	/*
	 * we are making a GUI (graphical user interface) 
	 * it is much prettier than a console application (text only)
	 * we use objects to keep track of what and how things happen in 
	 * our program
	 */
	//fields!
	//create a button object
	JButton button1 = new JButton("~~click me!~~");
	
	//constructor!
	public objects()
	{
		button1.addActionListener(new clicker());
		setLayout(new FlowLayout());
		add(button1);
		setBackground(Color.BLUE);
	}
	/*
	 * this function has CONSTRUCTED (BUILT) the starting point for
	 * my GUI we have added a button 
	 */
	public class clicker implements ActionListener
	{
		/*
		 * this is where we connect our button to an action
		 * button1 -------- action (the action is defined below)
		 * can you tell what this program will do? 
		 */
		public void actionPerformed(ActionEvent e)
		{
			/*
			 * e (we can name it other things too)
			 * is the variable that lives inside the program and 
			 * listens to any action that happens (it is a functioning variable)
			 */
			if(e.getSource() == button1)
			{
				System.exit(0);
			}
		}
	}
	public static void main(String[] args)
	{
		JFrame frame = new JFrame("THIS IS THE FRAME!");
		objects app = new objects();
		frame.setSize(300, 100);
		frame.add(app);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}

}
