import java.util.ArrayList;

public class the_checker 
{
	private ArrayList<Integer> list = new ArrayList<Integer>();
	
	public static ArrayList<Integer> numQuest(ArrayList<Integer> list)
	{
		
		//int k=0;
		int zero =new Integer(0);
		for(int k=0;k<list.size();k++)
		{
			System.out.println("current List: "+list.indexOf(k));
			if(list.get(k).equals(zero))
			{
				System.out.println("removing: "+list.indexOf(k));
				list.remove(k);
				
			}
				
		//k++;
		}
		System.out.println(list);
		return list;
	}
	
	public static void main(String[] args)
	{
		ArrayList<Integer> list = new ArrayList<Integer>();
		list.add(0);
		list.add(0);
		list.add(4);
		list.add(2);
		list.add(5);
		list.add(0);
		list.add(3);
		list.add(0);
		numQuest(list);
		/*for(int k=0;k<20;k=k+2)
		{
			if(k%3==1)
			{
				System.out.println(""+k);
			}
		}*/
		/*
		ArrayList<String> list = new ArrayList<String>();
		list.add("P");
		list.add("Q");
		list.add("R");
		list.set(2,"s");
		list.add(2,"T");
		list.add("u");
		System.out.println(list);
	*/
		
		
		for(int j=1;j<=5;j++)
		{
			for(int k=5;k>=j;k--)
			{
				System.out.print(j+"");
			}
			System.out.println("");
		}
		
	}

}
