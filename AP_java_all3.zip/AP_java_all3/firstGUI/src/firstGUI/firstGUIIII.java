package firstGUI;
/*
 * this is our first example of a GUI program!
 * they are much prettier than the CONSOLE applications (which only use the keyboard)
 * if you will notice, this program will create us a button that we can push
 * --> this is the best way of seeing if something is a GUI program (check for buttons)
 */
import java.awt.*;
import javax.swing.*;//GUI libraries (we will use them A LOT in the future)

public class firstGUIIII 
{
/* A CLASS is the place where we define the structure of our program
 * if your program was a body, the class would be the bones!
 * much like bones, classes can connect to one another through communication lines
 * the class with the "main" function is like the skull (head) all classes without
 * a main must be connected to main so that they can be used 
 * (try using your leg without using your brain :P )
 * 
 * CLASSES CREATE OBJECTS!
 * --> an object is a function or data IN USE by the user 
 * --> objects can change data as they go along in the program
 */
	
	public static void main(String[] args)
	{
		//JOptionPane is a quick GUI creating class (remember from yesterday?)
		//this class has many functions, here we chose the showMessageDialog function
		//							    	  message text       title text
		JOptionPane.showMessageDialog(null, "Hello! I am a GUI ", "TITLE!",0);
	}
}
