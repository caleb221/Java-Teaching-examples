/*
 * caleb seifert
 * 11/14/2016
 * Console review
 */
package console_review;

import java.util.*;

public class part1_review 
{
	public static void log(String Amessage)
	{
		System.out.println(Amessage);
	}
	
	public static void main(String[] args)
	{
		Scanner keys= new Scanner(System.in);
		int num =0;
		int input = 0;
		String name;
		Date today = new Date();
		
		log("Hello! \n what is your name?");
		name = keys.nextLine();
		log("good to see you "+name+ "  on this fine day of "+today);
		
		log("\nLets check a number with an if statement 0_0");
		log("please input a number: ");
		num=keys.nextInt();
		
		if(num < 10) // if statements help make decisions in code
					// we give the statement two conditions, and check them 
					// against each other. if the condition is true the code in
					// {squiggly brackets} is performed, if not then the code moves on
					// we can also make selections (like choosing which button we would
					// like to use) with if statements 
		{
			log("your number is less than 10!"); 
		}
		else if(num <= 20 )
		{
			log("your number is bigger than 20");
		}
		else if(num == 30)
		{
			log("you picked 30!");
		}
		else
		{
			log("you picked a big number");
		}
		
		
	}
	
}
