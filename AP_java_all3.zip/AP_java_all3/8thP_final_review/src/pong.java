/*
 * final review (pong)
 */

import java.awt.*;
import java.awt.event.*;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;

import javax.swing.*;
import javax.swing.Timer;

import java.util.*;

public class pong extends JPanel implements KeyListener, ActionListener
{	/*
	 * pong is now a subclass (lower extension) of JPanel
	 * we are given all of the public field variables and the methods
	 * of JPanel when we extend it to our class 
	 * 
	 * pong also implements a few listeners, what this means is
	 * that we now have the ability to use the methods that will
	 * take input from our keyboard and the panel
	 */
	
	/*
	 * 			fields 
	 * the fields are the place where all our most important variables 
	 * are declared, the PUBLIC variables in the field have access 
	 * to all classes and methods that call it in the proper way
	 */
	
	private int height,width;
	
	private final int SPEED =1;

	private Timer t = new Timer(5,this);
	private boolean first;
	
private HashSet<String> keys = new HashSet<String>();// not on the final
	
	//set up for the pad
	private int padH=10,padW=40;
	private int bottomPadX,topPadX;
	private int inset =10;
	
	//set up for ball
	private double ballX,ballY,velX=1,velY=1,ballSize=20;

	private int topScore,bottomScore;
	
	/*   			constructor!
	 * a constructor is the first set up for a class
	 * it defines how the class will interact with the user through objects
	 * a constructor is kind of like the bone structure of a code
	 * we can build GUI components and connect those components with
	 * the listener(s) of the code
	 * 
	 * if you ever want to find a constructor, all you need to know is
	 * the name of the class
	 * constructors ALWAYS have the same name as the class they are in
	 */
	public pong()
	{
		addKeyListener(this);
		setFocusable(true);
		setFocusTraversalKeysEnabled(true);
		first = true;
		t.setInitialDelay(1000);
		t.start();
	}
	
	@Override
	public void actionPerformed(ActionEvent e)
	{
		/*
		 * the actionPerformed method continuously updates the panel
		 * it is also the place we connect buttons to methods
		 * what this means is that any time we have data that needs
		 * to be updated (for the whole life of the program)
		 * we can put it in the actionPerformed function
		 */
		
		/*				GAME LOGIC
		 * game logic is how we put a game into code!
		 * pong is a simple game, we have 2 paddles on top and bottom
		 * if the ball hits the edges of the walls, it bounces off
		 * if the ball hits the players protected (with paddles)
		 * wall, the other player scores a point, so if the bottom
		 * player hits the top wall, the bottom player gets the point
		 */
		//side walls
		if(ballX < 0 || ballX > width-ballSize)
		{
			velY=-velY;
		}
		//top wall
		if(ballY <0)
		{
			velY=-velY;
			bottomScore+=1;
		}
		//bottom wall
		if(ballY +ballSize > height)
		{
			velY = -velY;
			topScore+=1;
		}
		
		if(ballY+ballSize >= height- padH-inset && velY >0)
		{
			if(ballX +ballSize >= bottomPadX && ballX <= bottomPadX +padW)
			{
				velY=-velY;
			}
		}
		if(ballY <= padH+inset && velY <0)
		{
			if(ballX+ballSize >= topPadX && ballX <= topPadX +padW)
			{
				velY=-velY;
			}
		}
		
		ballX+=velX;
		ballY+=velY;
		
		if(keys.size()==1)
		{
			if(keys.contains("LEFT"))
			{
				bottomPadX -= (bottomPadX >0 ) ? SPEED : 0;
			}
			else if(keys.contains("RIGHT"))
			{
				bottomPadX +=(bottomPadX < width - padW) ? SPEED : 0;
			}
		}
		
		//AI for pong
		double delta = ballX - topPadX;
		if(delta > 0)
		{
			topPadX += (topPadX < width - padW) ? SPEED : 0;
		}
		else if(delta < 0)
		{
			topPadX -= (topPadX > 0) ? SPEED : 0;
		}
		repaint();
	}

	public static void main(String[] args)
	{
		JFrame frame = new JFrame("PONG! ^_^");
		pong PONG = new pong();
		frame.setContentPane(PONG);
		frame.setSize(300,700);
		frame.setResizable(false);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
	
	
	@Override
	public void keyPressed(KeyEvent e)
	{/* the keyPressed method fires off (executes) 
	  * when the user presses a key!
	  * the KeyEvent e is the variable that the execution is stored in
	  * whenever we press down a key, e is changed
	  */
		int keypressed = e.getKeyCode();
		
		/* the switch statement!
		 * the switch statement is much like an if-else statement,
		 * it takes in one parameter (here we use keyPressed)
		 * and checks every case presented to it, what it does when 
		 * that specific case is found happens after the ':' 
		 * every case ends with a 'break'
		 */
		switch(keypressed)
		{
		case KeyEvent.VK_LEFT:
			keys.add("LEFT");
			break;
		case KeyEvent.VK_RIGHT:
			keys.add("RIGHT");
			break;
		}
	
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
	
	int keypressed = e.getKeyCode();
		
		switch(keypressed)
		{
		case KeyEvent.VK_LEFT:
			keys.remove("LEFT");
			break;
		case KeyEvent.VK_RIGHT:
			keys.remove("RIGHT");
			break;
		}
	}
	
	protected void paintComponent(Graphics g)
	{
		/*
		 * Graphics are almost just as important as data analysis!
		 * we make graphics so that the user can enjoy the experience
		 * of using your program. Graphics not only help guide the 
		 * user but also make things a lot simpler for them
		 */
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D)g;
		height=getHeight();
		width=getWidth();
		
		//starting point
		if(first == true)
		{
			bottomPadX= width/2-padW/2;
			topPadX=bottomPadX;
			
			ballX=width/2-ballSize/2;
			ballY=height/2-ballSize/2;
			
			first = false;
		}
		
		Rectangle2D bottomPad = new Rectangle(bottomPadX,
				height-padH-inset,padW,padH);
		g2.fill(bottomPad);
		
		Rectangle2D topPad = new Rectangle(topPadX,inset,padW,padH);
		
		g2.fill(topPad);
		
		Ellipse2D ball = new Ellipse2D.Double(ballX,ballY
				,ballSize,ballSize);
		g2.fill(ball);
		
		//scores!
		String topscore = "Top Score: "+topScore;
		String bottomscore = "Bottom Score: "+bottomScore;
		g2.drawString(bottomscore,10,height/2);
		g2.drawString(topscore, width-50, height/2);
	}
	
	@Override
	public void keyTyped(KeyEvent e) { }

}
