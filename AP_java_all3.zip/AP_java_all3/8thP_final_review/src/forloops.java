/*
 * Caleb Seifert
 * Final Review
 * for loops
 */

/*
 * a for loop is used is when we need to have an operation repeat for
 *		 a set number of times (the code loops)
 */
public class forloops 
{
	public static void main(String[] args)
	{
		for(int i=0;i<15;i++)
		{
			System.out.println("The loop has repeated: "+i+" times 0_0");
		//the loop will print out i, a variable we created that tells
		// java where we are in the loop and how many times we have
		// repeated the code in the '{ }' squiggly brackets
		}
	}
}