/*
 * final review 
 * console basics
 * first quarter
 */

import java.util.*;

public class console_basics 
{
	/*
	 * functions!
	 * a function is a small procedure (process/sequence)
	 * that can be called as many times as we need
	 */
	public static int add100(int num)
	{
		//the function expects an integer, and its name in the function 
		//		is num
		int ans=0;
		ans = num+100;
		return ans;
		//we return (give back) our answer, 
		//which is our original number +100
	}
	
	public static void main(String[] args)
	{
		String name;//strings are text (more than 1 character)
		int num=0;// integers are counting numbers
		Scanner keys = new Scanner(System.in);
		
		System.out.println("Hello! what is your name?");
		name=keys.nextLine();
		System.out.println("hey there "+name);
		System.out.println("pick any number in the universe "
				+ "and I will add 100 to it ^_^");
		num = keys.nextInt();
		
		//calling our function
		int added = add100(num);
		
		System.out.println("your number + 100 = "+added);
		
		/*  while loops
		 * the difference between for and while loops is that
		 * for loops need a set (known) bound that will end the loop
		 * while loops on the other hand can continue repeating
		 * on a condition much like an 'if' statement
		 */
		boolean loop_exit = false;
		int counter =0;
		
		while(loop_exit != true)
		{
			counter++;
			if(counter == 15)
			{
				loop_exit = true;
				System.out.println("the loop has repeated: "+counter
													+" times");
			}
		}
		/*
		 * 		algorithms!
		 * algorithms are like mathematical equations, but they can
		 * do more than just math!
		 * there are algorithms for graphics, data analysis, and also math
		 * algorithms are universal, which means that they can be
		 * coded in ANY programming language that exists (java,python,C ect..) 
		 */
		for(int i=0; i<2;i++)
		{
			for(int j=0;j<name.length();j++)
			{
				if(i%2 == j%2)
				{
					System.out.println("Modulus example:"
									+ "\n "+j+" %2 = "+(j%2));
					/*
					 * i%2 is the modulus function
					 * i is divided by 2, and if the remainder
					 *  is the new value returned
					 *  for example, 0/2 =0, no remainder
					 *  			 1/2 =.5, remainder of .5
					 *  			 2/2 = 1, no remainder
					 *  			 3/2 = 1.5, remainder of 1.5
					 *  			 4/2 = 2, no remainder 
					 */	
					System.out.println(name.charAt(j));
				}
			}
			System.out.println("_");
		}
	}

}





