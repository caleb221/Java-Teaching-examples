package coding_club1;

public class first_class 
{
	public static void main(String[] args)
	{
		System.out.println("Hello World!");
	}
}
