/*
 * Caleb Seifert
 * 3/1/17 
 */

public class variables_explained 
{
	public static void main(String[] args)
	{
		/*
		 * a variable is something we use in code to make
		 * codes change
		 * 
		 * we give names to variables, we then use the name that
		 * we gave the variable to use it.
		 * 
		 * variables are the basis of code
		 * they can be any type of data within a computer
		 *   we accomplish all of our tasks on a computer
		 *   (everything you have ever done on a computer) 
		 *   using mostly variables
		 */
		
		int MYnumber = 10;// create an INTEGER ("whole counting number")
					     // named MYnumber
		System.out.println("MY number is: "+MYnumber);
		System.out.println("\n...");
		MYnumber = 10 + 2;// this is one way to change a variable!
		System.out.println("MY Number is now: "+MYnumber);
	}

}
