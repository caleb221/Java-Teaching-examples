/*
  Caleb Seifert
  First program ever! =)
 */

/*
 * we write code in classes, they "hold"
 * the programs we write
 */
public class first_program 
{
	/*
	 * "main" is where the programs we write are
	 * actually executed (eclipse looks for "main"
	 * and does (performs) the actions inside it)
	 * ** every java application needs a main, we will
	 *  see it a lot in Computer Science**
	 */
	public static void main(String[] args)
	{
		System.out.println("Hello class!");/* give a text output! */
	}
}
