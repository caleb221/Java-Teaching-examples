package if_statements;

/*
 * the IF statement helps us to make desicions in our code!
 * here we will write a program that will tell us if we chose number 1 or 2
 */
import java.util.*;


public class if_statements 
{
	public static void main(String[] args)
	{
		Scanner keyboard = new Scanner(System.in);//setting up our keyboard
		int user_input =0;
		
		System.out.println("Hello! please choose 1 or 2, then press enter =) ");
		user_input = keyboard.nextInt();//get the number from the user 
		
		if(user_input == 1) //this is an IF statement
		{					//here we are checking IF user_input is equal to 1
							// if it is, then we do the stuff inside the { }
							//if it is not, then the code inside the { } does NOT
							//happen
			System.out.println("YOU CHOSE 1!!");//code that will happen if we chose 1
		}			
		if(user_input == 2)
		{
			System.out.println("you chose 2!! thats great!");
		}
	}
}
