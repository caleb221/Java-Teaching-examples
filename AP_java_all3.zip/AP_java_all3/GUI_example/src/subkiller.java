/*
 * Caleb Seifert
 * Game #1 =)
 */

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class subkiller extends JPanel
{
	public static void main(String[] args)
	{
		JFrame window = new JFrame("MY FIRST GAME =)");
		subkiller app = new subkiller();
		window.setContentPane(app);
		window.setSize(600,480);
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.setResizable(false);
		window.setVisible(true);
	}
	
	private Timer timer;
	private int width, height;
	private Boat boat;
	private Bomb bomb;
	private Sub sub;
	
	
	public subkiller()
	{
		setBackground(new Color(0,200,0));
		ActionListener action = new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				if(boat !=null)
				{
					boat.updateForNewFrame();
					sub.updateFornewFrame();
					//bomb.updateforNewframe();
				}
				repaint();
			}
		};
		timer = new Timer(30,action);
		addMouseListener(new MouseAdapter() 
					{
						public void mousePressed(MouseEvent e)
						{
							requestFocus();
						}
					});
		
		addFocusListener(new FocusListener() 
				{
					public void focusGained(FocusEvent e)
					{
						timer.start();
						repaint();
					}
					public void focusLost(FocusEvent e)
					{
						timer.stop();
						repaint();
					}
				});
		addKeyListener(new KeyAdapter()
		{
			public void keyPressed(KeyEvent e)
			{
				int keypressed = e.getKeyCode();
				if(keypressed == KeyEvent.VK_LEFT)
				{
					boat.centerX-=15;
				}
				else if( keypressed == KeyEvent.VK_RIGHT)
				{
					boat.centerX+=15;
				}
				else if(keypressed == KeyEvent.VK_DOWN)
				{
					//if(bomb.isFalling == false)
					//	bomb.isFalling = true;
				}
			}
		});
		
	}//end constructor
	
	
	
	
	
	
	
	
	
	
	
	
	
	public class Bomb
	{
		
	}
	
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);//get any previous graphics settings and
								// use them
		
		Graphics2D g2 = (Graphics2D)g; //change to 2D graphics
		
		//enable the better smoothing graphics (make stuff look better)
		g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING
							,RenderingHints.VALUE_ANTIALIAS_ON);
		
		if(boat==null)//if there is no game started
		{
			width=getWidth();//how long are we?
			height=getHeight();//how tall are we?
			boat = new Boat();//lets get a new boat!
			sub= new Sub();// maybe a new submarine too!
			bomb = new Bomb();//whats a new submarine without a new bomb??
		}
		if(hasFocus())
		{
			g.setColor(Color.cyan);
		}
		else
		{
			 g.setColor(Color.YELLOW);
			 g.drawString("~~Click to play!~~", 20, 30);
			 g.setColor(Color.gray);
		}
		g.drawRect(0, 0, width-1, height-1);
		g.drawRect(1, 1, width-2, height-2);
		g.drawRect(2, 2, width-2, height-2);
		
		boat.draw(g);
		sub.draw(g);
		//bomb.draw(g);
		
	}
	
	
	
	
	public class Boat
	{
		int centerX,centerY;// the center of our boats location
		Boat()
		{
			centerX=width/2; // cut the screen in half and put X there
			centerY = 80;//put Y 80 pixels(screen squares) above 0
		}
		void updateForNewFrame()
		{
			if(centerX < 0 )//make sure we are not going off the screen!
			{
				centerX=0;// this does not allow us to go off the screen
			}
			else if (centerX > width)// make sure we are not going
									// off the other side of the screen
			{
				centerX=width;//do not allow the boat to go off screen
			}
		}
		void draw(Graphics g)//here we draw the boat! pick a color and
		{					// a shape!
			g.setColor(Color.CYAN);// the color of the boat!
			g.fillRoundRect(centerX-40, centerY-20, 80, 40, 20, 20);
			//draw the boat!
		}
	}
	
	public class Sub
	{
		//fields
		int centerX,centerY;// center for the submarine
		boolean isMovingLeft; //is the sub moving left?
		boolean isMovingRight;// what about the right?
		int explosionFrameNum;// if we explode, lets make it awesome!
		boolean isExploding;// are we exploding?
		
		//constructor
		public Sub()
		{
			centerX = (int) ((width)*Math.random());//random X value
			centerY= height/2; //constant Y value
			isExploding=false;// we dont start off exploding
			//random chance of moving left or right (boolean)
			isMovingLeft = (Math.random() <.5);
		}
		//update each data point of our sub for each new frame we paint
		void updateFornewFrame()
		{
			//if we are exploding, lets make sure our frame updates it
			if(isExploding)
			{
				explosionFrameNum++;//add a frame number to the explosion
				//15 frames to explode ( you can make this longer if you 
				//want
				if(explosionFrameNum == 15)
				{
					centerX=(int)(width*Math.random());//re-establish our sub
					centerY=height/2;//y is constant
					isExploding = false;//we are done exploding after 15
					isMovingLeft=(Math.random() <.5);//random movement
				}
			}
			else 
			{
				if((Math.random() < .4))// here, we switch our direction
				{
					isMovingLeft = !isMovingLeft;//switch the boolean
				}
				if(isMovingLeft)
				{	
					centerX-=15;//move the sub 5 pixels to the left each frame
					if(centerX<=0)//if we hit the end of the screen
					{
						centerX=0;//we dont want to keep going off the screen
						isMovingLeft = false;//move right, there is no more left
					}
				}
				else
				{
					centerX+=15;//add 5 pixels to the right each frame
					if(centerX > width)//if we hit the far right of the board
					{
						centerX=width;//we dont want to go offscreen
						isMovingLeft = true;//move us back left now!
					}
				}
			}
		}//end update for new frame
		
		void draw(Graphics g)
		{
			g.setColor(Color.black);//color of submarine
			g.fillOval(centerX-3, centerY-15, 60, 30);
			g.setColor(Color.cyan);
			
			if(isExploding)//are we exploding? if so draw the explosion!
			{
				g.setColor(Color.YELLOW); //outer ring of explosion
				g.fillOval(centerX-4*explosionFrameNum,
						   centerY-2*explosionFrameNum,
						  8*explosionFrameNum,
						  4*explosionFrameNum);
				
				g.setColor(Color.red);//inner red ring explosion
				g.fillOval(centerX-4*explosionFrameNum,
						   centerY-explosionFrameNum/2,
						  4*explosionFrameNum,
						    explosionFrameNum);
			}
		}
	}//end sub class

}
