/*
 * Caleb Seifert
 * 11/8/16
 * a little more on graphics
 */
 package colorfulStrings;
 import java.awt.*;
 import javax.swing.*;

public class colorstring extends JPanel
{
	 String message; //fields, or the variables we use in the GUI that need to be
	 				// given to more than one class
	private Font font1,font2,font3,font4;
	
	//send the bigger constructor a null value
	public colorstring()
	{
		this(null);
	}
	
	//setting the fonts (this is a constructor)
	public colorstring(String message) 
	{
	  Font font1 = new Font("Serif",Font.BOLD,40);
	  Font font2 = new Font("SansSerif",Font.ITALIC,88);
	  Font font3 = new Font("MonoSpaced",Font.BOLD,35);
	  Font font4 = new Font("Dialog",Font.ITALIC,45);
	  
	  setBackground(Color.BLACK);
	}
	//draw the strings onto the panel
	public void paintComponent(Graphics g)
	{  
		if(message == null) // we send in a null variable, this makes sure
					// the message always has some value (null = nothing for computers)
	  {
		  message = "BACON IS GREAT!";
	  }
		super.paintComponent(g); // get the paintComponent from the super class (JPanel)
		Graphics2D g2 = (Graphics2D)g;
		g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_ON); // this is a method 
													// for making text prettier
		
		int height = getHeight(); // gets the height of the window
		int width = getWidth(); // width of the window
		
		for (int i =0; i<100;i++) 
		{
			int fontnum =(int) (4*Math.random())+1;
			
			switch(fontnum)// change the font based upon a random number chosen by computer
			{
			case 1:// if the random number is one, set the font to font1
				g.setFont(font1);
				break;
			case 2:
				g.setFont(font2);
				break;
			case 3:
				g.setFont(font3);
				break;
			case 4:
				g.setFont(font4);
				break;
			default:
				g.setFont(font1);
				break;
			}
			float hue = (float)Math.random(); // change the color with a random number
			g.setColor(Color.getHSBColor(hue, 1.0F, 1.0F));// set the color by hue
			
			int x,y; 
			x = -50 + (int) (Math.random()*width+40);// lets us move the string around at random
			y = (int)(Math.random()*(height+20));
			
			g.drawString(message, x, y); // draw the string at the position
		}
	}
	
	public static void main(String[] args)
	{
		JFrame window = new JFrame("WOOOO");
		colorstring content = new colorstring(null);
		
		window.setContentPane(content);
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.setLocation(150, 150);
		window.setSize(250, 350);
		window.setVisible(true);
	}
}