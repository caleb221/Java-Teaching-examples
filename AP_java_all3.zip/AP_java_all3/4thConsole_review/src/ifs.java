/*
 * Caleb Seifert
 * 11/14/16
 * console review part 1
 */

import java.util.*;

public class ifs 
{
	public static void main(String[] args)
	{
		Scanner keyboard = new Scanner(System.in);
		Date today = new Date();
		int num1=0;
		int num2=0;
		String mood;
		boolean check = false;
		
		System.out.println("Hello! how are you today?\n");
		mood= keyboard.nextLine();
		check = mood.equalsIgnoreCase("good");
		// if statements help us make deciscions in code
		//they take in 2 parameters (conditions/variables)
		//if the check is true the code in the {Squiggly brackets} 
		// is performed, if not the code moves on
		if(check == true)
		{
			System.out.println("Awesome! im happy you are doing well on "+today);
		}
		check = mood.equalsIgnoreCase("bad");
		if(check == true)
		{
			System.out.println("im sorry dude =\\ but dont worry it will be alright!");
		}
		check = mood.equalsIgnoreCase("meh");
		if(check == true)
		{
			System.out.println("i dont know either, im a computer");
		}
		
	}

}










