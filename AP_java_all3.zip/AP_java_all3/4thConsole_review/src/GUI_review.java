/*
 * Caleb Seifert 
 * 11/16/16
 * GUI review
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class GUI_review extends JFrame // the extends keyword tells us that we are creaing
									  // a subclass of JFrame
{
	//fields!
	//fields are the place we define all the variables that can be changed
	//while the code is running, or the variables that need to be accessed
	// by other classes
	JButton btn = new JButton("this is a button!");
	
	//constructor
	//constructors build our GUI, they are the blueprints that we define
	public GUI_review()
	{
		JPanel panel = new JPanel(); // create a panel object
		btn.addActionListener(new button_method());
		
		panel.setLayout(new FlowLayout()); // add a layout to the panel
		panel.add(btn);           		  //  add the button to the panel
		panel.add(new JLabel("this is a label!")); // add a label to the panel
		
		setContentPane(panel); // set the content pane (this is part of JFrame)
		pack();					//pack it up
		setTitle("this is the title");// set the FRAME title
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //enable default Frame buttons
	}
	
	public class button_method implements ActionListener // set up a class to handle events!
	{
		public void actionPerformed(ActionEvent e)	//when an event happens, it is sent here
		{
			if(e.getSource()==btn) // if the button named "btn" is pushed, the if statement
			{					  // will execute
				System.exit(0);
			}
		}
	}
	
	public static void main(String[] args)
	{
		GUI_review myGUI = new GUI_review(); // create the GUI object
		//we want to see all of our hard work! to do this we say....
		myGUI.setVisible(true);
	}

}
