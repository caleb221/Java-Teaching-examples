package eclipse_breaker;

/*
 * Caleb Seifert
 * 3/20/17
 * how to break eclipse!
 * a simple virus and other loops
 */

public class break_eclpise 
{
	public static void main(String[] args)
	{
		/*
		 * there are 2 main types of loops
		 * for loops (already talked about)
		 * and WHILE loops
		 * while loops act a bit differently than for loops
		 * we do not need to know 100% how many times we loop with a while loop
		 * lets see an example
		 */
		int number =0;
		while(number<10)
		{
			System.out.println("WHILE LOOP HAS REPEATED "+number+" Times");
			number++;
			/*
			 * variable++ means that we add 1 to the variable after each loop
			 * if variable is 1, the next time variable++ happens variable is now 2
			 * and then 3 and then it continues on until the loop has ended
			 */
		}
		int break_number =5;
		while(break_number < 10)
		{
			System.out.println("We have looped: "+break_number+" times");
			/*
			 * this is an INFINITE LOOP!
			 * but why is it infinite?
			 * there are 2 reasons why
			 * 1: we are checking break_number, but break_number never changes1
			 * 2: our logic in the loop is flawed
			 * we could attach this onto the back of a photo, or something
			 * and give it to our friends and fill up their computer
			 * with nonsense
			 */
		}
	}
}

/**
 * GUYS! its time for a project!
 * in this project, I want you to CREATE YOUR OWN GAME!
 * By the end of class time today, I want to see
 ***************************************************
 * I ENCOURAGE YOU TO MAKE YOUR OWN GRAPHICS! =)   *
 ***************************************************
 * 1: what type of game you want
 * 2: an idea of the gameplay (how will the user play your game?)
 * 3: how will you implement your controls? (keyboard, mouse, JButtons ect)
 * 4: at the VERY least, a project folder in your eclipse
 * 
 * Things we need to think about:
 * what objects will we need?
 * how will our interface look?
 * which libraries will we need?
 * 
 * Today's Game Goals:
 * 1: the outline for your classes 
 * 	--> where will the panel/frame be? 
 * 	--> where will the listener(s) be?
 * 	--> do you need any special data types? (arrays, arrayLists,hashMaps)
 * 
 * 2: Simple flowChart for your game's design (the player going through the game)
 * 	 --> USE THE FLOWCHART EXAMPLE FROM CH 7
 * 	 ------->>>>> I WANT TO SEE THIS ON PAPER
 * 				        EITHER TODAY(3/21/17) OR TOMORROW (3/22/17) 
 * 3: A list of Game rules
 * 
 * Things to think about:
 * how many classes do you need? depends on how many OBJECTS you want, and which type
 * 	 they are
 * 
 ======================================================= 
 |          DAY 3: FLOWCHART --> CODE                  |
 =======================================================
 * 
 * Today, we are going to start translating our flowchart into actual code!
 * --> remember, flowcharts are a form of psuedocode (sudo code)
 * 	   so your work is already half done! what still needs to be figured out is
 * 	   where to put all of the interactions and objects in your flowchart.
 * 	   --> we put them in classes XD 
 * 	   --> functions are friends,use all the library functions you can! it saves time
 * 	   
 * So today: start writing your game code! i would suggest to start out with the
 * 			 game rules and "brains" of the game, as this is the most difficult part
 * 
 * what I need to see from you today:
 * 1. The flowchart from yesterday
 * 2. the list of game rules
 * 3.The start of the brains of your code (at least start writing the class)
 *  
 ***********************if you need help please ask!*********************************
 * 
 * 
   ===================================================================
   \                                                                 /
    \ 				     DAY 4: the brain  							/
     \_____________________________________________________________/															   / 
 * 
 * Today we will put into action all of our game rules!
 * 	--> we need to use the class outline/flowchart
 *  --> implement the rules based on the USER 
 *  		(what happens when the user starts the game? how do they win?
 *  			when do they die? are there any instructions?)
 * Today's goals and what I need to see from you:
 * 1. Your game control center (brain) class and ALL THE RULES IMPLEMENTED (used)
 * 
 * --> remember, the brain needs to communicate with the rest of the body
 * 		just the same, your code brain communicates with the rest of your
 * 		classes...we can always check things THROUGH the player variable
 * 
 * --> you should have the rules written out on paper or somewhere in your computer
 *		try asking yourself if-else questions about the rules
 *				if the player shoots, what happens? the shot must be fired
 *				if the player dies, the game should end
 	**************EMAIL ME YOUR BRAIN CLASS TONIGHT******************************** 		
 --------------------------------------------------------
 |			DAY 5: The Body of your game				|
 --------------------------------------------------------
 * Now that we have our brain, its time to make the body!
 * this is the part of the code that everyone sees, so lets make it pretty!
 * also, the user interfacing is done here (controls, buttons,keyboard ect)
 * 
 * remember, we use pixels to draw our graphics
 * ..if you want faster motion simply add more pixels when you draw them
 * ..if you want an easier clickable space, divide the pixels to make them larger
 * 
 * dont forget to import your graphics into eclipse!
 *--> if you need help getting the files to read let me know!
 *->if you do not want to import graphics you are more than welcome to draw them out!
 * 
 * 
 * Day 5 I need to see from you:
 * 1. your connections between classes
 * 2. your graphics (paintComponent/paint/whatever you decide to use)
 * 3. your user interface (how you set up your keyboard/buttons/ect)
 * 
  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ 
  | 					DAY 6: USER INTERFACING					   |
  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 * 
 *  Today we look at our physical relationship with the user, how do they control
 * 	our game? 
 * 
 * we must ask " what is the most natural/ easiest way to play our game?"
 * and then implement it into code! 
 * is it a button?
 * is it the mouse?
 * is it the keyboard?
 * chances are, you may need to use more than just one of these interfaces!
 * remember, not all users have the same brain as you do. 
 * A good way to make sure (and make the whole experience better) 
 * for the user is to include an instructions page 
 * 
 * What I need to see from you today:
 * 1. how do you answer the question of "what is the easiest/most natural way to
 *  		play my game?"
 * 2. how you answer that question in your code
 * 
//  /\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\
//	\   					DAY 7:											 /	
// 	/						Graphics										 \
// 	\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
 * 
 * One of the fun parts about seeing our code work is how it looks!
 * today, lets focus on making our games look the best they can
 * importing sprites into eclipse is a very helpful way to make our codes look  
 * the way we want them.
 * piskel.com and other such sprite making applications can be useful!
 *			or we can find and edit pictures from the internet
 * 
 * remember: a great game is not only graphics but also challenging gameplay as well
 * 
 * what I would like to see from you today:
 *  if you are using sprites then please send me the .gif/.jpg/.png files
 *  if you are drawing graphics in Java please send me your 
 *  										paintComponent/paint/Canvas/draw method
 * if you are having any issue getting sprites to work or really any other problem
 * please let me know!
 * 					THIS IS THE LAST CLASS DAY TO WORK ON THIS PROJECT
 *  						IT IS DUE SATURDAY BEFORE MIDNIGHT
 */
