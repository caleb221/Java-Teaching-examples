/*
 * code bugs!
 */

public class bugs 
{
	public static void main(String[] args)
	{
		/*
		 * a code bug is an error =(
		 * errors are not uncommon, so do not worry
		 * there are always ways to fix errors!
		 * one of the most common types of errors is:
		 *  SYNTAX ERRORS
		 *  an error in spelling or the grammar of computers
		 *  Eclipse helps us DEBUG our code
		 */
		
		/*    \        /
		 *     \      /
		 *      |    |
		 * \____/------\____  
		 *      |  O o |    \
		 *      | \___/|    
		 *  ____\------/_____
		 * /                 \
		 */ 
		System.out.println("EXAMPLE OF ERROR (red lines)");
		
		/*
		 * the SECOND type of errors are......
		 * 	LOGIC ERRORS
		 */
		int number_to_add =5;
		int answer =0;
		/*
		 * i want to add (+) 5 to number_to _add, making its value 10
		 */
		answer = number_to_add * 5;//this multiplies the number by 5 0_0
		/*
		 * our code will not work the way we want =( 
		 * this is an example of a logic error, it is a mistake
		 * in our thinking and interaction with eclipse
		 * we usually only find them when we press the 'play' button
		 */

	}

}
