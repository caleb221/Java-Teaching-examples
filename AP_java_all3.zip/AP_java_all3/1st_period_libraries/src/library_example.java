
/*
 * 3/2/17
 * Libraries!
 * a library is a place with code that we did not write but we can use
 * these are helpful and save lots of our time
 * there is no need to re-invent the wheel, we share the wheel with 
 * everyone!
 */

import java.util.*;// this is the java.util library
				//this code shows us how we can use the library

public class library_example 
{
	public static void main(String[] args)
	{
		//the java.util library has a keyboard built into it! 
		//lets use it and see what happens
		Scanner keyboard = new Scanner(System.in);//keyboard in java
		
		int jaehons_number = 0;//number variable
		System.out.println("Hello! please input a number to add to 5!");
		jaehons_number = keyboard.nextInt();// save the number from user
		
		//make sure we saved the right number
		System.out.println("your input was:"+jaehons_number);
		System.out.println("your number +5 ="+(jaehons_number+5));
		/*
		 * THE TEXT IN GREEN ARE COMMENTS =)
		 * comments help us to know or figure out what is going on 
		 * inside the code
		 * comments are not code, and they are not "seen" by java
		 * they are helpful because they allow us to have notes
		 * in our code
		 */
	}
}
