/*
 * Caleb Seifert
 * Functions part 2
 * 10/18/16
 */

package functions_revisited;

import java.util.Scanner;

public class function_ex2 
{	
	
	public static int compare(int num1, int num2)
	{
		//compare two numbers, use whichever logical statement you think is best
		// <, >, !=, ==, <=, >=
		//return larger number
		return biggernum;
	}
	
	
	public static void main(String[] args)
	{
		Scanner keyboard = new Scanner(System.in);
		int num1=0;
		int num2 =0;
		int ans=0;
		//tell the user hello, and ask for 2 numbers
		//get the 2 numbers
		//send them into the function
		//let the user know the answer from the function
		//compare two numbers with a function
		ans = compare(num1,num2);
	}

}
