/*
 * Caleb Seifert
 * 10/17/16
 * Counting downwards and time
 */

package countdown1;

import java.util.*;

public class countdown11 
{
	public static void main(String[] args)
	{
		Date today= new Date();
		Scanner keys = new Scanner(System.in);
		
		int countdown=5;
		int input =0;
		
		System.out.println("Today is:  "+today);
		System.out.println("\nHello! Please input a number, 12 would be alright");
		input = keys.nextInt();
		
		while(countdown <= 0 || input != 12)
		{
			System.out.println("Why not choose 12?");
			input = keys.nextInt();
			System.out.println("You have "+ countdown+" chances left to choose 12\n");
			countdown--;
			
			
		}
		
	}
	
	
}
