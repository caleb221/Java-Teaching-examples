/*
 * Caleb Seifert
 * 11/16/16
 * GUI review
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*; //these are libraries! we use them to import many useful 
					 // functions so that we can use them and avoid writing
					// thousands of lines of code

public class GUIbasics extends JFrame// the extends keyword tells 
									 //us we are creating a subclass 
{
	//here are the fields, this is where we define variables that 
	// will be used or changed throughout the GUI while it is running
	JButton btn = new JButton("THIS IS A BUTTON!");
	
	//this is the constructor, it is the place we define the first steps for our GUI
	// it is like a blueprint for the GUI object
	public GUIbasics()
	{
		JPanel panel = new JPanel();
		//the panel is inside the frame, it is where all the actions happen
		panel.setLayout(new FlowLayout());
		
		btn.addActionListener(new button_method());//connect the button and the actionlistener
		
		panel.add(btn);                          //add the button to the panel
		panel.add(new JLabel("this is a label")); // create a label
		
		setContentPane(panel); // normally, we would need to define a frame object
		pack();				   // but since we have extended the JFrame class, it is not
		setTitle("this is the frame title"); // necessary to define a Frame unless we
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // are making a new window
	}
	
	public class button_method implements ActionListener
	{
		public void actionPerformed(ActionEvent e)
		{	//we put all the actions that our GUI can do in the action listener
			// this is where all our methods are called, when we want different 
			// methods for different buttons, we select the button with
			//e.getSource == (button or other object name)
			
			if(e.getSource() == btn) // this is how we make sure we exit when the 
			{						// button is clicked
				System.exit(0);
			}
		}
	}
	
	public static void main(String[] args)
	{
		GUIbasics gui = new GUIbasics();
		gui.setVisible(true);
	}
}







