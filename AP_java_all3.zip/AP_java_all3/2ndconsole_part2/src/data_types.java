/*
 * Caleb Seifert
 * 11/15/16
 * Data types
 */
import java.util.*;

public class data_types 
{
	public static void main(String[] args)
	{
		int number =0; // integers are whole counting numbers
		double decimal_num =0; // doubles have a decimal point (better accuracy)
		String name;        // strings are text in computers
		String array[] = new String[5]; // arrays --> one variable, multiple data
		int num_array[] = new int[5];  // same thing--> many integers, one variable 
		boolean bool = false; // booleans are used mostly for checking things, ONLY true or false
		
		Scanner keys = new Scanner(System.in);
		
		System.out.println("hello! these are the data types we have been using!\n");
		System.out.println("pick a number: ");
		//decimal_num=keys.nextDouble();
		System.out.println("your number as a double is: "+decimal_num+" and as an int is: "+(((int)decimal_num)));
		
		System.out.println("\ncool, now what is your name?\n");
		name=keys.nextLine();
		System.out.println("\nyour name is: "+name+"  which is a string, strings are text in CS\n");
		
	for(int i=0; i<name.length();i++)
	{
		System.out.println(name.charAt(i));
	}

	bool = name.equalsIgnoreCase("caleb");
	System.out.println(bool);
	System.out.println("enter 5 words");
	
	array[0]=keys.nextLine();
	array[1]=keys.nextLine();
	
	System.out.println("the first 2 names are: "+array[0]+" , "+array[1]);
	for(int n=0; n<array.length;n++)
	{
		array[n]=keys.nextLine();
	}
	System.out.println("the 3rd name you entered is: "+array[2]);
	System.out.println("\nnow try an integer array: enter 5 numbers\n");
	for(int n=0;n<num_array.length;n++)
	{
		num_array[n]=keys.nextInt();
	}
	System.out.println("the 2nd and 4th numbers you entered are: "+num_array[1]+","+num_array[3]);
	
	}

}
