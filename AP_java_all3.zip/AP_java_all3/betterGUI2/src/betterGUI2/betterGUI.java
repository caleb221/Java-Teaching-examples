/*
 * caleb seifert
 * 11/2/16
 * Better GUI
 */
package betterGUI2;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
public class betterGUI 
{
	private static class HelloDisplay extends JPanel
	{
		public void paintComponent(Graphics g)
		{
			super.paintComponent(g);
			Font font1 = new Font("SansSerif",Font.BOLD,25);
			g.setColor(Color.RED);
			g.setFont(font1);
			g.drawString("���!", 20, 30);
		}	
	}
	private static class Buttonclick implements ActionListener
	{
		public void actionPerformed(ActionEvent e)
		{
			
			Random rand = new Random();
			int num = rand.nextInt(3)+1;
			String name;
			//System.out.println(num);
			switch(num)
			{
			case 1: name ="Krystal";
				break;
			case 2: name = "Jay";
				break;
			case 3: name ="Anna";
				break;
			default: name = "irene";
				break;
			}
			JOptionPane.showMessageDialog(null, "���  "+name);
		}
	}
	public static void main(String[] args)
	{
		HelloDisplay box = new HelloDisplay();
		JButton button = new JButton("DO NOT CLICK!");
		Buttonclick click = new Buttonclick();
		
		button.addActionListener(click);
		
		JPanel content = new JPanel();
		content.setLayout(new BorderLayout());
		content.add(box, BorderLayout.CENTER);
		content.add(button,BorderLayout.SOUTH);
		
		JFrame window = new JFrame("Hey Yall!");
	window.getContentPane( ).setBackground(new Color(255,255,150));
	window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.setContentPane(content);
		window.setSize(250,100);
		window.setLocation(100, 200);
		window.setVisible(true);
	}
}