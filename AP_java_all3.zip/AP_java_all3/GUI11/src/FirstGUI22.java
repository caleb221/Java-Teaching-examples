/*
 * Caleb Seifert
 * 10/31/16
 * First GUI
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class FirstGUI22 
{
	private static class HelloDisplay extends JPanel 
	{
		public void paintComponent(Graphics g)
		{
			super.paintComponent(g);
			g.setColor(Color.magenta);
			
			Font font1 = new Font("SansSerif",Font.BOLD,20);
			g.setFont(font1);
			
			g.drawString("�� ��!",20, 30);
			g.drawString("make a good choice",20, 50);
			
		}		
	}
	
	private static class Buttonclick implements ActionListener
	{
		Date today = new Date();
		Random rand = new Random();
		int num = rand.nextInt(3);
		String name;
		
		public void actionPerformed(ActionEvent e) 
		{
			switch(num)
			{
				case 1: name ="Ken";
			break;
				case 2: name ="Joe";
			break;
				case 3: name = "Steven";
			break;
				default: name = "caleb";
			break;
			}
			System.out.println(num);
			num = rand.nextInt(3)+1;
			JOptionPane.showMessageDialog(null, "Hello "+name+"\n today is "+today);
			//System.exit(0);	
		}
	}
	
	private static class button2click implements ActionListener
	{
		public void actionPerformed(ActionEvent e)
		{
			String password;
			String passcheck = "112";
			boolean checked = false;
			Scanner keys = new Scanner(System.in);
			System.out.println("why did you click that one?\n");
			System.out.println("guess the password..");
			password = keys.next();
			checked = passcheck.equalsIgnoreCase(password);
			if(checked == true)
			{
				System.out.println("Awesome, you may leave now");
			}
			else 
			{
				System.out.println("you are stuck in the console forever HAHAHAHA");
				System.out.println("\n ok maybe not, try the password again");
				password = keys.nextLine();
			}
		}
	}

public static void main(String[] args)
{
	HelloDisplay box1 = new HelloDisplay();
	JButton mybutton= new JButton("DO NOT CLICK!");
	JButton button2 = new JButton("WHAT WILL HAPPEN?????");
	
	Buttonclick clicked = new Buttonclick();
	button2click clicked2= new button2click();
	
	mybutton.addActionListener(clicked);
	button2.addActionListener(clicked2);
	
	JPanel panel = new JPanel();
	panel.setLayout(new BorderLayout());
	panel.add(box1,BorderLayout.CENTER);
	panel.add(mybutton,BorderLayout.SOUTH);
	panel.add(button2,BorderLayout.WEST);
	
	JFrame window = new JFrame("WAKE UP ARCHER!!");
	window.setContentPane(panel);
	window.setSize(350,200);
	window.setLocation(100, 100);
	window.setVisible(true);
   }
}
