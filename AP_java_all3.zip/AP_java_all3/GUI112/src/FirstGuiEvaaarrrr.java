/*
 * Caleb Seifert
 * 10/31/16
 * first GUI
 */
import javax.swing.JOptionPane;

public class FirstGuiEvaaarrrr 
{
	public static void main(String[] args)
	{
		JOptionPane.showMessageDialog(null, "Happy OCTOBER 1ST!1!!");
	}
}
