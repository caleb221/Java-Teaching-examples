/*
 * Caleb seifert 
 * better GUI
 * 11/2/16
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class betterGUI 
{
	private static class HelloDisplay extends JPanel
	{
		public void paintComponent(Graphics g)
		{
			super.paintComponent(g);
			Font font1 = new Font("SansSerif",Font.BOLD,20);
			g.setColor(Color.BLUE);
			g.setFont(font1);
			g.drawString("Hello class! ", 20, 30);
			g.drawString("��֪���������ѧ", 20, 50);
		}
	}
	private static class Buttonclick implements ActionListener
	{
		public void actionPerformed(ActionEvent e)
		{
			System.out.println("WHY YOU CLICK ME????");
		}
	}
	
	public static void main(String[] args)
	{
		HelloDisplay display = new HelloDisplay();
		JButton button = new JButton("DO NOT CLICK ME!");
		Buttonclick clicked = new Buttonclick();
		
		button.addActionListener(clicked);
		
		JPanel content = new JPanel();
		content.setLayout(new BorderLayout());
		content.add(display, BorderLayout.CENTER);
		content.add(button,BorderLayout.SOUTH);
		
		JFrame window = new JFrame("WAKE UP KEVIN!");
		window.setContentPane(content);
		window.setSize(250,100);
		window.setLocation(100, 100);
		window.setVisible(true);
	}
}
