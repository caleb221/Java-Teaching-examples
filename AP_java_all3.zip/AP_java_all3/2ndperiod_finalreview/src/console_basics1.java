/*
 * review of console basics
 */

import java.util.*;

public class console_basics1 
{
	//main:the place where we run our code:
	public static void main(String[] args)
	{
		//a for loop is used when we need an operation repeated
		//and we have a known set of needed repitions
		//a while loop is used when we have a more flexible 
		//condition, but we run into infinite loops more often
		
		for(int i=0;i<15;i++)
		{
			//i is a variable that we created to keep track of where the 
			//loop is, the loop is set to run 15 (although the computer
			//sees it as 14, i-1) times..i will let us know where we are 
			System.out.println("the for loop has gone "+i+" times");
		}
		boolean loop_exit = false;
		int num =0;
		 while(loop_exit != true)
		{
			System.out.println("the while loop has repeated "+num+"times");
			System.out.println("\nthe value of the boolean is "+loop_exit);
			num++;
			if(num == 10)
			{
				loop_exit=true;//exit the loop after number is 10
			}
		}
		// if statements help us make decisions in our code!
		/*
		 * when we want something to change, we need to ask a question in
		 * a comparison type of way
		 *  if something is (like, equal to, less than, ect..) 
		 *  then perform an operation, if it is not, then we have
		 *  an option to say else for all other cases
		 */
		if(num<=10)
		{
			System.out.println("Number is greater than 10! 0_0 :"+num);
		}
		/*
		 * to connect a series of 'if statements'
		 * we can use if-else
		 */
		Scanner keys = new Scanner(System.in);
		num=keys.nextInt();
				if(num <5)
				{
					System.out.println("your number is less than 5");
				}
				else if(num <5 && num <20)
				{
					System.out.println("your number is between 5 and 20");
				}
				else
				{
					System.out.println("your number is larger than 20!");
				}
	/*
	 * an algorithm is a flexible equation that computers use
	 * to perform certain tasks, these tasks are often mathematical
	 * or for analyzing certain data sets, they can also be graphical
	 * 
	 * we use algorithms all the time
	 * here is an example of a graphical algorithm (we have seen this before)
	 */
				for(int row = 0; row<8;row++)
				{
					for(int col=0;col<8;col++)
					{
						if(row %2 == col %2)
						{
							System.out.print("| |");
						}
						else
						{
							System.out.print("__");
						}
						System.out.print("**");
					}
					System.out.println(" ");
				}
				
				/*
				 * computers are great at doing math,
				 * we have a whole library full of mathematical functions
				 * that are available to us, we call it Math.(function)
				 * and we can use it like this:
				 */
				System.out.println("your number squared is: "
									+(double)Math.pow(num, 2.0));
				System.out.println("Cos of your number is: "
									+(double)Math.cos(num));
				/*
				 * remember, we use functions ALL the time
				 * calling a function can be done in several ways
				 * if we are checking a value of a function we
				 * can use it inside of a conditional, that means
				 * the function has some type of 'return' statement
				 * for example, Math.cos(num) returns the cosine 
				 * 			of our number, we had to give it our
				 * 			number because it is expected..
				 * 	some functions do not require a return statement,
				 * but interact with our objects in way that has little
				 * effect on the program's data
				 * for example: paintComponent
				 * 		the paintComponent is a graphical function
				 * 		it changes the graphics but not the actual
				 * 		code data 
				 */
	}

}
