/*
 * Caleb Seifert
 * 1/11/17
 * pong review
 */

import java.awt.*;
import java.awt.event.*;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;
import java.util.*;
import javax.swing.*;
import javax.swing.Timer;

public class pong extends JPanel implements KeyListener,ActionListener
{
//our class is now a subclass (lower extension) of JPanel
//it also uses the key listener and action listener, which give us 
//the methods to enable keyboard and other such actions in the panel
	
	//fields
	//this is the place we define all of our variables that can
	//change while the program is running, they are normally 
	// the main variables of the code, and tell us what is happening where
	
	private int height,width;
	private Timer t = new Timer(5,this);
	private boolean first;
	
	private HashSet<String> keys = new HashSet<String>();
	
	//user's paddle (pad)
	private final int SPEED =1;
	private int padH =10, padW=40;
	private int bottomPadX,topPadX;
	private int inset = 10;
	
	//ball variables
	private double ballX,ballY,velX=1,velY=1,ballSize=20;
	
	//score variables
	private int scoreTop,scoreBottom;
	
	/* Constructors!
	 * constructors BUILD THE GUI! it is how we tell java
	 * how exactly we want the 1st state of the GUI to be 
	 * it is also where we connect our action listener(s)
	 * to the components we have
	 * constructors are NOT always necessary, unless we plan
	 * on returning a variable or we are building a piece of a GUI 
	 *NOTE: the constructor ALWAYS has the same name as the class
	 *														it is in
	 */
	public pong()
	{
		addKeyListener(this);// add our key listener to the panel
		setFocusable(true);//give a focus for the panel 
						  //the user must click on the panel to gain focus
		setFocusTraversalKeysEnabled(true);//making motion smoother
		first = true;
		t.setInitialDelay(1000);//wait 1000 miliseconds 
		t.start();//start the timer after waiting
	}
	
	public void paintComponent(Graphics g)
	{
		/*
		 * this is where we paint our panel!
		 * it will handle all of the game's graphics
		 */
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D)g;
		height=getHeight();
		width = getWidth();
		
		//first set up for the game
		if(first == true)
		{
			bottomPadX= width/2-padW/2;
			topPadX=bottomPadX;
			ballX=width/2- ballSize/2;
			ballY=height/2-ballSize/2;
			first = false;
		}
		
		Rectangle2D bottompad = new Rectangle(bottomPadX,
									height-padH-inset,padW,padH);
		g2.fill(bottompad);//put the rectangle on the panel!
		
		Rectangle2D topPad = new Rectangle(topPadX,inset,padW,padH);
		
		g2.fill(topPad);//put the rectangle on the panel!
		
		Ellipse2D ball = new Ellipse2D.Double(ballX,ballY,
											ballSize,ballSize);
		g2.fill(ball);//put the ball on the panel!
		
		String Tscore = "Top score: "+scoreTop;
		String Bscore = "Bottom Score: "+scoreBottom;
		
		g2.drawString(Tscore, width -50, height/2);
		g2.drawString(Bscore, 10, height/2);
		
	}
	
	
	@Override
	public void actionPerformed(ActionEvent e)
	{
		/*
		 * the actionPerformed is where we connect buttons
		 * and other methods that require the panel to UPDATE
		 * the timer is connected to the actionPerformed by its nature
		 * we use the actionPerformed to update graphics (repaint())
		 * and constantly check game logic 
		 * (we could also put this game logic in another class, 
		 * 		but we would still need to put it into the actionPerformed
		 * 		in order to update the state of the game) 
		 */
		
		
		/*
		 * Pong Game Logic!
		 * pong is a simple game, there are 2 pads and a ball, the ball
		 * is thrown across the screen and the pads need to make an
		 * attempt to stop the ball from hitting their side,
		 * if it does then the other player gets a point
		 */
	//side walls
		if(ballX <0 || ballX>width-ballSize)
		{
			velX = -velX;
		}
		
		if(ballY<0) // top wall
		{
			velY=-velY;
			scoreBottom+=1;
		}
		if(ballY +ballSize > height)//bottom wall
		{
			velY= -velY;
			scoreTop+=1;
		}
		
		//bottom pad
		if(ballY +ballSize >= height - padH-inset && velY >0)
		{
			if(ballX +ballSize >= bottomPadX && ballX<= bottomPadX+padW)
			{
				velY=-velY;
			}
		}
		//top pad
		if(ballY<= padH+inset && velY<0)
		{
			if(ballX+ballSize >= topPadX && ballX <= topPadX+padW)
			{
				velY=-velY;
			}
		}
		ballX+=velX;
		ballY+=velY;
	
		if(keys.size()==1)
		{
			if(keys.contains("LEFT"))
			{
				bottomPadX -= (bottomPadX > 0) ? SPEED: 0;
			}
			else if(keys.contains("RIGHT"))
			{
				bottomPadX +=(bottomPadX<width-padW) ? SPEED : 0;
			}
		}
		
		//AI 
		double delta= ballX-topPadX;
		if(delta>0)
		{
			topPadX += (topPadX < width - padW) ? SPEED : 0;
		}
		else if(delta < 0)
		{
			topPadX -=(topPadX > 0) ? SPEED : 0;
		}
		
		repaint();
	}
	
	public static void main(String[] args)
	{
		JFrame frame = new JFrame("PONG");
		pong game = new pong();
		frame.setContentPane(game);
		frame.setSize(300,700);
		frame.setResizable(false);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	@Override
	public void keyPressed(KeyEvent e)
	{
		/*
		 * The KeyEvent (Here it is named e) is the User's variable
		 * one could think of it as all the user's interaction with
		 * the program, here it is specialized to the keyboard, and
		 * will take in any user input from the keyboard
		 */
		int keypressed = e.getKeyCode();
		/*
		 * switch statements are much like an if-else statement
		 * the difference is that with a switch, we only check 1 variable
		 * this makes it efficient for variables that change quickly
		 * like e (user's variable)
		 */
		switch(keypressed)
		{
		case KeyEvent.VK_LEFT:
			keys.add("LEFT");
			break;
		case KeyEvent.VK_RIGHT:
			keys.add("RIGHT");
			break;
		}	
	}

	@Override
	public void keyReleased(KeyEvent arg0) 
	{
		int keypressed = arg0.getKeyCode();

		switch(keypressed)
		{
		case KeyEvent.VK_LEFT:
			keys.remove("LEFT");
			break;
		case KeyEvent.VK_RIGHT:
			keys.remove("RIGHT");
			break;
		}	
	}

	@Override
	public void keyTyped(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	
}
