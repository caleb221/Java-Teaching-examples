/*
 * Caleb seifert
 * 11/17/16
 * graphics review
 * 
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class graphics_review extends JPanel
{
	// field!
	Font f1 = new Font("SansSerif",Font.BOLD,25);
	Font f2 = new Font("MonoSpaced", Font.BOLD,30);
	
	//constructor
	public graphics_review()
	{
		setBackground(Color.BLACK);
		JFrame frame = new JFrame("woo this be the frame!");
		frame.setContentPane(this);
		frame.setLocation(300, 250);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(300, 150);
		frame.setVisible(true);	
	}
	public void paintComponent(Graphics g) // paint component is a JPanel function
	{
		super.paintComponent(g); // gets any graphics that has been already set up in the
								// constructor, and adds them into the panel	
							   // here, we have already set the background color to black
							  // so in order to keep that black background this is what we use
		g.setFont(f1);    // set the font, it has already been defined in the field
		g.setColor(Color.green); // choose a pretty color!
		int x = 150; // x-dimensions in pixels
		int y = 75; // y-dimensions in pixels
		g.drawString("�й� �� �Ǻó�", x, y);	 // draw a string! this paints a word for us onto
										//	the panel
		g.setColor(Color.cyan);
		g.setFont(f2);
		g.drawString("Hello!", x-45, y+30);
		//g.drawOval(x, y, 50, 50);

	}
	
	public static void main(String[] args)
	{
		graphics_review app = new graphics_review();
	}

}


