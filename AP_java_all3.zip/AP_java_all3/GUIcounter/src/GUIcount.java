/*
 * Caleb Seifert
 * 11/7/16
 * Counting in a GUI
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class GUIcount extends Frame implements ActionListener
{
	private Label lbl;         //makes a label
	private TextField textfld; //make a text field
	private Button btn;        //make a button
	private int count=0;	  // keep a count for how many times user has clicked
	
	//big constructor
	//Builds the GUI, the whole class is a subclass of JFrame, so no need to
	// explicitly create a JFrame
	public GUIcount()
	{
		setLayout(new FlowLayout());
		
		lbl = new Label("How many times can you click?");
		add(lbl); // add the label to the panel
		
		textfld = new TextField("", 10); // create a new text field (blank)
		textfld.setEditable(false);// we can not make the field a different size
		add(textfld); // add it to our panel
		
		btn = new Button("CLICK ME!"); // create a button!
		add(btn);   				  // add it to our panel
		
		btn.addActionListener(this); // connect the button and the action 
									// "this" means go look in the class for an 
								   //  actionListener
 		
		setTitle("THE CLICKER?");
		setSize(250,100);   //set the size of our frame
		setVisible(true);  //  lets us see what monstrousity we have created
	}
	public static void main(String[] args)
	{
		GUIcount app = new GUIcount(); // call our own class, it will create a GUI!
	}

	@Override // performs an action with updated data
	public void actionPerformed(ActionEvent e)
	{
		count++; // adds 1 to count every time we click
		textfld.setText("" + count); // lets the user see how many 
									//	clicks there have been
	}
}





