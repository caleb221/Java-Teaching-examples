/*
 * final review, semester 1, AP computer science
 */
import java.util.*;

public class day2 
{
	/*
	 * functions! functions are used to perform an action more than once
	 * they help when we need to do the same operation many times
	 * lets write a function that will raise a number the the 33rd power
	 */
	public static int thirtythirdpow(int num)
	{
		int ans=0;
		// here we use math.pow, it is another function written by
		//the good people at Sun (java creators)
		//we need to cast an integer data type, for conversion
		//functions are very picky about which inputs they receive
		ans = (int) Math.pow(num, 33.0);
		return ans;
	}
	
	public static void main(String[] args)
	{
		//keyboard
		Scanner keys = new Scanner(System.in);
		
		//number set up
		int num1,num2,num3 =0;
		
		//text (string) set up
		String words;
		
		System.out.println("hello, what is your name? ");
		words = keys.nextLine();
		System.out.println("hello "+words+"  nice to see you again!");
		System.out.println("how many numbers do you want to raise to the"
				+ "\n 33rd power?");
		num1=keys.nextInt();
		for(int i=0;i<=0;i++)
		{
			System.out.println("what number do you want to raise?");
			num2= keys.nextInt();
			num3 = thirtythirdpow(num2);
			System.out.println(num2+"^ 33 = "+num3);
		}
		
		/*
		 * algorithms!
		 * algorithms are much like equations, we use them all the time
		 * they are not bound to any specific programming language
		 * they can be used for math, graphics,data analysis, and other
		 * very useful operations we may need to perform in a program
		 * 
		 * algorithms usually are written in pseudocode 
		 * (half normal english half code) 
		 * and  they also use flow charts to explain what goes on
		 * here is an example:
		 */
		for(int i=0; i<words.length();i++)
		{
			for(int j=0;j<words.length();j++)
			{
				if(i%2 == j%2)
				{
					/*
					 * % is the modulus function
					 *   it divides the number and returns the remainder
					 *   of that number 
					 */
					//print out every other letter of your name!
					System.out.print("-"+words.charAt(j));
				}
			}
			System.out.println("_");
		}
		
		boolean check = false;
		System.out.println("input a letter to switch the boolean value!");
		System.out.println("the current value is: "+check);
		String word2 = keys.nextLine();
		if(word2 != null)
		{
			//booleans can use logical arithmetic!
			//because they only have 2 values, we can do a special
			// type of algebra with them, and it is very fast for
			//computers
			//			(boolean algebra)
			check = !check;
		}
		System.out.println("the boolean is now: "+check);
		
		
	}

}




