import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class brickbreaker extends JPanel
implements KeyListener,ActionListener,Runnable
{
	static boolean right = false;
	 static boolean left = false;

	 int ballx = 160;
	 int bally = 218;
	 int batx = 160;
	 int baty = 245;

	 int brickx = 70;
	 int bricky = 50;

	 int brickBreadth = 30;
	 int brickHeight = 20;

	 Rectangle Ball = new Rectangle(ballx, bally, 5, 5);
	 Rectangle Bat = new Rectangle(batx, baty, 40, 5);

	 Rectangle[] Brick = new Rectangle[12];
	 
	int movex = -1;
	int movey = -1;
	boolean ballFallDown = false;
	boolean bricksOver = false;
	int count = 0;
	String status;
	public brickbreaker() {
	  JFrame frame = new JFrame();
	
	  JButton button = new JButton("restart");
	  frame.setSize(350, 450);
	  frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	  frame.add(this);
	  frame.add(button, BorderLayout.SOUTH);
	  frame.setLocationRelativeTo(null);
	  frame.setResizable(false);
	  frame.setVisible(true);
	  button.addActionListener(this);

	  this.addKeyListener(this);
	  this.setFocusable(true);
	  Thread t = new Thread(this);
	  t.start();
	 }

	public void paint(Graphics g)
	{
		/*
		 * Graphics! they are almost just as important as data analysis
		 * who would want to use an ugly app? it not only benefits
		 * the user's experience, but also helps them follow
		 * along and take any action you would want them to.
		 */
		
		g.setColor(Color.PINK);//background color
		g.fillRect(0, 0, 350, 450);//background
		
		g.setColor(Color.MAGENTA);//ball color
		g.fillOval(Ball.x, Ball.y, Ball.width, Ball.height);
		g.setColor(Color.BLACK);
		g.fill3DRect(Bat.x, Bat.y, Bat.width, Bat.height,true);
		g.setColor(Color.GRAY);
		g.fillRect(0, 251, 450, 200);
		g.setColor(Color.blue);//brick color
		g.drawRect(0, 0, 343, 250);//border of panel
		for(int i=0;i<Brick.length;i++)
		{
			if(Brick[i] !=null)
			{
				g.fill3DRect(Brick[i].x,Brick[i].y, 
						Brick[i].width, Brick[i].height, true);
			}
		}
		
		if(ballFallDown == true || bricksOver == true)
		{
			Font f = new Font("Arial",Font.BOLD,20);
			g.setFont(f);
			g.drawString(status, 70, 120);
			ballFallDown=false;
			bricksOver = false;
		}
	}

	@Override
	public void run() 
	{
		/*
		 * the run method will not be on the final, but
		 * it is good to know that run has a built in timer and 
		 * updates automatically, it is connected with threads
		 * ...more on this next semester =D
		 */
		createBricks();
		
		while(true)
		{
			for(int i=0;i<Brick.length;i++)
			{
				if(Brick[i] != null)
				{
					if(Brick[i].intersects(Ball))
					{
						Brick[i] = null;
						movey=-movey;
						count++;
					}
				}
			}
			
			if(count == Brick.length)
			{
				bricksOver = true;
				status = "WOO!!! YOU WIN!!!!";
				repaint();
			}
			repaint();
			Ball.x +=movex;
			Ball.y +=movey;
			
			if(left == true)
			{
				Bat.x-=3;
				right = false;
			}
			if(right == true)
			{
				Bat.x +=3;
				left=false;
			}
			if(Bat.x <= 4)
			{
				Bat.x = 4;
			}
			else if(Bat.x >= 298)
			{
				Bat.x=298;
			}
			
			if(Ball.intersects(Bat))
			{
				movey=-movey;
			}
			if(Ball.x <= 0 || Ball.x + Ball.height >= 343)
			{
				movex=-movex;
			}
			if(Ball.y <= 0 )
			{
				movey=-movey;
			}
			if(Ball.y >= 250)
			{
				ballFallDown =true;
				status = "YOU LOST! THE BALL IS GONE 0_0";
				repaint();
			}
			try
			{
				Thread.sleep(10);
			}
			catch(Exception ex)
			{
				
			}	
		}
	}
	
	public void InitializeVariables()
	{
		  right = false;
		  left = false;

		  ballx = 160;
		  bally = 218;
		  batx = 160;
		  baty = 245;

		  brickx = 70;
		  bricky = 50;

		  brickBreadth = 30;
		  brickHeight = 20;

		 Rectangle Ball = new Rectangle(ballx, bally, 5, 5);
		 Rectangle Bat = new Rectangle(batx, baty, 40, 5);

		 Rectangle[] Brick = new Rectangle[12];
		 
		 movex = -1;
		 movey = -1;
		 ballFallDown = false;
		 bricksOver = false;
		 count = 0;
		 status = null;
	}
	
	public void restart()
	{
		requestFocus(true);
		InitializeVariables();
		createBricks();
		repaint();
	}

	@Override
	public void actionPerformed(ActionEvent e) 
	{
		/*
		 * if our panel needs to be updated, or a button is needed
		 * we use the actionPerformed, it also has the (you) variable e
		 * the action performed method updates the panel as the life
		 * of the program continues
		 */
		String str = e.getActionCommand();
		if(str.equals("restart"))
		{
			this.restart();
		}
	}
	public static void main(String[] args)
	{
		brickbreaker g = new brickbreaker();
	}

	@Override
	public void keyPressed(KeyEvent e) {
		/*
		 * the KeyEvent e variable is the user's (you) variable!
		 * anytime the user (you) presses down on a key
		 * the value of e changes!
		 * this is how we directly interface with the user
		 */
		int keypressed = e.getKeyCode();
		if(keypressed == KeyEvent.VK_LEFT)
		{
			left=true;
		}
		if(keypressed == KeyEvent.VK_RIGHT)
		{
			right = true;
		}
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		
		int keypressed = e.getKeyCode();
		
		if(keypressed == KeyEvent.VK_LEFT)
		{
			left=false;
		}
		if(keypressed == KeyEvent.VK_RIGHT)
		{
			right = false;
		}
	}
	public void createBricks()
	{
		//create bricks for the game!
		for(int i=0;i<Brick.length;i++)
		{
		  Brick[i]=new Rectangle(brickx,bricky,brickBreadth,brickHeight);
		  if(i == 5)
		  {
			  brickx = 70;
			  bricky = (bricky+brickHeight+2);
		  }
		  if(i ==9)
		  {
			  brickx=100;
			  bricky=(bricky+brickHeight+2);
		  }
		  brickx +=(brickBreadth+1);
		}
	}

	@Override
	public void keyTyped(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}

}
