/*
 * Caleb Seifert
 * AP Review (day1)
 * 
 */

import java.util.*;

public class day1 
{
	//for loops!
	//a for loop is used when we want to repeat a set of operations 
	// in which we know exactly how many times to repeat those operations
	// (we use while loops when the condition needs to be checked until
	//   a given parameter changes)
	public static void main(String[] args)
	{
		for(int i=0; i<15;i++)
		{// this loop will repeat 14 times (i-1, start from 0th place)
		// and all it will do is show us (user) how many times the loop 
		//has repeated
			System.out.println("the loop has repeated: "+i+"  times 0_0");
		}
		// now we will write a while loop
		//this loop has more flexibility with how many times it
		// repeats
		int i=0;
		while(i<10)
		{
			System.out.println("the while loop has gone: "+i+" times");
			i++;
		}
		boolean checker=false;
		i=0;
		while(checker == false)
		{
			i++;
			if(i == 5)
			{
				checker = true;
			}
		}	
	}	
}
